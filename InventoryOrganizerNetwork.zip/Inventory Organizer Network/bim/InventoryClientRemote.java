package bim;

import java.net.Socket;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Vector;
import java.util.Date;
import java.awt.Rectangle;

public class InventoryClientRemote {
  volatile Socket socketRemote;
  volatile DataInputStream dis;
  volatile DataOutputStream dos;
  volatile transient Object syncOut=new Object();
  public static int CREATE_USER=0;
  public static int LOG_IN=1;
  public static int DELETE_ME=2;
  public static int LOGOUT_NOW=3;
  public static int ADD_ADMIN=4;
  public static int DELETE_ADMIN=5;
  public static int VIEW_ADMIN=6;
  public static int FORCE_BACKUP_NOW=7;
  public static int CHANGE_PASSWORD=8;
  public static int CHANGE_EMAIL=9;
  public static int CHARACTER_BAN=10;
  public static int CHARACTER_UNBAN=11;
  public static int SHUTDOWN_SERVER=12;
  public static int GET_CONTAINER_LIST=13;
  public static int FILE_LOAD=14;
  public static int FILE_SAVE=15;
  public static int FILE_DELETE=16;


  public InventoryClientRemote(Socket socketRemote) throws Exception {
    this.socketRemote=socketRemote;
    dis=new DataInputStream(socketRemote.getInputStream());
    dos=new DataOutputStream(socketRemote.getOutputStream());
//    oos.flush();
  }

  public void write(String strOut) throws Exception {
    dos.writeInt(strOut.length());
    dos.writeBytes(strOut);
  }

  public void write(String strOut[]) throws Exception {
    dos.writeInt(strOut.length);
    for(int i=0;i<strOut.length;i++)
      write(strOut[i]);
  }

  public void write(String strOut[][]) throws Exception {
    dos.writeInt(strOut.length);
    dos.writeInt(strOut[0].length);
    for(int i=0;i<strOut.length;i++) {
      for(int ia=0;ia<strOut[0].length;ia++)
        write(strOut[i][ia]);
    }
  }

  public void write(short shrtOut[][]) throws Exception {
    dos.writeInt(shrtOut.length);
    dos.writeInt(shrtOut[0].length);
    for(int i=0;i<shrtOut.length;i++) {
      for(int ia=0;ia<shrtOut[0].length;ia++)
        dos.writeShort(shrtOut[i][ia]);
    }
  }

  public void write(int intOut) throws Exception {
    dos.writeInt(intOut);
  }

  public void write(Integer intOut) throws Exception {
    dos.writeInt(intOut.intValue());
  }

  public void write(int intOut[]) throws Exception {
    dos.writeInt(intOut.length);
    for(int i=0;i<intOut.length;i++)
      dos.writeInt(intOut[i]);
  }

  public void write(int intOut[][]) throws Exception {
    dos.writeInt(intOut.length);
    dos.writeInt(intOut[0].length);
    for(int i=0;i<intOut.length;i++) {
      for(int ia=0;ia<intOut[0].length;ia++)
        dos.writeInt(intOut[i][ia]);
    }
  }

  public void write(Long lngOut) throws Exception {
    dos.writeLong(lngOut.longValue());
  }

  public void write(Long lngOut[]) throws Exception {
    dos.writeInt(lngOut.length);
    for(int i=0;i<lngOut.length;i++)
      dos.writeLong(lngOut[i].longValue());
  }

  public void write(boolean blnOut) throws Exception {
    dos.writeBoolean(blnOut);
  }

  public void write(Boolean blnOut) throws Exception {
    dos.writeBoolean(blnOut.booleanValue());
  }

  public void write(InventoryItem item) throws Exception {
    write(item.strName);
    write(item.strDescription);
    write(item.intX);
    write(item.intY);
    write(item.intWidth);
    write(item.intHeight);
    write(item.intWeight);
    write(item.intWeightMax);
    if(item.dateExpiration==null)
      write(false);
    else {
      write(true);
      write(item.dateExpiration);
    }
    if(item.strImage==null)
      write(false);
    else {
      write(true);
      write(item.strImage);
    }
  }

  public void write(InventoryContainer item) throws Exception {
    write(item.strName);
    write(item.strDescription);
    write(item.intX);
    write(item.intY);
    write(item.intWidth);
    write(item.intHeight);
    write(item.intWeight);
    write(item.intWeightMax);
    if(item.dateExpiration==null)
      write(false);
    else {
      write(true);
      write(item.dateExpiration);
    }
    if(item.strImage==null)
      write(false);
    else {
      write(true);
      write(item.strImage);
    }

    write(item.intContainerWidth);
    write(item.intContainerHeight);
    writeInventoryVector(item.vecItems);
    write(item.vacantSpaces);
  }

  public void write(Date dateExpiration) throws Exception {
    write(dateExpiration.getYear());
    write(dateExpiration.getMonth());
    write(dateExpiration.getDate());
  }

  public void writeInventoryVector(Vector vecItems) throws Exception {
    write(vecItems.size());
    for(int i=0;i<vecItems.size();i++) {
      InventoryItem item=(InventoryItem)vecItems.elementAt(i);
      if(item instanceof InventoryContainer) {
        InventoryContainer container=(InventoryContainer)item;

        write(false);
        write(container);
      }
      else {
        write(true);
        write(item);
      }
    }
  }

  public void write(Rectangle vacantSpaces[]) throws Exception {
    write(vacantSpaces.length);
 
    for(int i=0;i<vacantSpaces.length;i++) {
      write((int)vacantSpaces[i].getX());
      write((int)vacantSpaces[i].getY());
      write((int)vacantSpaces[i].getWidth());
      write((int)vacantSpaces[i].getHeight());
    }
  }

  public void flush() throws Exception {
    dos.flush();
  }

  public boolean readBoolean() throws Exception {
    return dis.readBoolean();
  }

  public String readStr() throws Exception {
    int intLen=dis.readInt();
    byte bbuf[]=new byte[intLen];
    dis.readFully(bbuf);
    String strStr=new String(bbuf);

    return strStr;
  }

  public String[] readStrs() throws Exception {
    int intStrALen=dis.readInt();
    String strStrA[]=new String[intStrALen];
    for(int i=0;i<intStrALen;i++)
      strStrA[i]=readStr();

    return strStrA;
  }

  public int readInt() throws Exception {
    return dis.readInt();
  }

  public InventoryItem readInventoryItem() throws Exception {
    String strName=readStr();
    String strDescription=readStr();
    int intX=readInt();
    int intY=readInt();
    int intWidth=readInt();
    int intHeight=readInt();
    int intWeight=readInt();
    int intWeightMax=readInt();
    boolean blnHasDate=readBoolean();
    Date dateExpiration=null;
    if(blnHasDate)
      dateExpiration=readDate();
    boolean blnHasImage=readBoolean();
    String strImage=null;
    if(blnHasImage)
      strImage=readStr();

    InventoryItem item=new InventoryItem();
    item.strName=strName;
    item.strDescription=strDescription;
    item.intX=intX;
    item.intY=intY;
    item.intWidth=intWidth;
    item.intHeight=intHeight;
    item.intWeight=intWeight;
    item.intWeightMax=intWeightMax;
    item.dateExpiration=dateExpiration;
    item.strImage=strImage;

    return item;
  }

  public InventoryContainer readInventoryContainer() throws Exception {
    String strName=readStr();
    String strDescription=readStr();
    int intX=readInt();
    int intY=readInt();
    int intWidth=readInt();
    int intHeight=readInt();
    int intWeight=readInt();
    int intWeightMax=readInt();
    boolean blnHasDate=readBoolean();
    Date dateExpiration=null;
    if(blnHasDate)
      dateExpiration=readDate();
    boolean blnHasImage=readBoolean();
    String strImage=null;
    if(blnHasImage)
      strImage=readStr();

    int intContainerWidth=readInt();
    int intContainerHeight=readInt();
    Vector vecItems=readInventoryVector();
    Rectangle vacantSpaces[]=readInventorySpaces();

    InventoryContainer container=new InventoryContainer();
    container.strName=strName;
    container.strDescription=strDescription;
    container.intX=intX;
    container.intY=intY;
    container.intWidth=intWidth;
    container.intHeight=intHeight;
    container.intWeight=intWeight;
    container.intWeightMax=intWeightMax;
    container.dateExpiration=dateExpiration;
    container.strImage=strImage;

    container.intContainerWidth=intContainerWidth;
    container.intContainerHeight=intContainerHeight;
    container.vecItems=vecItems;
    container.vacantSpaces=vacantSpaces;

    return container;
  }

  public Date readDate() throws Exception {
    int intYear=readInt();
    int intMonth=readInt();
    int intDate=readInt();

    return new Date(intYear, intMonth, intDate);
  }

  public Vector readInventoryVector() throws Exception {
    Vector vecRet=new Vector();

    int intVSize=readInt();
    for(int i=0;i<intVSize;i++) {
      boolean blnIsItem=readBoolean();
      if(blnIsItem)
        vecRet.addElement(readInventoryItem());
      else
        vecRet.addElement(readInventoryContainer());
    }

    return vecRet;
  }

  public Rectangle[] readInventorySpaces() throws Exception {
    int intSSize=readInt();
    Rectangle vacantSpaces[]=new Rectangle[intSSize];
    for(int i=0;i<intSSize;i++)
      vacantSpaces[i]=new Rectangle(readInt(), readInt(), readInt(), readInt());

    return vacantSpaces;
  }





  public String createUser(String name, String email, String strPass) {
synchronized(syncOut) {
    try {
      write(new Integer(CREATE_USER));
      write(name);
      write(email);
      write(strPass);
      flush();

      String strIn=readStr();
  
      return strIn;
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}

    return null;
  }

  public String logIn(String name, String pass, String strClientAddress, Integer intClientPort) {
synchronized(syncOut) {
    try {
      write(new Integer(LOG_IN));
      write(name);
      write(pass);
      write(strClientAddress);
      write(intClientPort);
      flush();

      String strIn=readStr();
  
      return strIn;
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}

    return null;
  }

  public void deleteMe() {
synchronized(syncOut) {
    try {
      write(new Integer(DELETE_ME));
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }

  public void logoutNow() {
synchronized(syncOut) {
    try {
      write(new Integer(LOGOUT_NOW));
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }

  public void addAdmin(String adminName) {
synchronized(syncOut) {
    try {
      write(new Integer(ADD_ADMIN));
      write(adminName);
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }

  public void deleteAdmin(String adminName) {
synchronized(syncOut) {
    try {
      write(new Integer(DELETE_ADMIN));
      write(adminName);
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }

  public String[] viewAdmin() {
synchronized(syncOut) {
    try {
      write(new Integer(VIEW_ADMIN));
      flush();

      String strInZ[]=readStrs();
  
      return strInZ;
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}

    return null;
  }

  public void forceBackupNow() {
synchronized(syncOut) {
    try {
      write(new Integer(FORCE_BACKUP_NOW));
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }

  public String changePassword(String strOldPassword, String strNewPassword) {
synchronized(syncOut) {
    try {
      write(new Integer(CHANGE_PASSWORD));
      write(strOldPassword);
      write(strNewPassword);
      flush();

      String strIn=readStr();

      return strIn;
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}

    return null;
  }

  public void changeEmail(String strEmail) {
synchronized(syncOut) {
    try {
      write(new Integer(CHANGE_EMAIL));
      write(strEmail);
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }

  public void characterBan(String strCharName, Long lngBanTime) {
synchronized(syncOut) {
    try {
      write(new Integer(CHARACTER_BAN));
      write(strCharName);
      write(lngBanTime);
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }

  public void characterUnban(String strCharName) {
synchronized(syncOut) {
    try {
      write(new Integer(CHARACTER_UNBAN));
      write(strCharName);
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }

  public void shutdownServer(Integer intMinutes) {
synchronized(syncOut) {
    try {
      write(new Integer(SHUTDOWN_SERVER));
      write(intMinutes);
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }

  public String[] getContainerList() {
synchronized(syncOut) {
    try {
      write(new Integer(GET_CONTAINER_LIST));
      flush();

      String strIn[]=readStrs();

      return strIn;
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
    return null;
  }

  public InventoryContainer fileLoad(String strContainerName) {
synchronized(syncOut) {
    try {
      write(new Integer(FILE_LOAD));
      write(strContainerName);
      flush();

      return readInventoryContainer();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}

    return null;
  }

  public void fileSave(String strContainerName, InventoryContainer container) {
synchronized(syncOut) {
    try {
      write(new Integer(FILE_SAVE));
      write(strContainerName);
      write(container);
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }

  public void fileDelete(String strContainerName) {
synchronized(syncOut) {
    try {
      write(new Integer(FILE_DELETE));
      write(strContainerName);
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }
}