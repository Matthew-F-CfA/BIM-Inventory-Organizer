package bim;

import java.io.Serializable;
import java.util.Vector;

class InventoryRecipe extends InventoryIngredient
implements Serializable {
  Vector vecIngredients=new Vector();

  InventoryRecipe() {
  }

  InventoryRecipe(String strName, String strDescription) {
    this.strName=strName;
    this.strDescription=strDescription;
  }

  InventoryRecipe(String strName, String strDescription, Vector vecIngredients) {
    this.strName=strName;
    this.strDescription=strDescription;
    this.vecIngredients=vecIngredients;
  }

  public Vector getIngredients() {
    return vecIngredients;
  }

  public void setIngredients(Vector vecIngredients) {
    this.vecIngredients=vecIngredients;
  }

  public String getDetails() {
    String strDetails="";

    for(int i=0;i<vecIngredients.size();i++) {
      InventoryIngredient ingredient=(InventoryIngredient)vecIngredients.elementAt(i);
      strDetails+=ingredient.getDetails()+"\n\n";
    }

    return strDetails;
  }
}