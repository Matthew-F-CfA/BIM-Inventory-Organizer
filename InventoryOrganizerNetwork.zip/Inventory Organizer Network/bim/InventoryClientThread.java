package bim;

import java.net.Socket;
import java.net.SocketException;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Vector;
import java.util.Date;
import java.awt.Rectangle;

class InventoryClientThread extends Thread {
  volatile Socket socketRemote;
  volatile DataInputStream dis;
  volatile DataOutputStream dos;
  volatile InventoryServer receiver;
  volatile InventoryUser user;
  volatile boolean keepRunning=true;

  InventoryClientThread(InventoryServer receiver, Socket socketRemote, DataInputStream dis, DataOutputStream dos) throws Exception {
    super();
    this.receiver=receiver;
    this.socketRemote=socketRemote;
    this.dis=dis;
    this.dos=dos;
  }

  InventoryClientThread(InventoryServer receiver, InventoryUser user, Socket socketRemote, DataInputStream dis, DataOutputStream dos) throws Exception {
    super();
    this.receiver=receiver;
    this.user=user;
    this.socketRemote=socketRemote;
    this.dis=dis;
    this.dos=dos;
  }

  public InventoryUser getUser() {
    return user;
  }

  public void setUser(InventoryUser user) {
    this.user=user;
  }

  public void write(String strOut) throws Exception {
    dos.writeInt(strOut.length());
    dos.writeBytes(strOut);
  }

  public void write(String strOut[]) throws Exception {
    dos.writeInt(strOut.length);
    for(int i=0;i<strOut.length;i++)
      write(strOut[i]);
  }

  public void write(String strOut[][]) throws Exception {
    dos.writeInt(strOut.length);
    dos.writeInt(strOut[0].length);
    for(int i=0;i<strOut.length;i++) {
      for(int ia=0;ia<strOut[0].length;ia++)
        write(strOut[i][ia]);
    }
  }

  public void write(short shrtOut[][]) throws Exception {
    dos.writeInt(shrtOut.length);
    dos.writeInt(shrtOut[0].length);
    for(int i=0;i<shrtOut.length;i++) {
      for(int ia=0;ia<shrtOut[0].length;ia++)
        dos.writeShort(shrtOut[i][ia]);
    }
  }

  public void write(int intOut) throws Exception {
    dos.writeInt(intOut);
  }

  public void write(Integer intOut) throws Exception {
    dos.writeInt(intOut.intValue());
  }

  public void write(int intOut[]) throws Exception {
    dos.writeInt(intOut.length);
    for(int i=0;i<intOut.length;i++)
      dos.writeInt(intOut[i]);
  }

  public void write(int intOut[][]) throws Exception {
    dos.writeInt(intOut.length);
    dos.writeInt(intOut[0].length);
    for(int i=0;i<intOut.length;i++) {
      for(int ia=0;ia<intOut[0].length;ia++)
        dos.writeInt(intOut[i][ia]);
    }
  }

  public void write(Long lngOut) throws Exception {
    dos.writeLong(lngOut.longValue());
  }

  public void write(Long lngOut[]) throws Exception {
    dos.writeInt(lngOut.length);
    for(int i=0;i<lngOut.length;i++)
      dos.writeLong(lngOut[i].longValue());
  }

  public void write(boolean blnOut) throws Exception {
    dos.writeBoolean(blnOut);
  }

  public void write(Boolean blnOut) throws Exception {
    dos.writeBoolean(blnOut.booleanValue());
  }

  public void write(InventoryItem item) throws Exception {
    write(item.strName);
    write(item.strDescription);
    write(item.intX);
    write(item.intY);
    write(item.intWidth);
    write(item.intHeight);
    write(item.intWeight);
    write(item.intWeightMax);
    if(item.dateExpiration==null)
      write(false);
    else {
      write(true);
      write(item.dateExpiration);
    }
    if(item.strImage==null)
      write(false);
    else {
      write(true);
      write(item.strImage);
    }
  }

  public void write(InventoryContainer item) throws Exception {
    write(item.strName);
    write(item.strDescription);
    write(item.intX);
    write(item.intY);
    write(item.intWidth);
    write(item.intHeight);
    write(item.intWeight);
    write(item.intWeightMax);
    if(item.dateExpiration==null)
      write(false);
    else {
      write(true);
      write(item.dateExpiration);
    }
    if(item.strImage==null)
      write(false);
    else {
      write(true);
      write(item.strImage);
    }

    write(item.intContainerWidth);
    write(item.intContainerHeight);
    writeInventoryVector(item.vecItems);
    write(item.vacantSpaces);
  }

  public void write(Date dateExpiration) throws Exception {
    write(dateExpiration.getYear());
    write(dateExpiration.getMonth());
    write(dateExpiration.getDate());
  }

  public void writeInventoryVector(Vector vecItems) throws Exception {
    write(vecItems.size());
    for(int i=0;i<vecItems.size();i++) {
      InventoryItem item=(InventoryItem)vecItems.elementAt(i);
      if(item instanceof InventoryContainer) {
        InventoryContainer container=(InventoryContainer)item;

        write(false);
        write(container);
      }
      else {
        write(true);
        write(item);
      }
    }
  }

  public void write(Rectangle vacantSpaces[]) throws Exception {
    write(vacantSpaces.length);
 
    for(int i=0;i<vacantSpaces.length;i++) {
      write((int)vacantSpaces[i].getX());
      write((int)vacantSpaces[i].getY());
      write((int)vacantSpaces[i].getWidth());
      write((int)vacantSpaces[i].getHeight());
    }
  }

  public void flush() throws Exception {
    dos.flush();
  }

  public long readLong() throws Exception {
    return dis.readLong();
  }

  public int readInt() throws Exception {
    return dis.readInt();
  }

  public String readStr() throws Exception {
    int intLen=dis.readInt();
    byte bbuf[]=new byte[intLen];
    dis.readFully(bbuf);
    String strStr=new String(bbuf);

    return strStr;
  }

  public String[] readStrs() throws Exception {
    int intStrALen=dis.readInt();
    String strStrA[]=new String[intStrALen];
    for(int i=0;i<intStrALen;i++)
      strStrA[i]=readStr();

    return strStrA;
  }

  public String[][] readStrs2() throws Exception {
    int intStrLen=dis.readInt();
    int intStr2Len=dis.readInt();
    String strStrA[][]=new String[intStrLen][intStr2Len];
    for(int i=0;i<intStrLen;i++) {
      for(int ia=0;ia<intStr2Len;ia++)
        strStrA[i][ia]=readStr();
    }

    return strStrA;
  }

  public short[][] readShrts2() throws Exception {
    int intShrtLen=dis.readInt();
    int intShrt2Len=dis.readInt();
    short shrtShrtA[][]=new short[intShrtLen][intShrt2Len];
    for(int i=0;i<intShrtLen;i++) {
      for(int ia=0;ia<intShrt2Len;ia++)
        shrtShrtA[i][ia]=dis.readShort();
    }

    return shrtShrtA;
  }

  public int[] readInts() throws Exception {
    int intIn[]=new int[dis.readInt()];
    for(int i=0;i<intIn.length;i++)
     intIn[i]=dis.readInt();

    return intIn;
  }

  public int[][] readInts2() throws Exception {
    int intFirstLen=dis.readInt();
    int intSecondLen=dis.readInt();
    int intIn[][]=new int[intFirstLen][intSecondLen];
    for(int i=0;i<intFirstLen;i++) {
      for(int ia=0;ia<intSecondLen;ia++)
        intIn[i][ia]=dis.readInt();
    }

    return intIn;
  }

  public Long[] readLongs() throws Exception {
    int intLongALen=dis.readInt();
    Long lngIn[]=new Long[intLongALen];
    for(int i=0;i<intLongALen;i++)
      lngIn[i]=new Long(dis.readLong());

    return lngIn;
  }

  public boolean readBoolean() throws Exception {
    return dis.readBoolean();
  }

  public InventoryItem readInventoryItem() throws Exception {
    String strName=readStr();
    String strDescription=readStr();
    int intX=readInt();
    int intY=readInt();
    int intWidth=readInt();
    int intHeight=readInt();
    int intWeight=readInt();
    int intWeightMax=readInt();
    boolean blnHasDate=readBoolean();
    Date dateExpiration=null;
    if(blnHasDate)
      dateExpiration=readDate();
    boolean blnHasImage=readBoolean();
    String strImage=null;
    if(blnHasImage)
      strImage=readStr();

    InventoryItem item=new InventoryItem();
    item.strName=strName;
    item.strDescription=strDescription;
    item.intX=intX;
    item.intY=intY;
    item.intWidth=intWidth;
    item.intHeight=intHeight;
    item.intWeight=intWeight;
    item.intWeightMax=intWeightMax;
    item.dateExpiration=dateExpiration;
    item.strImage=strImage;

    return item;
  }

  public InventoryContainer readInventoryContainer() throws Exception {
    String strName=readStr();
    String strDescription=readStr();
    int intX=readInt();
    int intY=readInt();
    int intWidth=readInt();
    int intHeight=readInt();
    int intWeight=readInt();
    int intWeightMax=readInt();
    boolean blnHasDate=readBoolean();
    Date dateExpiration=null;
    if(blnHasDate)
      dateExpiration=readDate();
    boolean blnHasImage=readBoolean();
    String strImage=null;
    if(blnHasImage)
      strImage=readStr();

    int intContainerWidth=readInt();
    int intContainerHeight=readInt();
    Vector vecItems=readInventoryVector();
    Rectangle vacantSpaces[]=readInventorySpaces();

    InventoryContainer container=new InventoryContainer();
    container.strName=strName;
    container.strDescription=strDescription;
    container.intX=intX;
    container.intY=intY;
    container.intWidth=intWidth;
    container.intHeight=intHeight;
    container.intWeight=intWeight;
    container.intWeightMax=intWeightMax;
    container.dateExpiration=dateExpiration;
    container.strImage=strImage;

    container.intContainerWidth=intContainerWidth;
    container.intContainerHeight=intContainerHeight;
    container.vecItems=vecItems;
    container.vacantSpaces=vacantSpaces;

    return container;
  }

  public Date readDate() throws Exception {
    int intYear=readInt();
    int intMonth=readInt();
    int intDate=readInt();

    return new Date(intYear, intMonth, intDate);
  }

  public Vector readInventoryVector() throws Exception {
    Vector vecRet=new Vector();

    int intVSize=readInt();
    for(int i=0;i<intVSize;i++) {
      boolean blnIsItem=readBoolean();
      if(blnIsItem)
        vecRet.addElement(readInventoryItem());
      else
        vecRet.addElement(readInventoryContainer());
    }

    return vecRet;
  }

  public Rectangle[] readInventorySpaces() throws Exception {
    int intSSize=readInt();
    Rectangle vacantSpaces[]=new Rectangle[intSSize];
    for(int i=0;i<intSSize;i++)
      vacantSpaces[i]=new Rectangle(readInt(), readInt(), readInt(), readInt());

    return vacantSpaces;
  }

  public void run() {
    int intReceiveMethod=-1;

    try {
      while(keepRunning) {
        intReceiveMethod=dis.readInt();

        if(intReceiveMethod==InventoryClientRemote.CREATE_USER) {
          String strUserName=readStr();
          String strPassword=readStr();
          String strEmail=readStr();

          String strOut=receiver.createUser(strUserName, strPassword, strEmail);

          write(strOut);

          socketRemote.close();

          return;
        }
        else if(intReceiveMethod==InventoryClientRemote.LOG_IN) {
          String strUserName=readStr();
          String strPassword=readStr();
          String strClientAddress=readStr();
          Integer intClientPort=new Integer(readInt());
          String strOut=receiver.logIn(user, socketRemote, strUserName, strPassword, strClientAddress, intClientPort);

          write(strOut);

          if(!strOut.equals("Logged in.")) {
            socketRemote.close();

            receiver.removeVecUninitClientThread();

            return;
          }
        }
        else if(intReceiveMethod==InventoryClientRemote.DELETE_ME) {
          receiver.deleteMe(user);

          try {
            socketRemote.close();
          }
          catch(Exception ex) {
          }

          receiver.logoutNow(user);
        }
        else if(intReceiveMethod==InventoryClientRemote.LOGOUT_NOW) {
          receiver.logoutNow(user);
          return;
        }
        else if(intReceiveMethod==InventoryClientRemote.ADD_ADMIN) {
          String strAdminName=readStr();

          receiver.addAdmin(user, strAdminName);
        }
        else if(intReceiveMethod==InventoryClientRemote.DELETE_ADMIN) {
          String strAdminName=readStr();

          receiver.deleteAdmin(user, strAdminName);
        }
        else if(intReceiveMethod==InventoryClientRemote.VIEW_ADMIN) {
          String strAdminNames[]=receiver.viewAdmin(user);

          write(strAdminNames);
        }
        else if(intReceiveMethod==InventoryClientRemote.FORCE_BACKUP_NOW) {
          receiver.forceBackupNow(user);
        }
        else if(intReceiveMethod==InventoryClientRemote.CHANGE_PASSWORD) {
          String strName=readStr();
          String strPass=readStr();

          String strRet=receiver.changePassword(user, strName, strPass);

          write(strRet);
        }
        else if(intReceiveMethod==InventoryClientRemote.CHANGE_EMAIL) {
          String strEmail=readStr();

          receiver.changeEmail(user, strEmail);
        }
        else if(intReceiveMethod==InventoryClientRemote.CHARACTER_BAN) {
          String strName=readStr();
          Long lngBanTime=new Long(readLong());

          receiver.characterBan(user, strName, lngBanTime);
        }
        else if(intReceiveMethod==InventoryClientRemote.CHARACTER_UNBAN) {
          String strName=readStr();

          receiver.characterUnban(user, strName);
        }
        else if(intReceiveMethod==InventoryClientRemote.SHUTDOWN_SERVER) {
          Integer intMinutes=new Integer(readInt());

          receiver.shutdownServer(user, intMinutes);
        }
        else if(intReceiveMethod==InventoryClientRemote.GET_CONTAINER_LIST) {
          String strOut[]=receiver.getContainerList(user);

          write(strOut);
        }
        else if(intReceiveMethod==InventoryClientRemote.FILE_LOAD) {
          String strContainerName=readStr();

          InventoryContainer container=receiver.fileLoad(user, strContainerName);

          write(container);
        }
        else if(intReceiveMethod==InventoryClientRemote.FILE_SAVE) {
          String strContainerName=readStr();
          InventoryContainer container=readInventoryContainer();

          receiver.fileSave(user, strContainerName, container);
        }
        else if(intReceiveMethod==InventoryClientRemote.FILE_DELETE) {
          String strContainerName=readStr();

          receiver.fileDelete(user, strContainerName);
        }

        if(user!=null) {
          user.setLastClientCommandTime(System.currentTimeMillis());

          if(InventoryClientThread.isReceiveMethodSave(intReceiveMethod))
            user.save();
        }

      }

      socketRemote.close();
    }
    catch(SocketException ex) {
      try {
        socketRemote.close();
      }
      catch(Exception ex2) {
      }

      receiver.removeVecUninitClientThread();

      if(user!=null) {
        receiver.logoutNow(user);
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();

      try {
        socketRemote.close();
      }
      catch(Exception ex2) {
      }

      receiver.removeVecUninitClientThread();

      if(user!=null) {
        receiver.logoutNow(user);
      }
    }
  }

  public static boolean isReceiveMethodSave(int intReceiveMethod) {
    if(intReceiveMethod==InventoryClientRemote.FILE_SAVE)
      return true;
    else if(intReceiveMethod==InventoryClientRemote.FILE_DELETE)
      return true;

//    if(intReceiveMethod==TCliRemote2.LOGOUT_NOW)
//      return true;

    return false;
  }
}