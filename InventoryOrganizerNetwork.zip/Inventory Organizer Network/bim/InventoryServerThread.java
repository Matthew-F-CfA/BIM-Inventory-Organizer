package bim;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

class InventoryServerThread extends Thread {
  volatile Socket socketRemote;
  volatile DataInputStream dis;
  volatile DataOutputStream dos;
  volatile InventoryReceiver receiver;
  volatile boolean keepRunning=true;

  InventoryServerThread(InventoryReceiver receiver, Socket socketRemote) throws Exception {
    super();
    this.receiver=receiver;
    this.socketRemote=socketRemote;
    dis=new DataInputStream(socketRemote.getInputStream());
    dos=new DataOutputStream(socketRemote.getOutputStream());
  }

  public void write(String strOut) throws Exception {
    dos.writeInt(strOut.length());
    dos.writeBytes(strOut);
  }

  public void write(String strOut[]) throws Exception {
    dos.writeInt(strOut.length);
    for(int i=0;i<strOut.length;i++)
      write(strOut[i]);
  }

  public void write(String strOut[][]) throws Exception {
    dos.writeInt(strOut.length);
    dos.writeInt(strOut[0].length);
    for(int i=0;i<strOut.length;i++) {
      for(int ia=0;ia<strOut[0].length;ia++)
        write(strOut[i][ia]);
    }
  }

  public void write(short shrtOut[][]) throws Exception {
    dos.writeInt(shrtOut.length);
    dos.writeInt(shrtOut[0].length);
    for(int i=0;i<shrtOut.length;i++) {
      for(int ia=0;ia<shrtOut[0].length;ia++)
        dos.writeShort(shrtOut[i][ia]);
    }
  }

  public void write(int intOut) throws Exception {
    dos.writeInt(intOut);
  }

  public void write(Integer intOut) throws Exception {
    dos.writeInt(intOut.intValue());
  }

  public void write(int intOut[]) throws Exception {
    dos.writeInt(intOut.length);
    for(int i=0;i<intOut.length;i++)
      dos.writeInt(intOut[i]);
  }

  public void write(int intOut[][]) throws Exception {
    dos.writeInt(intOut.length);
    dos.writeInt(intOut[0].length);
    for(int i=0;i<intOut.length;i++) {
      for(int ia=0;ia<intOut[0].length;ia++)
        dos.writeInt(intOut[i][ia]);
    }
  }

  public void write(Long lngOut) throws Exception {
    dos.writeLong(lngOut.longValue());
  }

  public void write(Long lngOut[]) throws Exception {
    dos.writeInt(lngOut.length);
    for(int i=0;i<lngOut.length;i++)
      dos.writeLong(lngOut[i].longValue());
  }

  public void write(Boolean blnOut) throws Exception {
    dos.writeBoolean(blnOut.booleanValue());
  }

  public void flush() throws Exception {
    dos.flush();
  }

  public int readInt() throws Exception {
    return dis.readInt();
  }

  public String readStr() throws Exception {
    int intLen=dis.readInt();
    byte bbuf[]=new byte[intLen];
    dis.readFully(bbuf);
    String strStr=new String(bbuf);

    return strStr;
  }

  public String[] readStrs() throws Exception {
    int intStrALen=dis.readInt();
    String strStrA[]=new String[intStrALen];
    for(int i=0;i<intStrALen;i++)
      strStrA[i]=readStr();

    return strStrA;
  }

  public String[][] readStrs2() throws Exception {
    int intStrLen=dis.readInt();
    int intStr2Len=dis.readInt();
    String strStrA[][]=new String[intStrLen][intStr2Len];
    for(int i=0;i<intStrLen;i++) {
      for(int ia=0;ia<intStr2Len;ia++)
        strStrA[i][ia]=readStr();
    }

    return strStrA;
  }

  public short[][] readShrts2() throws Exception {
    int intShrtLen=dis.readInt();
    int intShrt2Len=dis.readInt();
    short shrtShrtA[][]=new short[intShrtLen][intShrt2Len];
    for(int i=0;i<intShrtLen;i++) {
      for(int ia=0;ia<intShrt2Len;ia++)
        shrtShrtA[i][ia]=dis.readShort();
    }

    return shrtShrtA;
  }

  public int[] readInts() throws Exception {
    int intIn[]=new int[dis.readInt()];
    for(int i=0;i<intIn.length;i++)
     intIn[i]=dis.readInt();

    return intIn;
  }

  public int[][] readInts2() throws Exception {
    int intFirstLen=dis.readInt();
    int intSecondLen=dis.readInt();
    int intIn[][]=new int[intFirstLen][intSecondLen];
    for(int i=0;i<intFirstLen;i++) {
      for(int ia=0;ia<intSecondLen;ia++)
        intIn[i][ia]=dis.readInt();
    }

    return intIn;
  }

  public Long[] readLongs() throws Exception {
    int intLongALen=dis.readInt();
    Long lngIn[]=new Long[intLongALen];
    for(int i=0;i<intLongALen;i++)
      lngIn[i]=new Long(dis.readLong());

    return lngIn;
  }

  public void run() {
    int intReceiveMethod=-1;

    try {
      while(keepRunning) {
        intReceiveMethod=dis.readInt();


        if(intReceiveMethod==InventoryServerRemote.INIT_ADMIN) {
          receiver.initAdmin();
        }
        else if(intReceiveMethod==InventoryServerRemote.INIT_MASTER) {
          receiver.initMaster();
        }
        else if(intReceiveMethod==InventoryServerRemote.LOGOUT_NOW) {
          receiver.logoutNow();
        }
        else if(intReceiveMethod==InventoryServerRemote.SHUTDOWN_WARNING) {
          Integer intMinutes=new Integer(readInt());

          receiver.shutdownWarning(intMinutes);
        }
      }

      socketRemote.close();
    }
    catch(Exception ex) {
      ex.printStackTrace();

      try {
        socketRemote.close();
      }
      catch(Exception ex2) {
      }

      receiver.iFrame.logoutNow();
    }
  }
}