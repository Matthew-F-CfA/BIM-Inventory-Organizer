package bim;

public class InventoryReceiver {
  volatile InventoryFrame iFrame;

  public InventoryReceiver() {
    super();
//    this.charFrame=charFrame;
  }

  public InventoryFrame getFrame() {
    return iFrame;
  }

  public void setFrame(InventoryFrame iFrame) {
    this.iFrame=iFrame;
  }
  
  public void initAdmin() {
    iFrame.initializeAdmin();
  }

  public void initMaster() {
    iFrame.initializeMaster();
  }

  public void logoutNow() {
    try {

      iFrame.serveThread.keepRunning=false;

synchronized(iFrame.thRemote.syncOut) {
      iFrame.thRemote.socketRemote.close();
}

//      iFrame.dispose();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }

    System.exit(0);
  }

  public void shutdownWarning(Integer intMinutes) {
    try {

      InventoryFrame.MessageDialog mDialog=iFrame.new MessageDialog(iFrame, "Shutdown Warning", "Server will shutdown in "+intMinutes.toString()+" minutes.");
      iFrame.new DialogStarter(mDialog).start();

    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
}