package bim;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;

class TransferableItem implements Transferable {
  protected static DataFlavor itemFlavor = new DataFlavor(InventoryItem.class, "An Inventory Item Object");
  protected static DataFlavor[] supportedFlavors = { itemFlavor };
  InventoryItem item;

  public TransferableItem(InventoryItem item) {
    this.item = item;
  }

  public DataFlavor[] getTransferDataFlavors() {
    return supportedFlavors;
  }

  public boolean isDataFlavorSupported(DataFlavor flavor) {
    if (flavor.equals(itemFlavor))
      return true;
    return false;
  }

  public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException {
    if (flavor.equals(itemFlavor))
      return item;
    else
      throw new UnsupportedFlavorException(flavor);
  }
}
