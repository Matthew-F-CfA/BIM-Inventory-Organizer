package bim;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

class RemoteStarter extends Frame
implements ActionListener {
  Dimension screenDim;
  Button btnGenerate=new Button("Generate User");
  Button btnLogIn=new Button("Log In");
  TextField serverTF=new TextField(40);
  TextField portTF=new TextField(40);

  public static void main(String args[]) {
    RemoteStarter lStart=new RemoteStarter();
    lStart.screenDim=Toolkit.getDefaultToolkit().getScreenSize();
    lStart.setLocation(lStart.screenDim.width/4, lStart.screenDim.height/4);
    lStart.setSize(lStart.screenDim.width/2, lStart.screenDim.height/2);
    lStart.setVisible(true);
  }

  RemoteStarter() {
    super();
    setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB));
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });
    Panel tempPan2=new Panel();
    tempPan2.setLayout(new GridLayout(2, 2));
    tempPan2.add(new Label("Remote Server:"));
    tempPan2.add(serverTF);
    tempPan2.add(new Label("Port Number:"));
    tempPan2.add(portTF);
    add("North", tempPan2);
    Panel tempPan=new Panel();
    tempPan.add(btnGenerate);
    btnGenerate.addActionListener(this);
    tempPan.add(btnLogIn);
    btnLogIn.addActionListener(this);
    add("Center", tempPan);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnGenerate) {
      String strPortNumber=portTF.getText();
      int intPortNumber=-1;
      try {
        intPortNumber=Integer.parseInt(strPortNumber);
      }
      catch(Exception ex) {
        portTF.setText("Error. Digits only.");
        try {
          Thread.sleep(4000);
        }
        catch(Exception ex2) {
        }
        portTF.setText(strPortNumber);
        return;
      }
      try {
        UserBuilder userBuild=new UserBuilder(serverTF.getText(), intPortNumber);
        userBuild.setLocation(screenDim.width/4, screenDim.height/4);
        userBuild.setSize(screenDim.width/2, screenDim.height/2);
        userBuild.setVisible(true);
        setVisible(false);
        dispose();
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
    else if(evSource==btnLogIn) {
      String strPortNumber=portTF.getText();
      int intPortNumber=-1;
      try {
        intPortNumber=Integer.parseInt(strPortNumber);
      }
      catch(Exception ex) {
        portTF.setText("Error. Digits only.");
        try {
          Thread.sleep(4000);
        }
        catch(Exception ex2) {
        }
        portTF.setText(strPortNumber);
        return;
      }

      try {
        LoginFrame lFrame=new LoginFrame(serverTF.getText(), intPortNumber);
        lFrame.setLocation(0, 0);
        lFrame.setSize(screenDim.width, screenDim.height-40);
        lFrame.setVisible(true);
        setVisible(false);
        dispose();
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
  }
}