package bim;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

class UserBuilder extends Frame
implements ActionListener {
  TextField txtName=new TextField();
  TextField txtPass=new TextField();
  TextField txtEmail=new TextField();
  Button btnCreate=new Button("Create");
  Button btnCancel=new Button("Cancel");
  String strServerName;
  int intPortNumber=-1;

  UserBuilder(String strServerName, int intPortNumber) {
    super("Create User");
    this.strServerName=strServerName;
    this.intPortNumber=intPortNumber;

    Panel tempPan=new Panel();
    tempPan.setLayout(new GridLayout(3, 2));
    tempPan.add(new Label("Name:"));
    tempPan.add(txtName);
    tempPan.add(new Label("Password:"));
    tempPan.add(txtPass);
    tempPan.add(new Label("E-mail:"));
    tempPan.add(txtEmail);
    add("North", tempPan);
    add("Center", new Label(""));
    Panel tempPan2=new Panel();
    tempPan2.add(btnCreate);
    btnCreate.addActionListener(this);
    tempPan2.add(btnCancel);
    btnCancel.addActionListener(this);
    add("South", tempPan2);

    Dimension screenDim=Toolkit.getDefaultToolkit().getScreenSize();
    setLocation(screenDim.width/4, screenDim.height/4);
    setSize(screenDim.width/2, screenDim.height/2);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnCreate) {
      String strName=txtName.getText();
      if(strName.length()==0) {
        txtName.setText("Name required.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex) {
        }
        txtName.setText("");

        return;
      }

      if(strName.length()>25) {
        txtName.setText("Name can't be more than 25 characters.");
        try {
          Thread.sleep(4000);
        }
        catch(Exception ex) {
        }
        txtName.setText("");

        return;
      }

      String strPass=txtPass.getText();
      if(strPass.length()==0) {
        txtPass.setText("Password required.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex) {
        }
        txtPass.setText("");

        return;
      }

      if(strPass.length()>25) {
        txtPass.setText("Password can't be more than 25 characters.");
        try {
          Thread.sleep(4000);
        }
        catch(Exception ex) {
        }
        txtPass.setText("");

        return;
      }

      String strEmail=txtEmail.getText();
      if(strEmail.length()==0) {
        txtEmail.setText("E-mail required.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex) {
        }
        txtEmail.setText("");

        return;
      }

      if(strEmail.length()>25) {
        txtEmail.setText("E-mail can't be more than 25 characters.");
        try {
          Thread.sleep(4000);
        }
        catch(Exception ex) {
        }
        txtEmail.setText("");

        return;
      }

      if(strEmail.indexOf('@')==-1) {
        txtEmail.setText("E-mail must contain '@'.");
        try {
          Thread.sleep(4000);
        }
        catch(Exception ex) {
        }
        txtEmail.setText("");

        return;
      }

      try {
        Socket socket=new Socket(strServerName, intPortNumber);
        DataOutputStream dos=new DataOutputStream(socket.getOutputStream());
        DataInputStream dis=new DataInputStream(socket.getInputStream());

        dos.writeBoolean(true);

        dos.writeInt(InventoryClientRemote.CREATE_USER);
        dos.writeInt(strName.length());
        dos.writeBytes(strName);
        dos.writeInt(strPass.length());
        dos.writeBytes(strPass);
        dos.writeInt(strEmail.length());
        dos.writeBytes(strEmail);

        int intLen=dis.readInt();
        byte bbuf[]=new byte[intLen];
        dis.readFully(bbuf);
        String strStr=new String(bbuf);

        String strStatus=strStr;

        socket.close();

        if(strStatus.equals("Create user successful.")) {
          MessageDialog mDialog=new MessageDialog(this, "Create User Dialog", "Successfully created \""+strName+"\".");
          mDialog.show();
        }
        else {
          MessageDialog mDialog=new MessageDialog(this, "Create User Dialog", strStatus);
          mDialog.show();
        }
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
    else if(evSource==btnCancel) {
      System.exit(0);
    }
  }

  class MessageDialog extends Dialog
  implements ActionListener {
    Button btnClose=new Button("Close");

    MessageDialog(Frame parent, String strTitle, String strLabel) {
      super(parent, strTitle, true);

      add("Center", new Label(strLabel));
      Panel tempPan=new Panel();
      tempPan.add(btnClose);
      btnClose.addActionListener(this);
      add("South", tempPan);

      Dimension screenDim=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      dispose();
    }
  }
}