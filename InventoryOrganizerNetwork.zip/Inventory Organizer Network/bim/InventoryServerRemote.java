package bim;

import java.net.URL;
import java.util.Vector;
import java.net.Socket;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.awt.image.BufferedImage;
import java.net.SocketException;

public class InventoryServerRemote {
  volatile Socket socketRemote;
  volatile DataInputStream dis;
  volatile DataOutputStream dos;
  volatile transient Object syncOut=new Object();
  volatile InventoryUser user;
  public static int INIT_ADMIN=0;
  public static int INIT_MASTER=1;
  public static int LOGOUT_NOW=2;
  public static int SHUTDOWN_WARNING=3;

  public InventoryServerRemote() {
  }

  public InventoryServerRemote(Socket socketRemote, InventoryUser user) throws Exception {
    this.socketRemote=socketRemote;
    this.user=user;
    dos=new DataOutputStream(socketRemote.getOutputStream());
    dis=new DataInputStream(socketRemote.getInputStream());
  }

  public void write(String strOut) throws Exception {
    dos.writeInt(strOut.length());
    dos.writeBytes(strOut);
  }

  public void write(String strOut[]) throws Exception {
    dos.writeInt(strOut.length);
    for(int i=0;i<strOut.length;i++)
      write(strOut[i]);
  }

  public void write(String strOut[][]) throws Exception {
    dos.writeInt(strOut.length);
    dos.writeInt(strOut[0].length);
    for(int i=0;i<strOut.length;i++) {
      for(int ia=0;ia<strOut[0].length;ia++)
        write(strOut[i][ia]);
    }
  }

  public void write(short shrtOut[][]) throws Exception {
    dos.writeInt(shrtOut.length);
    dos.writeInt(shrtOut[0].length);
    for(int i=0;i<shrtOut.length;i++) {
      for(int ia=0;ia<shrtOut[0].length;ia++)
        dos.writeShort(shrtOut[i][ia]);
    }
  }

  public void write(int intOut) throws Exception {
    dos.writeInt(intOut);
  }

  public void write(Integer intOut) throws Exception {
    dos.writeInt(intOut.intValue());
  }

  public void write(int intOut[]) throws Exception {
    dos.writeInt(intOut.length);
    for(int i=0;i<intOut.length;i++)
      dos.writeInt(intOut[i]);
  }

  public void write(int intOut[][]) throws Exception {
    dos.writeInt(intOut.length);
    dos.writeInt(intOut[0].length);
    for(int i=0;i<intOut.length;i++) {
      for(int ia=0;ia<intOut[0].length;ia++)
        dos.writeInt(intOut[i][ia]);
    }
  }

  public void write(Long lngOut) throws Exception {
    dos.writeLong(lngOut.longValue());
  }

  public void write(Long lngOut[]) throws Exception {
    dos.writeInt(lngOut.length);
    for(int i=0;i<lngOut.length;i++)
      dos.writeLong(lngOut[i].longValue());
  }

  public void write(Boolean blnOut) throws Exception {
    dos.writeBoolean(blnOut.booleanValue());
  }

  public void flush() throws Exception {
    dos.flush();
  }

  public void initAdmin() {
synchronized(syncOut) {
    try {
      write(new Integer(INIT_ADMIN));
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }

  public void initMaster() {
synchronized(syncOut) {
    try {
      write(new Integer(INIT_MASTER));
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }

  public void logoutNow() {
synchronized(syncOut) {
    try {
      write(new Integer(LOGOUT_NOW));
      flush();
    }
    catch(Exception ex) {
      if(!(ex instanceof SocketException))
        ex.printStackTrace();
    }
}
  }

  public void shutdownWarning(Integer intMinutes) {
synchronized(syncOut) {
    try {
      write(new Integer(SHUTDOWN_WARNING));
      write(intMinutes);
      flush();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }
}