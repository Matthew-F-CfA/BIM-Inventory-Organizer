package bim;

import java.net.*;
import java.io.*;
import java.util.*;

class InventoryServer {
  volatile File passFile=new File("PassFile");
  volatile File emailFile=new File("EMail");
  volatile File adminFile=new File("AdminFile");
  volatile String backupPath="backup";
  volatile boolean keepAlive=true;
  volatile Vector vecUninitializedCliThreads=new Vector();
  volatile transient Object syncUninitializedCliThreads=new Object();
  volatile transient Object syncAdminLogFile=new Object();
  volatile File adminLogFile=new File("AdminCommandsLog.txt");
  volatile TreeMap allPassHash=new TreeMap();
  volatile TreeMap emailHash=new TreeMap();
  volatile InventoryServer refThis;
  volatile String serverBase;
  volatile String baseStr;
  volatile Vector adminVec=new Vector();
  volatile transient Object syncAdmin=new Object();
  volatile BackupThread backupThr=new BackupThread();
  volatile ShutdownThread shutdownThr;
  volatile TreeMap allUsersHash=new TreeMap();
  volatile transient Object syncUser=new Object();
  volatile Vector vecIPAddressesLoggedIn=new Vector();
  volatile CharacterSaveThread charSaveThr=new CharacterSaveThread();

  public static void main(String args[]) {
    try {
      if(args.length==0) {
        System.out.println("Usage:");
        System.out.println("  java InventoryServer <port number>");

        return;
      }

      int intPortNumber=Integer.parseInt(args[0]);

      InventoryServer server=new InventoryServer();

      ServerSocket serveSock=new ServerSocket(intPortNumber);
      while(server.keepAlive) {
        try {
          Socket clientSocket=serveSock.accept();

          DataInputStream dis=new DataInputStream(clientSocket.getInputStream());
          DataOutputStream dos=new DataOutputStream(clientSocket.getOutputStream());

          Boolean blnCreate=dis.readBoolean();

          if(blnCreate) {
            InventoryClientThread iThr=new InventoryClientThread(server, clientSocket, dis, dos);
            iThr.start();
          }
          else {
            int intLen=dis.readInt();
            byte bbuf[]=new byte[intLen];
            dis.readFully(bbuf);
            String strStr=new String(bbuf);

            String strUserName=strStr;

            String fSep=System.getProperty("file.separator");
            File fileLoad=new File("users"+fSep+strUserName);
            ObjectInputStream ois2=new ObjectInputStream(new FileInputStream(fileLoad));
            InventoryUser user=(InventoryUser)ois2.readObject();
            ois2.close();

            InventoryClientThread iThr=new InventoryClientThread(server, user, clientSocket, dis, dos);
            iThr.start();

synchronized(server.syncUninitializedCliThreads) {
            server.vecUninitializedCliThreads.addElement(iThr);
}
          }
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }        
      }      
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  InventoryServer() {
    super();
    this.refThis=this;

    try {
      System.out.println("Initializing files...");
      serverBase=new File(System.getProperty("user.dir")).toURL().toString();  
      String serverURLS=serverBase;
      if(!serverBase.endsWith("/"))
        serverBase+="/";
      String baseStr=new URL(serverURLS).getFile();
      String fileSep=System.getProperty("file.separator");
      baseStr=new File(baseStr).getAbsolutePath();
      if(!baseStr.endsWith(fileSep))
        baseStr+=fileSep;
      passFile=new File(String.valueOf(baseStr+passFile.getName()));
      emailFile=new File(String.valueOf(baseStr+emailFile.getName()));
      adminFile=new File(String.valueOf(baseStr+adminFile.getName()));
      backupPath=baseStr+backupPath+fileSep;
      System.out.println("Initializing pass's...");
      initPass();

      System.out.println("Initializing processes...");
      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(adminFile));
      adminVec=(Vector)ois.readObject();
      ois.close();

      charSaveThr.start();

      backupThr.start();

      System.out.println("Server Up!!");
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public void initPass() throws Exception {
    ObjectInputStream ois=new ObjectInputStream(new FileInputStream(passFile));
    allPassHash=(TreeMap)ois.readObject();
    ois.close();
  }

  public void initEmail() throws Exception {
    ObjectInputStream ois=new ObjectInputStream(new FileInputStream(emailFile));
    emailHash=(TreeMap)ois.readObject();
    ois.close();
  }

  public String createUser(String strUserName, String strPassword, String strEmail) {
    String strRet="";

    try {
      String fSep=System.getProperty("file.separator");
      File fileSave=new File("users"+fSep+strUserName);
      if(fileSave.exists()) {
        return "User already exists. Please choose another name.";
      }

      InventoryUser user=new InventoryUser(strUserName, strPassword, strEmail);

      ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileSave));
      oos.writeObject(user);
      oos.close();

      allPassHash.put(strUserName, strPassword);
      oos=new ObjectOutputStream(new FileOutputStream(passFile));
      oos.writeObject(allPassHash);
      oos.close();


      strRet="Create user successful.";
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }

    return strRet;
  }

  public String logIn(InventoryUser user, Socket cliSock, String name, String strPassword, String strClientAddress, Integer intClientPort) {
    if(shutdownThr!=null) {
      if(shutdownThr.shutdownPointOfNoReturn)
        return "Can't login. Server is shutting down.";
    }

    if(!allPassHash.containsKey(name))
      return "Error. Character name not found.";
    String thPass=String.valueOf(allPassHash.get(name));
    if(!thPass.equals(strPassword))
      return "Error. Incorrect password.";

synchronized(syncUser) {

    InventoryUser user0=(InventoryUser)allUsersHash.get(name);
    if(user0!=null)
      logoutNow(user0);

}


synchronized(vecIPAddressesLoggedIn) {

    String strHostAddress=cliSock.getInetAddress().getHostAddress();

    if(vecIPAddressesLoggedIn.contains(strHostAddress)) {
      return "Error. Only one client per ip address allowed.";
    }

}


    try {
synchronized(syncUser) {

      if(user.getCharacterBanTime()>System.currentTimeMillis())
        return "Error. Character is banned.";


      user.thContext=this;


      Socket socketRemote=new Socket(strClientAddress, intClientPort.intValue());

      InventoryServerRemote serveRemote=new InventoryServerRemote(socketRemote, user);

      user.lastLoginTime=new Long(System.currentTimeMillis());
      user.setRemote(serveRemote);


      InventoryClientThread currThr=(InventoryClientThread)Thread.currentThread();
      user.setCliThread(currThr);
      removeVecUninitClientThread();

      if(String.valueOf(adminVec.elementAt(0)).equals(user.strName)) {
        user.setIsAdmin(true);
        serveRemote.initMaster();
      }
      else {
synchronized(syncAdmin) {
        for(int i=1;i<adminVec.size();i++) {
          if(user.strName.equals(String.valueOf(adminVec.elementAt(i)))) {
            user.setIsAdmin(true);
            serveRemote.initAdmin();
            break;
          }
        }
}
      }

      allUsersHash.put(name, user);


//syncUser end
}

    }
    catch(Exception ex) {
      ex.printStackTrace();

      logoutNow(user);

      return "Error. "+String.valueOf(ex);
    }


//Commented out for testing with multiple clients from localhost.
synchronized(vecIPAddressesLoggedIn) {

    String strHostAddress=cliSock.getInetAddress().getHostAddress();

    vecIPAddressesLoggedIn.addElement(strHostAddress);

}

    return "Logged in.";    
  }

  public void logoutNow(InventoryUser cliChar) {
    try {

//Commented out for testing with multiple clients from localhost.
synchronized(vecIPAddressesLoggedIn) {

      try {
        String strHostAddress=cliChar.getCliThread().socketRemote.getInetAddress().getHostAddress();

        vecIPAddressesLoggedIn.remove(strHostAddress);
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }

}


synchronized(syncUser) {
      if(allUsersHash.remove(cliChar.strName)==null)
        return;
}

      cliChar.cliThr.keepRunning=false;

      cliChar.thRemote.logoutNow();

synchronized(cliChar.thRemote.syncOut) {
      cliChar.thRemote.socketRemote.close();
}

      cliChar.save();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public void removeVecUninitClientThread() {
    Thread currThread=Thread.currentThread();
    if(currThread instanceof InventoryClientThread) {
      InventoryClientThread currThr=(InventoryClientThread)currThread;

synchronized(syncUninitializedCliThreads) {
      vecUninitializedCliThreads.remove(currThr);
}
    }
  }

  public void deleteMe(InventoryUser user) {
    try {
      String fSep=System.getProperty("file.separator");
      File fileDelete=new File("users"+fSep+user.strName);
      fileDelete.delete();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public void addAdmin(InventoryUser user, String adminName) {
    try {
synchronized(syncUser) {
synchronized(syncAdmin) {
      if(String.valueOf(adminVec.elementAt(0)).equals(user.strName)) {
        if(!adminVec.contains(adminName)) {
          adminVec.addElement(adminName);

          Object objAdmin=allUsersHash.get(adminName);
          if(objAdmin!=null) {
            InventoryUser newUserAdmin=(InventoryUser)objAdmin;
            newUserAdmin.setIsAdmin(true);
          }

          ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(adminFile));
          oos.writeObject(adminVec);
          oos.close();

          writeToAdminLogFile("addAdmin,"+user.strName+","+adminName);
        }
      }
}
}
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public void deleteAdmin(InventoryUser user, String adminName) {
    try {
synchronized(syncUser) {
synchronized(syncAdmin) {
      if(String.valueOf(adminVec.elementAt(0)).equals(user.strName)) {
        int adminInd=adminVec.indexOf(adminName);
        if(adminInd>0) {
          adminVec.removeElementAt(adminInd);

          Object objAdmin=allUsersHash.get(adminName);
          if(objAdmin!=null) {
            InventoryUser newUserAdmin=(InventoryUser)objAdmin;
            newUserAdmin.setIsAdmin(false);
          }

          ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(adminFile));
          oos.writeObject(adminVec);
          oos.close();


          writeToAdminLogFile("deleteAdmin,"+user.strName+","+adminName);
        }
      }
}
}
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public String[] viewAdmin(InventoryUser user) {
    String retStr[]=new String[0];
    try {

synchronized(syncAdmin) {
      if(String.valueOf(adminVec.elementAt(0)).equals(user.strName)) {
        retStr=new String[adminVec.size()-1];
        for(int i=0;i<retStr.length;i++)
          retStr[i]=String.valueOf(adminVec.elementAt(i+1));
      }
}
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
    return retStr;
  }

  public void forceBackupNow(InventoryUser user) {
    try {

synchronized(syncAdmin) {
      if(user.isAdmin()) {
        backupThr.backupNow=true;

        writeToAdminLogFile("forceBackupNow,"+user.strName);
      }
}

    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public String changePassword(InventoryUser user, String strOldPassword, String strNewPassword) {
    try {
      String strCharPass=(String)allPassHash.get(user.strName);

      if(!strCharPass.equals(strOldPassword))
        return "Error. Old password doesn't match.";

synchronized(allPassHash) {

      allPassHash.put(user.strName, strNewPassword);

      ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(passFile));
      oos.writeObject(allPassHash);
      oos.close();
}

      return "Password change successful.";
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }

    return "Error during password change.";
  }

  public void changeEmail(InventoryUser user, String strEmail) {
    try {

synchronized(emailHash) {

      emailHash.put(user.strName, strEmail);

      ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(emailFile));
      oos.writeObject(emailHash);
      oos.close();
}
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public void characterBan(InventoryUser user, String strCharName, Long lngBanTime) {
    try {
      boolean hasAccess=false;
synchronized(syncAdmin) {
      if(user.isAdmin())
        hasAccess=true;

      if(adminVec.contains(strCharName))
        return;
}

      if(!hasAccess)
        return;

synchronized(syncUser) {

      Object objUser=allUsersHash.get(strCharName);
      if(objUser==null) {
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream(new File("users"+System.getProperty("file.separator")+strCharName)));
        InventoryUser user0=(InventoryUser)ois.readObject();
        ois.close();

        user0.setCharacterBanTime(lngBanTime.longValue());

        user0.save();
      }
      else {
        InventoryUser user0=(InventoryUser)objUser;
        user0.setCharacterBanTime(lngBanTime.longValue());

        user0.save();
      }

}

      writeToAdminLogFile("characterBan,"+user.strName+","+strCharName+","+lngBanTime.toString());
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public void characterUnban(InventoryUser user, String strCharName) {
    try {
      boolean hasAccess=false;
synchronized(syncAdmin) {
      if(user.isAdmin())
        hasAccess=true;
}

      if(!hasAccess)
        return;

synchronized(syncUser) {

      Object objUser=allUsersHash.get(strCharName);
      if(objUser==null) {
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream(new File("users"+System.getProperty("file.separator")+strCharName)));
        InventoryUser user0=(InventoryUser)ois.readObject();
        ois.close();

        user0.setCharacterBanTime(0l);

        user0.save();
      }
      else {
        InventoryUser user0=(InventoryUser)objUser;
        user0.setCharacterBanTime(0l);

        user0.save();
      }

}

      writeToAdminLogFile("characterUnban,"+user.strName+","+strCharName);
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public void shutdownServer(InventoryUser user, Integer intMinutes) {
    try {
      boolean hasAccess=false;
synchronized(syncAdmin) {
      if(user.isAdmin())
        hasAccess=true;
}

      if(!hasAccess)
        return;

      if(shutdownThr!=null) {
        if(!shutdownThr.shutdownPointOfNoReturn) {
          shutdownThr.cancelIt=true;

          shutdownThr=new ShutdownThread(intMinutes.intValue());
          shutdownThr.start();
        }
      }
      else {
        shutdownThr=new ShutdownThread(intMinutes.intValue());
        shutdownThr.start();
      }

      writeToAdminLogFile("shutdownServer,"+user.strName+","+intMinutes.toString());
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public String[] getContainerList(InventoryUser user) {
    String strRet[]=new String[0];

    try {
      TreeMap mapInventory=user.getInventory();
      strRet=new String[mapInventory.size()];
      int intCount=0;
      Iterator iter=mapInventory.entrySet().iterator();
      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();
        strRet[intCount++]=(String)mEntry.getKey();
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }

    return strRet;
  }

  public InventoryContainer fileLoad(InventoryUser user, String strContainerName) {
    InventoryContainer invRet=null;

    try {
      invRet=user.getInventory(strContainerName);
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }

    return invRet;
  }

  public void fileSave(InventoryUser user, String strContainerName, InventoryContainer container) {
    try {
      user.setInventory(strContainerName, container);
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public void fileDelete(InventoryUser user, String strContainerName) {
    try {
      user.removeInventory(strContainerName);
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public void writeToAdminLogFile(String strMessage) {
synchronized(syncAdminLogFile) {

    try {
      RandomAccessFile raf=new RandomAccessFile(adminLogFile, "rw");
      raf.seek(adminLogFile.length());
      raf.writeBytes(strMessage);
      raf.write(13);
      raf.write(10);
      raf.close();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }

}

  }

  class CharacterSaveThread extends Thread {
    volatile boolean keepRunning=true;
    volatile boolean done=false;

    CharacterSaveThread() {
      super();
    }

    public void run() {
      int intCount=0;
      int intCountTo=30*60;
      while(keepRunning) {
        try {
          Thread.sleep(1000l);
        }
        catch(Exception ex) {
        }
        ++intCount;
        if(intCount==intCountTo) {
          intCount=0;

synchronized(syncUser) {
          try {
            Iterator iter0=allUsersHash.entrySet().iterator();
            while(iter0.hasNext()) {
              try {
                Map.Entry mEntry=(Map.Entry)iter0.next();
                InventoryUser user=(InventoryUser)mEntry.getValue();
                user.save();
              }
              catch(Exception ex) {
                ex.printStackTrace();
              }
            }
          }
          catch(Exception ex) {
            ex.printStackTrace();
          }
}


        }
      }

      done=true;
    }
  }

  class BackupThread extends Thread {
    volatile String newFolderS="";
    volatile boolean backupNow=false;
    volatile boolean keepRunning=true;
    volatile boolean done=false;
    
    BackupThread() {
      String fList[]=new File(backupPath).list();
      int newFolder=fList.length;
      newFolderS=String.valueOf(backupPath+System.getProperty("file.separator")+newFolder+System.getProperty("file.separator"));
    }

    public void backupFile(File fileRead, File fileWrite) throws Exception {
      byte byteBuf[]=new byte[100000];
      BufferedInputStream bis=new BufferedInputStream(new FileInputStream(fileRead), 100000);

      fileWrite.getParentFile().mkdirs();

      BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream(fileWrite), 100000);

      int inAvail=0;
      while(true) {
        inAvail=bis.available();
        if(inAvail<=0) {
          inAvail=bis.read();
          if(inAvail==-1)
            break;
          bos.write(inAvail);

          continue;
        }

        if(inAvail>byteBuf.length)
          inAvail=byteBuf.length;

        bis.read(byteBuf, 0, inAvail);
        bos.write(byteBuf, 0, inAvail);
      }

      bis.close();
      bos.close();
    }

    public void run() {
      int backupCount=0;
      String nextFolderS="";
      int timeCount=0;
      int timeCountTo=720*60;
      while(keepRunning) {
        while(keepRunning) {
          if(backupNow) {
            timeCount=0;
            backupNow=false;
            break;
          }
          try {
            Thread.sleep(1000l);
          }
          catch(Exception ex) {
          }
          ++timeCount;
          if(timeCount==timeCountTo) {
            timeCount=0;
            break;
          }
        }
synchronized(syncUser) {
        nextFolderS=String.valueOf(newFolderS+backupCount+System.getProperty("file.separator"));

synchronized(allPassHash) {
        try {
          backupFile(passFile, new File(nextFolderS+passFile.getName()));

          ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(passFile));
          oos.writeObject(allPassHash);
          oos.close();
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
}

synchronized(emailHash) {
        try {
          backupFile(emailFile, new File(nextFolderS+emailFile.getName()));

          ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(emailFile));
          oos.writeObject(emailHash);
          oos.close();
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
}

synchronized(syncAdmin) {
        try {
          backupFile(adminFile, new File(nextFolderS+adminFile.getName()));

          ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(adminFile));
          oos.writeObject(adminVec);
          oos.close();
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
}

        try {
          String nextSFolder2=nextFolderS+String.valueOf("users"+System.getProperty("file.separator"));

          File dirUsers=new File("users");
          File fileList[]=dirUsers.listFiles();
          for(int i=0;i<fileList.length;i++)
            backupFile(fileList[i], new File(nextSFolder2+fileList[i].getName()));


/*
          Iterator iter=allUsersHash.entrySet().iterator();
          while(iter.hasNext()) {
            Map.Entry mEntry=(Map.Entry)iter.next();
            String strUserName=(String)mEntry.getKey();
            InventoryUser user=(InventoryUser)mEntry.getValue();

            user.save();

            File nextFile=new File("users"+System.getProperty("file.separator")+strUserName);
            backupFile(nextFile, new File(nextSFolder2+strUserName));
          }
*/
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }

        try {
          new File(String.valueOf(nextFolderS+"backupdone")).createNewFile();
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
}
        ++backupCount;
      }

      done=true;
    }
  }

  class ShutdownThread extends Thread {
    volatile long lngTimeUntil5MinuteMarker=0l;
    volatile long lngTimeUntilShutdown=0l;
    volatile boolean cancelIt=false;
    volatile boolean shutdownPointOfNoReturn=false;

    ShutdownThread(int intMinutes) {
      super();

      if(intMinutes<=5) {
        lngTimeUntil5MinuteMarker=0l;
        lngTimeUntilShutdown=new Integer(intMinutes).longValue()*60000l;
      }
      else {
        lngTimeUntil5MinuteMarker=new Integer(intMinutes-5).longValue()*60000l;
        lngTimeUntilShutdown=5l*60000l;
      }
    }

    public void run() {
      try {
        Thread.sleep(lngTimeUntil5MinuteMarker);

        if(cancelIt)
          return;

        int intMinutesUntilShutdown=new Long(lngTimeUntilShutdown).intValue()/60000;

synchronized(syncUser) {

        Iterator iter=allUsersHash.entrySet().iterator();
        while(iter.hasNext()) {
          Map.Entry mEntry=(Map.Entry)iter.next();
          InventoryUser user=(InventoryUser)mEntry.getValue();

          user.thRemote.shutdownWarning(new Integer(intMinutesUntilShutdown));
        }

}

        Thread.sleep(lngTimeUntilShutdown);

        if(cancelIt)
          return;

        shutdownPointOfNoReturn=true;


synchronized(syncUser) {

        Iterator iter=allUsersHash.entrySet().iterator();
        while(iter.hasNext()) {
          Map.Entry mEntry=(Map.Entry)iter.next();
          InventoryUser user=(InventoryUser)mEntry.getValue();

          logoutNow(user);
        }

}

        charSaveThr.keepRunning=false;

        backupThr.keepRunning=false;
//        backupThr.backupNow=true;

        while(true) {
          if(charSaveThr.done)
            break;
          try {
            Thread.sleep(1000);
          }
          catch(Exception ex) {
          }
        }

        while(true) {
          if(backupThr.done)
            break;
          try {
            Thread.sleep(1000);
          }
          catch(Exception ex) {
          }
        }

        System.exit(0);
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
  }
}