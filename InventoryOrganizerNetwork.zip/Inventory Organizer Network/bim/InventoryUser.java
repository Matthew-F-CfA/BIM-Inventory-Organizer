package bim;

import java.io.*;
import java.util.TreeMap;

class InventoryUser
implements Serializable {
  volatile String strName;
  volatile String strPassword;
  volatile String strEmail;
  volatile TreeMap mapInventory=new TreeMap();
  volatile transient long lngLastClientCommandTime=0l;
  volatile transient Object syncSave=new Object();
  volatile Long characterBanTime=new Long(0l);
  volatile transient InventoryServer thContext;
  volatile Long lastLoginTime=new Long(Long.MAX_VALUE);
  volatile transient InventoryServerRemote thRemote;
  volatile transient InventoryClientThread cliThr;
  volatile transient boolean blnAdmin=false;

  InventoryUser(String strName, String strPassword) {
    this.strName=strName;
    this.strPassword=strPassword;
  }

  InventoryUser(String strName, String strPassword, String strEmail) {
    this.strName=strName;
    this.strPassword=strPassword;
    this.strEmail=strEmail;
  }

  InventoryUser(String strName, String strPassword, String strEmail, TreeMap mapInventory) {
    this.strName=strName;
    this.strPassword=strPassword;
    this.strEmail=strEmail;
    this.mapInventory=mapInventory;
  }

  public String getName() {
    return strName;
  }

  public void setName(String strName) {
    this.strName=strName;
  }

  public String getPassword() {
    return strPassword;
  }

  public void setPassword(String strPassword) {
    this.strPassword=strPassword;
  }

  public TreeMap getInventory() {
    return mapInventory;
  }

  public void setInventory(TreeMap mapInventory) {
    this.mapInventory=mapInventory;
  }

  public InventoryContainer getInventory(String strInventoryName) {
    return (InventoryContainer)mapInventory.get(strInventoryName);
  }

  public void setInventory(String strInventoryName, InventoryContainer inventoryContainer) {
    mapInventory.put(strInventoryName, inventoryContainer);
  }

  public void removeInventory(String strInventoryName) {
    mapInventory.remove(strInventoryName);
  }

  public void setLastClientCommandTime(long lngTime) {
    this.lngLastClientCommandTime=lngTime;
  }

  public long getCharacterBanTime() {
    return characterBanTime.longValue();
  }

  public void setCharacterBanTime(long lngBanTime) {
    if(lngBanTime==(-1l))
      this.characterBanTime=new Long(Long.MAX_VALUE-1l);
    else
      this.characterBanTime=new Long(System.currentTimeMillis()+lngBanTime);
  }

  public InventoryClientThread getCliThread() {
    return cliThr;
  }

  public void setCliThread(InventoryClientThread cliThr) {
    this.cliThr=cliThr;
  }

  public boolean isAdmin() {
    return blnAdmin;
  }

  public void setIsAdmin(boolean blnAdmin) {
    this.blnAdmin=blnAdmin;
  }

  public InventoryServerRemote getRemote() {
    return thRemote;
  }

  public void setRemote(InventoryServerRemote thRemote) {
    this.thRemote=thRemote;
  }

  private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
    ois.defaultReadObject();
    initializeTransients();
  }

  public void initializeTransients() {
    lngLastClientCommandTime=0l;
    syncSave=new Object();
    blnAdmin=false;
  }

  public void save() {
synchronized(syncSave) {
    try {
      String fSep=System.getProperty("file.separator");
      File fileSave=new File("users"+fSep+strName);
      ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileSave));
      oos.writeObject(this);
      oos.close();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
}
  }
}