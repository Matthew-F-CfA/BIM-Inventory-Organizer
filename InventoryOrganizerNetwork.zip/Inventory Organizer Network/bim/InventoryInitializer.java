package bim;

import java.io.*;
import java.util.TreeMap;
import java.util.Vector;

class InventoryInitializer {
  public static void main(String args[]) {
    if(args.length!=2) {
      System.out.println("Usage: ");
      System.out.println("  java InventoryInitializer <user name> <password>");

      return;
    }

    try {
      InventoryUser iUser=new InventoryUser(args[0], args[1]);
      String fSep=System.getProperty("file.separator");
      ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(new File("users"+fSep+args[0])));
      oos.writeObject(iUser);
      oos.close();

      TreeMap allPassHash=new TreeMap();
      allPassHash.put(args[0], args[1]);

      File passFile=new File("PassFile");
      oos=new ObjectOutputStream(new FileOutputStream(passFile));
      oos.writeObject(allPassHash);
      oos.close();

      Vector adminVec=new Vector();
      adminVec.addElement(args[0]);

      File adminFile=new File("AdminFile");
      oos=new ObjectOutputStream(new FileOutputStream(adminFile));
      oos.writeObject(adminVec);
      oos.close();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
}