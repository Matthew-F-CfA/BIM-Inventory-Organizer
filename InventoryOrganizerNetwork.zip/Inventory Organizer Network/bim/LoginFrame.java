package bim;

import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import java.awt.image.BufferedImage;

class LoginFrame extends Frame
implements ActionListener {
  TextField txtName=new TextField();
  TextField txtPass=new TextField();
  TextField txtServerName=new TextField();
  TextField txtPortNumber=new TextField();
  Button btnLogin=new Button("Login");
  Button btnCancel=new Button("Cancel");
  String strServerName;
  int intPortNumber=-1;
  volatile InventoryServerThread serveThread;
  volatile InventoryReceiver thReceiver=new InventoryReceiver();

  LoginFrame(String strServerName, int intPortNumber) {
    super("Create User");
    this.strServerName=strServerName;
    this.intPortNumber=intPortNumber;

    setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB));
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    txtServerName.setText(strServerName);
    txtPortNumber.setText(String.valueOf(intPortNumber));

    Panel tempPan=new Panel();
    tempPan.setLayout(new GridLayout(4, 2));
    tempPan.add(new Label("Name:"));
    tempPan.add(txtName);
    tempPan.add(new Label("Password:"));
    tempPan.add(txtPass);
    tempPan.add(new Label("Server Name:"));
    tempPan.add(txtServerName);
    tempPan.add(new Label("Port Number:"));
    tempPan.add(txtPortNumber);
    add("North", tempPan);
    add("Center", new Label(""));
    Panel tempPan2=new Panel();
    tempPan2.add(btnLogin);
    btnLogin.addActionListener(this);
    tempPan2.add(btnCancel);
    btnCancel.addActionListener(this);
    add("South", tempPan2);

    Dimension screenDim=Toolkit.getDefaultToolkit().getScreenSize();
    setLocation(screenDim.width/4, screenDim.height/4);
    setSize(screenDim.width/2, screenDim.height/2);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnLogin) {
      String strName=txtName.getText();
      if(strName.length()==0) {
        txtName.setText("Name required.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex) {
        }
        txtName.setText("");

        return;
      }

      if(strName.length()>25) {
        txtName.setText("Name can't be more than 25 characters.");
        try {
          Thread.sleep(4000);
        }
        catch(Exception ex) {
        }
        txtName.setText("");

        return;
      }

      String strPass=txtPass.getText();
      if(strPass.length()==0) {
        txtPass.setText("Password required.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex) {
        }
        txtPass.setText("");

        return;
      }

      if(strPass.length()>25) {
        txtPass.setText("Password can't be more than 25 characters.");
        try {
          Thread.sleep(4000);
        }
        catch(Exception ex) {
        }
        txtPass.setText("");

        return;
      }

      try {
        Socket socket=new Socket(strServerName, intPortNumber);
        DataOutputStream dos=new DataOutputStream(socket.getOutputStream());
        DataInputStream dis=new DataInputStream(socket.getInputStream());

        InetAddress lAddress=InetAddress.getLocalHost();


        ServerSocket serveSock;
        int intLocalPort=7000;
        while(true) {
          try {
            serveSock=new ServerSocket(intLocalPort, 0, lAddress);
            break;
          }
          catch(Exception ex) {
            ++intLocalPort;
          }
        }

        ServerSocketThread sThr=new ServerSocketThread(serveSock);
        sThr.start();

        while(true) {
          try {
            Thread.sleep(500);
          }
          catch(Exception ex) {
          }
          if(sThr.startedAccepting) {
            try {
              Thread.sleep(1000);
            }
            catch(Exception ex) {
            }

            break;
          }
        }

        InventoryFrame iFrame=new InventoryFrame("Inventory Organizer");

        thReceiver.setFrame(iFrame);

        dos.writeBoolean(false);        

        dos.writeInt(strName.length());
        dos.writeBytes(strName);

        dos.writeInt(InventoryClientRemote.LOG_IN);

        dos.writeInt(strName.length());
        dos.writeBytes(strName);
        dos.writeInt(strPass.length());
        dos.writeBytes(strPass);

        String strLocalAddress=lAddress.getHostAddress();

//        ServerSocket serveSock=new ServerSocket(0);
//        int intPortNumber=serveSock.getLocalPort();

        dos.writeInt(strLocalAddress.length());
        dos.writeBytes(strLocalAddress);
        dos.writeInt(intLocalPort);


        int intLen=dis.readInt();
        byte bbuf[]=new byte[intLen];
        dis.readFully(bbuf);
        String strStr=new String(bbuf);

        while(true) {
          try {
            Thread.sleep(200);
          }
          catch(Exception ex) {
          }
          if(serveThread!=null)
            break;
        }

        iFrame.serveThread=serveThread;

        String strStatus=strStr;
        if(strStatus.equals("Logged in.")) {
          iFrame.thRemote=new InventoryClientRemote(socket);

          iFrame.setLocation(0, 0);
          Dimension screenDim=Toolkit.getDefaultToolkit().getScreenSize();
          iFrame.setSize(screenDim.width, screenDim.height-40);
          iFrame.setVisible(true);
          setVisible(false);
          dispose();
        }
        else {
          txtName.setText(strStatus);
          Thread.sleep(4000);
          txtName.setText(strName);

          socket.close();
        }
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
    else if(evSource==btnCancel) {
      System.exit(0);
    }
  }

  class ServerSocketThread extends Thread {
    volatile ServerSocket serveSock;
    volatile boolean startedAccepting=false;

    ServerSocketThread(ServerSocket serveSock) {
      super();

      this.serveSock=serveSock;
    }

    public void run() {
      try {
        startedAccepting=true;
        Socket socketRemote=serveSock.accept();

        serveThread=new InventoryServerThread(thReceiver, socketRemote);
        serveThread.start();
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
  }
}