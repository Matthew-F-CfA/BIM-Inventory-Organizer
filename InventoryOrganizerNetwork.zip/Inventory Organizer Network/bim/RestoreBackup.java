package bim;

import java.io.*;

class RestoreBackup {

  public static void main(String args[]) {
    try {
      if(args.length!=2) {
        System.out.println("Usage: ");
        System.out.println("  java bim.RestoreBackup <index0> <index1>");
        return;
      }

      Integer.parseInt(args[0]);
      Integer.parseInt(args[1]);

      String fSep=System.getProperty("file.separator");
      String strBackupPath="backup"+fSep+args[0]+fSep+args[1]+fSep;

      if(!(new File(strBackupPath+"backupdone").exists())) {
        System.out.println("Incomplete backup. Exiting...");
        return;
      }

      File passFile=new File("PassFile");
      restoreFile(new File(strBackupPath+passFile.getName()), passFile);

      File emailFile=new File("EMail");
      restoreFile(new File(strBackupPath+emailFile.getName()), emailFile);

      File adminFile=new File("AdminFile");
      restoreFile(new File(strBackupPath+adminFile.getName()), adminFile);

      String saveUser="users";
      File fileUsers=new File(strBackupPath+saveUser);
      File fileUsers0[]=fileUsers.listFiles();
      for(int i=0;i<fileUsers0.length;i++)
        restoreFile(fileUsers0[i], new File("users"+fSep+fileUsers0[i].getName()));
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public static void restoreFile(File fileRead, File fileWrite) throws Exception {
    byte byteBuf[]=new byte[100000];
    BufferedInputStream bis=new BufferedInputStream(new FileInputStream(fileRead), 100000);

    BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream(fileWrite), 100000);

    int inAvail=0;
    while(true) {
      inAvail=bis.available();
      if(inAvail<=0) {
        inAvail=bis.read();
        if(inAvail==-1)
          break;
        bos.write(inAvail);

        continue;
      }

      if(inAvail>byteBuf.length)
        inAvail=byteBuf.length;

      bis.read(byteBuf, 0, inAvail);
      bos.write(byteBuf, 0, inAvail);
    }

    bis.close();
    bos.close();
  }
}