package bim;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.dnd.*;
import java.awt.datatransfer.*;
import javax.swing.JFileChooser;
import java.io.*;
import java.util.Vector;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Arrays;

class InventoryFrame extends Frame
implements ActionListener, DragGestureListener {
  InventoryFrame refThis;
  Dimension screenDim;
  Menu menuFile=new Menu("File");
  MenuItem menuFileSelectScrollPane=new MenuItem("Select ScrollPane");
  MenuItem menuFileSetNumberOfScrollPanes=new MenuItem("Set Number of Scroll Panes");
  MenuItem menuFileNew=new MenuItem("New");
  MenuItem menuFileResizeContainer=new MenuItem("Resize Container");
  MenuItem menuFileCloseContainer=new MenuItem("Close Container");
  MenuItem menuFileLoad=new MenuItem("Load Container");
  MenuItem menuFileSave=new MenuItem("Save Container");
  MenuItem menuFileDelete=new MenuItem("Delete Container");
  MenuItem menuFileExit=new MenuItem("Exit");
  Menu menuOptions=new Menu("User Options");
  MenuItem menuOptionsSearch=new MenuItem("Search");
  MenuItem menuOptionsCreateIngredient=new MenuItem("Create Ingredient");
  MenuItem menuOptionsCreateRecipe=new MenuItem("Create Recipe");
  MenuItem menuOptionsUseRecipe=new MenuItem("Use Recipe");
  Menu menuUser=new Menu("User");
  MenuItem menuUserChangePassword=new MenuItem("Change Password");
  MenuItem menuUserChangeEmail=new MenuItem("Change E-mail");
  MenuItem menuUserDelete=new MenuItem("Delete");
  Menu menuAdmin=new Menu("Admin");
  MenuItem menuAdminAdd=new MenuItem("Add Admin");
  MenuItem menuAdminDelete=new MenuItem("Delete Admin");
  MenuItem menuAdminView=new MenuItem("View Admin");
  Menu menuOptionsAdmin=new Menu("Admin Options");
  MenuItem menuOptionsAdminBackup=new MenuItem("Backup Server");
  MenuItem menuOptionsAdminBan=new MenuItem("Ban User");
  MenuItem menuOptionsAdminUnban=new MenuItem("Unban User");
  MenuItem menuOptionsAdminShutdown=new MenuItem("Shutdown Server");
  Hashtable hashScrollPane=new Hashtable();
  int scrollPaneCount=1;
  InventoryScrollPane inventoryScrollPane;
  String strScrollPane="Main";
  String strScrollPanes[]={strScrollPane};
  InventoryScrollPane inventoryDragAndDrop;
  DragGestureRecognizer recognizerDragAndDrop;
  int intHashCodeDragAndDrop=-1;
  DragSource dragSource=new DragSource();
  int uniqueHashCode=Integer.MIN_VALUE;
  Hashtable hashImages=new Hashtable();
  volatile InventoryClientRemote thRemote;
  volatile InventoryServerThread serveThread;

/*
  public static void main(String args[]) {
    String strTitle="Inventory Organizer - Main";
    if(args.length>0)
      strTitle="Inventory Organizer";
    InventoryFrame iFrame=new InventoryFrame(strTitle);
    iFrame.screenDim=Toolkit.getDefaultToolkit().getScreenSize();
    iFrame.setSize(iFrame.screenDim.width, iFrame.screenDim.height-40);
    iFrame.setVisible(true);

    if(args.length==0) {
      iFrame.inventoryScrollPane=new InventoryScrollPane(ScrollPane.SCROLLBARS_ALWAYS, iFrame);
      iFrame.new MyDropTargetListener(iFrame.inventoryScrollPane);
      iFrame.hashScrollPane.put("Main", iFrame.inventoryScrollPane);
    }
    else {
      int intScrollPanes=-1;
      try {
        intScrollPanes=Integer.parseInt(args[0]);
        iFrame.scrollPaneCount=intScrollPanes;
        iFrame.strScrollPanes=new String[intScrollPanes];
        for(int i=0;i<intScrollPanes;i++) {
          InventoryScrollPane iScrollPane=new InventoryScrollPane(ScrollPane.SCROLLBARS_ALWAYS, iFrame);
          iFrame.new MyDropTargetListener(iScrollPane);
          iFrame.strScrollPanes[i]=String.valueOf(i);
          iFrame.hashScrollPane.put(iFrame.strScrollPanes[i], iScrollPane);
        }
      }
      catch(Exception ex) {
        System.out.println("Error. Integer expected.");
        System.out.println("Usage:");
        System.out.println("  java InventoryFrame <number of scrollpanes>");
        System.exit(0);
      }
    }

    iFrame.initScrollPanes();
  }
*/

  InventoryFrame(String strTitle) {
    super(strTitle);
    refThis=this;
    setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB));
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        Iterator iter=hashScrollPane.entrySet().iterator();
        while(iter.hasNext()) {
          Map.Entry mEntry=(Map.Entry)iter.next();
          String strScrollPane0=(String)mEntry.getKey();
          InventoryScrollPane sPane=(InventoryScrollPane)mEntry.getValue();

          if(sPane.blnChangesMade) {
            InventoryScrollPane.ConfirmSaveDialog cDialog=sPane.new ConfirmSaveDialog(refThis, strScrollPane0);
            cDialog.show();
            if(cDialog.cancelIt)
              return;

            if(cDialog.save) {
              if(!sPane.save())
                return;
            }
          }
        }

        System.exit(0);
      }
    });

    screenDim=Toolkit.getDefaultToolkit().getScreenSize();

    inventoryScrollPane=new InventoryScrollPane(ScrollPane.SCROLLBARS_ALWAYS, this);
    new MyDropTargetListener(inventoryScrollPane);
    hashScrollPane.put("Main", inventoryScrollPane);
    strScrollPanes=new String[1];
    strScrollPanes[0]="Main";
    strScrollPane=strScrollPanes[0];
    setTitle("Inventory Organizer - "+strScrollPane);

    MenuBar mBar=new MenuBar();

    menuFile.add(menuFileSelectScrollPane);
    menuFileSelectScrollPane.addActionListener(this);
    menuFile.add(menuFileSetNumberOfScrollPanes);
    menuFileSetNumberOfScrollPanes.addActionListener(this);
    menuFile.add(menuFileNew);
    menuFileNew.addActionListener(this);
    menuFile.add(menuFileResizeContainer);
    menuFileResizeContainer.addActionListener(this);
    menuFile.add(menuFileCloseContainer);
    menuFileCloseContainer.addActionListener(this);
    menuFile.add(menuFileLoad);
    menuFileLoad.addActionListener(this);
    menuFile.add(menuFileSave);
    menuFileSave.addActionListener(this);
    menuFile.add(menuFileDelete);
    menuFileDelete.addActionListener(this);
    menuFile.add(menuFileExit);
    menuFileExit.addActionListener(this);
    mBar.add(menuFile);

    menuOptions.add(menuOptionsSearch);
    menuOptionsSearch.addActionListener(this);
    menuOptions.add(menuOptionsCreateIngredient);
    menuOptionsCreateIngredient.addActionListener(this);
    menuOptions.add(menuOptionsCreateRecipe);
    menuOptionsCreateRecipe.addActionListener(this);
    menuOptions.add(menuOptionsUseRecipe);
    menuOptionsUseRecipe.addActionListener(this);
    mBar.add(menuOptions);

    menuUser.add(menuUserChangePassword);
    menuUserChangePassword.addActionListener(this);
    menuUser.add(menuUserChangeEmail);
    menuUserChangeEmail.addActionListener(this);
//    menuUser.add(menuUserDelete);
//    menuUserDelete.addActionListener(this);
    mBar.add(menuUser);

    menuAdmin.add(menuAdminAdd);
    menuAdminAdd.addActionListener(this);
    menuAdmin.add(menuAdminDelete);
    menuAdminDelete.addActionListener(this);
    menuAdmin.add(menuAdminView);
    menuAdminView.addActionListener(this);

    menuOptionsAdmin.add(menuOptionsAdminBackup);
    menuOptionsAdminBackup.addActionListener(this);
    menuOptionsAdmin.add(menuOptionsAdminBan);
    menuOptionsAdminBan.addActionListener(this);
    menuOptionsAdmin.add(menuOptionsAdminUnban);
    menuOptionsAdminUnban.addActionListener(this);
    menuOptionsAdmin.add(menuOptionsAdminShutdown);
    menuOptionsAdminShutdown.addActionListener(this);

    setMenuBar(mBar);

    initScrollPanes();
  }

  public void initScrollPanes() {
    MenuItem mItem=menuFile.getItem(0);
    if(mItem==menuFileSelectScrollPane) {
      menuFile.remove(0);
      menuFileSelectScrollPane.removeActionListener(this);
    }

    if(scrollPaneCount>1) {
      menuFile.insert(menuFileSelectScrollPane, 0);
      menuFileSelectScrollPane.addActionListener(this);
    }

    setLayout(new GridLayout(scrollPaneCount, 1));

    removeAll();

    for(int i=0;i<strScrollPanes.length;i++)
      add((ScrollPane)hashScrollPane.get(strScrollPanes[i]));

    invalidate();
    validate();
    repaint();
  }

  public void initializeAdmin() {
    getMenuBar().add(menuOptionsAdmin);
  }

  public void initializeMaster() {
    getMenuBar().add(menuOptionsAdmin);
    getMenuBar().add(menuAdmin);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==menuFileSelectScrollPane) {
      SelectScrollPaneDialog sDialog=new SelectScrollPaneDialog(this);
      sDialog.show();
    }
    else if(evSource==menuFileSetNumberOfScrollPanes) {
      InputTextDialog iDialog=new InputTextDialog(this, "Set Number of Scroll Panes Dialog", "Number of Scroll Panes:", "Set Number");
      iDialog.show();

      if(iDialog.cancelIt)
        return;

      String strText=iDialog.getInputText();

      int intText=-1;
      try {
        intText=Integer.parseInt(strText);
      }
      catch(Exception ex) {
        return;
      }

      if(intText<1)
        return;

      Iterator iter=hashScrollPane.entrySet().iterator();
      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();
        String strScrollPane0=(String)mEntry.getKey();
        InventoryScrollPane sPane=(InventoryScrollPane)mEntry.getValue();

        if(sPane.blnChangesMade) {
          InventoryScrollPane.ConfirmSaveDialog cDialog=sPane.new ConfirmSaveDialog(refThis, strScrollPane0);
          cDialog.show();
          if(cDialog.cancelIt)
            return;

          if(cDialog.save) {
            if(!sPane.save())
              return;
          }
        }
      }

      if(intText==1) {
        inventoryScrollPane=new InventoryScrollPane(ScrollPane.SCROLLBARS_ALWAYS, this);
        new MyDropTargetListener(inventoryScrollPane);
        hashScrollPane.put("Main", inventoryScrollPane);
        strScrollPanes=new String[1];
        strScrollPanes[0]="Main";
        strScrollPane=strScrollPanes[0];
        setTitle("Inventory Organizer - "+strScrollPane);
      }
      else {
        inventoryScrollPane=null;

        scrollPaneCount=intText;
        strScrollPanes=new String[intText];
        for(int i=0;i<intText;i++) {
          InventoryScrollPane iScrollPane=new InventoryScrollPane(ScrollPane.SCROLLBARS_ALWAYS, this);
          new MyDropTargetListener(iScrollPane);
          strScrollPanes[i]=String.valueOf(i);
          hashScrollPane.put(strScrollPanes[i], iScrollPane);
        }
      }

      initScrollPanes();
    }
    else if(evSource==menuFileNew) {
      if(inventoryScrollPane==null)
        return;

      InventoryScrollPane.AddInventoryDialog aDialog=inventoryScrollPane.new AddInventoryDialog(this);
      aDialog.show();

      if(aDialog.cancelIt)
        return;

      InventoryItem item=aDialog.getItem();
      if(item instanceof InventoryContainer) {
        InventoryScrollPane.InventoryContainerSizeDialog iDialog=inventoryScrollPane.new InventoryContainerSizeDialog(this);
        iDialog.show();

        InventoryContainer container=(InventoryContainer)item;
        container.setContainerWidth(iDialog.getInputContainerWidth());
        container.setContainerHeight(iDialog.getInputContainerHeight());

        inventoryScrollPane.inventoryParent=container;
        inventoryScrollPane.inventoryParent.makeContainerFitScreen(inventoryScrollPane.getViewportSize());
        inventoryScrollPane.vecInventoryParents.removeAllElements();
        inventoryScrollPane.vecInventoryParents.addElement(inventoryScrollPane.inventoryParent);
        inventoryScrollPane.inventoryCurrent=container;
      }

      item.setHashCode(this);

      inventoryScrollPane.blnChangesMade=true;

      inventoryScrollPane.invalidate();
      inventoryScrollPane.validate();
      inventoryScrollPane.iCanv.repaint();
    }
    else if(evSource==menuFileResizeContainer) {
      if(inventoryScrollPane==null)
        return;

      if(inventoryScrollPane.inventoryParent==null)
        return;

      InventoryScrollPane.InventoryContainerSizeDialog iDialog=inventoryScrollPane.new InventoryContainerSizeDialog(this);
      iDialog.show();

      inventoryScrollPane.inventoryCurrent.setContainerWidth(iDialog.getInputContainerWidth());
      inventoryScrollPane.inventoryCurrent.setContainerHeight(iDialog.getInputContainerHeight());

      inventoryScrollPane.inventoryCurrent.makeContainerFitScreen(inventoryScrollPane.getViewportSize());

      inventoryScrollPane.invalidate();
      inventoryScrollPane.validate();
      inventoryScrollPane.iCanv.repaint();
    }
    else if(evSource==menuFileCloseContainer) {
      if(inventoryScrollPane==null)
        return;

      if(inventoryScrollPane.inventoryCurrent==inventoryScrollPane.inventoryParent)
        return;

      inventoryScrollPane.vecInventoryParents.removeElementAt(inventoryScrollPane.vecInventoryParents.size()-1);
      InventoryContainer container=(InventoryContainer)inventoryScrollPane.vecInventoryParents.elementAt(inventoryScrollPane.vecInventoryParents.size()-1);

      inventoryScrollPane.inventoryCurrent=container;
      inventoryScrollPane.invalidate();
      inventoryScrollPane.validate();
      inventoryScrollPane.iCanv.repaint();
    }
    else if(evSource==menuFileLoad) {
      if(inventoryScrollPane==null)
        return;

      if(inventoryScrollPane.blnChangesMade) {
        InventoryScrollPane.ConfirmSaveDialog cDialog=inventoryScrollPane.new ConfirmSaveDialog(this, strScrollPane);
        cDialog.show();
        if(cDialog.cancelIt)
          return;

        if(cDialog.save) {
          if(!inventoryScrollPane.save())
            return;
        }
      }

      String strItems[]=thRemote.getContainerList();

      ListDialog lDialog=new ListDialog(this, "File Load Dialog", strItems);
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      String strItem=lDialog.lstList.getSelectedItem();

      InventoryContainer container=thRemote.fileLoad(strItem);

      inventoryScrollPane.inventoryParent=container;

      inventoryScrollPane.strFileName=strItem;

      inventoryScrollPane.inventoryParent.setParent();

      inventoryScrollPane.inventoryParent.setHashCode(this);

      inventoryScrollPane.inventoryParent.makeContainerFitScreen(inventoryScrollPane.getViewportSize());

      inventoryScrollPane.blnChangesMade=false;

      inventoryScrollPane.vecInventoryParents.removeAllElements();
      inventoryScrollPane.vecInventoryParents.addElement(inventoryScrollPane.inventoryParent);
      inventoryScrollPane.inventoryCurrent=inventoryScrollPane.inventoryParent;

      inventoryScrollPane.inventoryParent.initializeImage(this);

      inventoryScrollPane.invalidate();
      inventoryScrollPane.validate();
      inventoryScrollPane.iCanv.repaint();
      
/*
      JFileChooser fDialog=new JFileChooser();
      fDialog.setCurrentDirectory(new File("."));
      fDialog.setDialogTitle("Load Inventory Dialog");
      fDialog.setMultiSelectionEnabled(false);
      fDialog.setFileSelectionMode(JFileChooser.FILES_ONLY);
      int intResp=fDialog.showOpenDialog(this);

      if(intResp!=JFileChooser.APPROVE_OPTION)
        return;

      File fileLoad=fDialog.getSelectedFile();

      try {
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileLoad));
        inventoryScrollPane.inventoryParent=(InventoryContainer)ois.readObject();
        ois.close();

        inventoryScrollPane.strFileName=fileLoad.getAbsolutePath();

        inventoryScrollPane.inventoryParent.setParent();

        inventoryScrollPane.inventoryParent.setHashCode(this);

        inventoryScrollPane.inventoryParent.makeContainerFitScreen(inventoryScrollPane.getViewportSize());

        inventoryScrollPane.blnChangesMade=false;

        inventoryScrollPane.vecInventoryParents.removeAllElements();
        inventoryScrollPane.vecInventoryParents.addElement(inventoryScrollPane.inventoryParent);
        inventoryScrollPane.inventoryCurrent=inventoryScrollPane.inventoryParent;

        inventoryScrollPane.inventoryParent.initializeImage(this);

        inventoryScrollPane.invalidate();
        inventoryScrollPane.validate();
        inventoryScrollPane.iCanv.repaint();
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
*/
    }
    else if(evSource==menuFileSave) {
      if(inventoryScrollPane==null)
        return;

      inventoryScrollPane.save();
    }
    else if(evSource==menuFileDelete) {
      String strItems[]=thRemote.getContainerList();

/*
      String strItems[]=new String[hashScrollPane.size()];
      int intCount=0;
      Iterator iter=hashScrollPane.entrySet().iterator();
      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();
        String strScrollPane0=(String)mEntry.getKey();
        strItems[intCount++]=strScrollPane0;
      }
*/

      ListDialog lDialog=new ListDialog(this, "File Delete Dialog", strItems);
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      String strItem=lDialog.lstList.getSelectedItem();

      thRemote.fileDelete(strItem);

      Iterator iter=hashScrollPane.entrySet().iterator();
      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();
        InventoryScrollPane sPane=(InventoryScrollPane)mEntry.getValue();
        if(sPane.strFileName!=null) {
          if(sPane.strFileName.equals(strItem)) {
//            if(sPane==inventoryScrollPane) {
//              setTitle("Inventory Organizer");
//              inventoryScrollPane=null;
//            }
            
            sPane.reinit();
            sPane.iCanv.repaint();
            break;
          }
        }
      }

/*
      InventoryScrollPane sPane=(InventoryScrollPane)hashScrollPane.get(strItem);
      if(inventoryScrollPane==sPane) {
        setTitle("Inventory Organizer");
        inventoryScrollPane=null;
      }

//      hashScrollPane.remove(strItem);

      sPane.reinit();
*/
    }
    else if(evSource==menuFileExit) {
      Iterator iter=hashScrollPane.entrySet().iterator();
      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();
        String strScrollPane0=(String)mEntry.getKey();
        InventoryScrollPane sPane=(InventoryScrollPane)mEntry.getValue();

        if(sPane.blnChangesMade) {
          InventoryScrollPane.ConfirmSaveDialog cDialog=sPane.new ConfirmSaveDialog(refThis, strScrollPane0);
          cDialog.show();
          if(cDialog.cancelIt)
            return;

          if(cDialog.save) {
            if(!sPane.save())
              return;
          }
        }
      }

      thRemote.logoutNow();

      System.exit(0);
    }
    else if(evSource==menuOptionsSearch) {
      if(inventoryScrollPane==null)
        return;

      InventoryScrollPane.SearchDialog sDialog=inventoryScrollPane.new SearchDialog(this);
      sDialog.show();
    }
    else if(evSource==menuOptionsCreateIngredient) {
      CreateIngredientDialog cDialog=new CreateIngredientDialog(this);
      cDialog.show();
    }
    else if(evSource==menuOptionsCreateRecipe) {
      CreateRecipeDialog cDialog=new CreateRecipeDialog(this);
      cDialog.show();
    }
    else if(evSource==menuOptionsUseRecipe) {
      Iterator iter=hashScrollPane.entrySet().iterator();
      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();
        String strScrollPane0=(String)mEntry.getKey();
        InventoryScrollPane sPane=(InventoryScrollPane)mEntry.getValue();

        if(sPane.blnChangesMade) {
          InventoryScrollPane.ConfirmSaveDialog cDialog=sPane.new ConfirmSaveDialog(refThis, strScrollPane0, true);
          cDialog.show();
          if(cDialog.cancelIt)
            return;

          if(cDialog.save) {
            if(!sPane.save())
              return;
          }
        }
      }

      UseRecipeDialog uDialog=new UseRecipeDialog(this);
      uDialog.show();
    }
    else if(evSource==menuUserChangePassword) {
      InputTextDialog tDialog=new InputTextDialog(this, "Change Password Dialog", "Old Password:", "Enter Old Password");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strOld=tDialog.getInputText();

      
      tDialog=new InputTextDialog(this, "Change Password Dialog", "New Password:", "Enter New Password");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strNew=tDialog.getInputText();


      thRemote.changePassword(strOld, strNew);
    }
    else if(evSource==menuUserChangeEmail) {
      InputTextDialog tDialog=new InputTextDialog(this, "Change E-mail Dialog", "New E-mail Address:", "Enter E-mail Address");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strEmail=tDialog.getInputText();

      thRemote.changeEmail(strEmail);
    }
    else if(evSource==menuUserDelete) {
      ConfirmDialog cDialog=new ConfirmDialog(this, "User Account Delete Confirmation Dialog", "Are you sure you want to delete this user?");
      cDialog.show();

      if(cDialog.cancelIt)
        return;

      thRemote.deleteMe();
    }
    else if(evSource==menuAdminAdd) {
      InputTextDialog tDialog=new InputTextDialog(this, "Add Admin Dialog", "New Admin Name:", "Add Now");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strAdminName=tDialog.getInputText();

      thRemote.addAdmin(strAdminName);
    }
    else if(evSource==menuAdminDelete) {
      InputTextDialog tDialog=new InputTextDialog(this, "Delete Admin Dialog", "Delete Admin Name:", "Delete Now");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strAdminName=tDialog.getInputText();

      thRemote.deleteAdmin(strAdminName);
    }
    else if(evSource==menuAdminView) {
      String strAdmin[]=thRemote.viewAdmin();

      ListDialog lDialog=new ListDialog(this, "View Admin Dialog", strAdmin, false);
      lDialog.show();
    }
    else if(evSource==menuOptionsAdminBackup) {
      thRemote.forceBackupNow();
    }
    else if(evSource==menuOptionsAdminBan) {
      InputTextDialog tDialog=new InputTextDialog(this, "User Ban Dialog", "User Name:", "Ban");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strBanName=tDialog.getInputText();

      UserBanDialog uDialog=new UserBanDialog(this);
      uDialog.show();

      if(uDialog.cancelIt)
        return;

      Long lngBanDuration=uDialog.getBanDuration();

      thRemote.characterBan(strBanName, lngBanDuration);
    }
    else if(evSource==menuOptionsAdminUnban) {
      InputTextDialog tDialog=new InputTextDialog(this, "User Unban Dialog", "User Name:", "Unban");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strBanName=tDialog.getInputText();

      thRemote.characterUnban(strBanName);
    }
    else if(evSource==menuOptionsAdminShutdown) {
      InputTextDialog tDialog=new InputTextDialog(this, "Shutdown Dialog", "Shutdown In Minutes:", "Shutdown");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strShutdownMinutes=tDialog.getInputText();

      Integer intMinutes=null;
      try {
        intMinutes=Integer.valueOf(strShutdownMinutes);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Shutdown Dialog", "Error. Shutdown minutes must be digits only.");
        mDialog.show();

        return;
      }

      thRemote.shutdownServer(intMinutes);
    }
  }

  public void dragGestureRecognized(DragGestureEvent event) {
    Cursor cursor = null;
    InventoryScrollPane panel = (InventoryScrollPane) ((InventoryScrollPane.InventoryCanvas)event.getComponent()).getParent();

    if (event.getDragAction() == DnDConstants.ACTION_COPY) {
      cursor = DragSource.DefaultCopyDrop;
    }
    if(panel.inventoryMoving==null)
      return;

    event.startDrag(cursor, new TransferableItem(panel.inventoryMoving));
  }

  public void logoutNow() {
    try {
      thRemote.logoutNow();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }

    System.exit(0);
  }

  class SelectScrollPaneDialog extends Dialog
  implements ActionListener {
    List lstChoices=new List(5);
    Button btnSelect=new Button("Select");
    TextField txtName=new TextField();
    Button btnRename=new Button("Rename ScrollPane");

    SelectScrollPaneDialog(Frame parent) {
      super(parent, "Select Scroll Pane Dialog", true);

      for(int i=0;i<strScrollPanes.length;i++)
        lstChoices.add(strScrollPanes[i]);

      add("Center", lstChoices);
      Panel tempPan=new Panel();
      tempPan.setLayout(new GridLayout(2, 1));
      Panel tempPanA=new Panel();
      tempPanA.add(btnSelect);
      btnSelect.addActionListener(this);
      tempPan.add(tempPanA);
      Panel tempPanB=new Panel();
      tempPanB.setLayout(new BorderLayout());
      tempPanB.add("West", new Label("Name:"));
      tempPanB.add("Center", txtName);
      tempPanB.add("East", btnRename);
      btnRename.addActionListener(this);
      tempPan.add(tempPanB);
      add("South", tempPan);

      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnSelect) {
        int intSelIndex=lstChoices.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        InventoryScrollPane inventoryScrollPane2=inventoryScrollPane;

        strScrollPane=lstChoices.getItem(intSelIndex);
        inventoryScrollPane=(InventoryScrollPane)hashScrollPane.get(strScrollPane);

        if(inventoryScrollPane2!=null)
          inventoryScrollPane2.iCanv.repaint();
        inventoryScrollPane.iCanv.repaint();

        refThis.setTitle("Inventory Organizer - "+strScrollPane);

        dispose();
      }
      else if(evSource==btnRename) {
        int intSelIndex=lstChoices.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        String strName=txtName.getText();
        if(strName.length()==0) {
          txtName.setText("Name required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex) {
          }
          txtName.setText("");

          return;
        }

        if(hashScrollPane.containsKey(strName))
          return;

        String strPrevName=lstChoices.getItem(intSelIndex);

        lstChoices.remove(intSelIndex);
        lstChoices.add(strName, intSelIndex);
        strScrollPanes[intSelIndex]=strName;

        hashScrollPane.put(strName, hashScrollPane.remove(strPrevName));
      }
    }
  }

  class MyDropTargetListener extends DropTargetAdapter {
    private DropTarget dropTarget;
    private InventoryScrollPane panel;

    public MyDropTargetListener(InventoryScrollPane panel) {
      this.panel = panel;
      dropTarget = new DropTarget(panel, DnDConstants.ACTION_COPY, this, true, null);
    }

    public void drop(DropTargetDropEvent event) {
      if(recognizerDragAndDrop==null) {
        event.rejectDrop();
        return;
      }

      recognizerDragAndDrop.removeDragGestureListener(refThis);
      recognizerDragAndDrop=null;
      try {
        Transferable tr = event.getTransferable();
        InventoryItem item = (InventoryItem) tr.getTransferData(TransferableItem.itemFlavor);
        if (event.isDataFlavorSupported(TransferableItem.itemFlavor)) {
          if(this.panel.inventoryParent==null) {
            event.rejectDrop();
            return;
          }

          if(this.panel==inventoryDragAndDrop) {
            event.rejectDrop();
            return;
          }

          if(this.panel.inventoryCurrent==null) {
            event.rejectDrop();
            return;
          }

          event.acceptDrop(DnDConstants.ACTION_COPY);
          item.setHashCode(intHashCodeDragAndDrop);
          inventoryDragAndDrop.dragAndDropRemove(item);
//          inventoryDragAndDrop.blnMovingInventory=false;
          Point pLoc=event.getLocation();
          item.setX((int)pLoc.getX());
          item.setY((int)pLoc.getY());
          this.panel.dragAndDropAdd(item);
          event.dropComplete(true);
          return;
        }
        event.rejectDrop();
      } catch (Exception e) {
        e.printStackTrace();
        event.rejectDrop();
      }
    }
  }

  class CreateIngredientDialog extends Dialog
  implements ActionListener, ItemListener {
    TextField txtName=new TextField();
    TextArea txtDescription=new TextArea(5, 100);
    TextField txtWeight=new TextField();
    List lstIngredients=new List(5);
    TextArea txtDetails=new TextArea(5, 100);
    Button btnCreateIngredient=new Button("Create Ingredient");
    Button btnDeleteIngredient=new Button("Delete Ingredient");
    Button btnDone=new Button("Done");

    CreateIngredientDialog(Frame parent) {
      super(parent, "Create Ingredient Dialog", true);

      String strList[]=new File("ingredients").list();
      Arrays.sort(strList);
      for(int i=0;i<strList.length;i++)
        lstIngredients.add(strList[i]);

      Panel tempPanZ=new Panel();
      tempPanZ.setLayout(new BorderLayout());

      Panel tempPan=new Panel();
      tempPan.setLayout(new GridLayout(3, 2));
      tempPan.add(new Label("Name: "));
      tempPan.add(txtName);
      tempPan.add(new Label("Weight: ")); 
      tempPan.add(txtWeight);
      tempPan.add(new Label("Description:"));
      tempPan.add(new Label(""));
      tempPanZ.add("North", tempPan);
      tempPanZ.add("Center", txtDescription);
      add("North", tempPanZ);

      Panel tempPanZ2=new Panel();
      tempPanZ2.setLayout(new GridLayout(2, 1));

      Panel tempPan2=new Panel();
      tempPan2.setLayout(new BorderLayout());
      tempPan2.add("North", new Label("Ingredients:"));
      tempPan2.add("Center", lstIngredients);
      lstIngredients.addItemListener(this);
      tempPanZ2.add(tempPan2);
      Panel tempPan4=new Panel();
      tempPan4.setLayout(new BorderLayout());
      tempPan4.add("North", new Label("Details:"));
      tempPan4.add("Center", txtDetails);
      tempPanZ2.add(tempPan4);
      add("Center", tempPanZ2);

      Panel tempPan3=new Panel();
      tempPan3.add(btnCreateIngredient);
      btnCreateIngredient.addActionListener(this);
      tempPan3.add(btnDeleteIngredient);
      btnDeleteIngredient.addActionListener(this); 
      tempPan3.add(btnDone);
      btnDone.addActionListener(this);
      add("South", tempPan3);

      setLocation(screenDim.width/4, 0);
      setSize(screenDim.width/2, screenDim.height-40);
    }

    public void itemStateChanged(ItemEvent ie) {
      Object evSource=ie.getSource();

      if(evSource==lstIngredients) {
        int intSelIndex=lstIngredients.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        String fSep=System.getProperty("file.separator");
        String strFileName="ingredients"+fSep+lstIngredients.getItem(intSelIndex);
        try {
          File fileIngredient=new File(strFileName);
          ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileIngredient));
          InventoryIngredient ingredient=(InventoryIngredient)ois.readObject();
          ois.close();

          txtDetails.setText(ingredient.getDetails());
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
      }
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnCreateIngredient) {
        String strName=txtName.getText();
        if(strName.length()==0) {
          txtName.setText("Name required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex) {
          }
          txtName.setText("");

          return;
        }

        if(strName.indexOf('*')!=-1) {
          txtName.setText("Name can't contain '*'.");
          try {
            Thread.sleep(4000);
          }
          catch(Exception ex) {
          }
          txtName.setText(strName);

          return;
        }

        String fSep=System.getProperty("file.separator");
        String strFileName="ingredients"+fSep+strName;

        try {
          String strWeight=txtWeight.getText();
          if(strWeight.length()==0) {
            txtWeight.setText("Weight required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex) {
            }
            txtWeight.setText("");

            return;
          }

          int intWeight=-1;
          try {
            intWeight=Integer.parseInt(strWeight);
          }
          catch(Exception ex) {
            txtWeight.setText("Digits only.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtWeight.setText(strWeight);

            return;
          }

          if(intWeight<1) {
            txtWeight.setText("Positive digits only.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex) {
            }
            txtWeight.setText(strWeight);

            return;
          }

          strFileName+=" "+strWeight;
          File fileIngredient=new File(strFileName);
          if(fileIngredient.exists()) {
            txtName.setText("Error. Ingredient already exists.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex) {
            }
            txtName.setText(strName);

            return;
          }

          String strDescription=txtDescription.getText();

          InventoryIngredient ingredient=new InventoryIngredient(strName, strDescription, intWeight);
          ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileIngredient));
          oos.writeObject(ingredient);
          oos.close();

          String strIngredients[]=lstIngredients.getItems();
          String strIngredients2[]=new String[strIngredients.length+1];
          System.arraycopy(strIngredients, 0, strIngredients2, 0, strIngredients.length);
          strIngredients2[strIngredients.length]=strName+" "+strWeight;

          Arrays.sort(strIngredients2);

          lstIngredients.removeAll();
          for(int i=0;i<strIngredients2.length;i++)
            lstIngredients.add(strIngredients2[i]);
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
      }
      else if(evSource==btnDeleteIngredient) {
        int intSelIndex=lstIngredients.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        String fSep=System.getProperty("file.separator");
        String strFileName="ingredients"+fSep+lstIngredients.getItem(intSelIndex);
        try {
          File fileIngredient=new File(strFileName);
          fileIngredient.delete();

          lstIngredients.remove(intSelIndex);
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
      }
      else if(evSource==btnDone) {
        dispose();
      }
    }
  }

  class CreateRecipeDialog extends Dialog
  implements ActionListener, ItemListener {
    TextField txtName=new TextField();
    TextArea txtDescription=new TextArea(5, 100);
    List lstIngredients=new List(5);
    List lstAddedIngredients=new List(5);
    Button btnAddIngredient=new Button("Add Ingredient");
    Button btnRemoveIngredient=new Button("Remove Ingredient");
    List lstRecipes=new List(5);
    TextArea txtDetails=new TextArea(5, 100);
    Button btnCreateRecipe=new Button("Create Recipe");
    Button btnDeleteRecipe=new Button("Delete Recipe");
    Button btnDone=new Button("Done");

    CreateRecipeDialog(Frame parent) {
      super(parent, "Create Recipe Dialog", true);

      String strList[]=new File("ingredients").list();
      Arrays.sort(strList);
      for(int i=0;i<strList.length;i++)
        lstIngredients.add(strList[i]);

      strList=new File("recipes").list();
      Arrays.sort(strList);
      for(int i=0;i<strList.length;i++)
        lstRecipes.add(strList[i]);

      Panel tempPanZ=new Panel();
      tempPanZ.setLayout(new BorderLayout());

      Panel tempPan=new Panel();
      tempPan.setLayout(new GridLayout(2, 2));
      tempPan.add(new Label("Name: "));
      tempPan.add(txtName);
      tempPan.add(new Label("Description:"));
      tempPan.add(new Label(""));
      tempPanZ.add("North", tempPan);
      tempPanZ.add("Center", txtDescription);
      add("North", tempPanZ);

      Panel tempPanZ2=new Panel();
      tempPanZ2.setLayout(new GridLayout(4, 1));

      Panel tempPan2=new Panel();
      tempPan2.setLayout(new BorderLayout());
      tempPan2.add("North", new Label("Ingredients:"));
      tempPan2.add("Center", lstIngredients);
      tempPan2.add("South", btnAddIngredient);
      btnAddIngredient.addActionListener(this);
      tempPanZ2.add(tempPan2);
      Panel tempPan6=new Panel();
      tempPan6.setLayout(new BorderLayout());
      tempPan6.add("North", new Label("Added Ingredients:"));
      tempPan6.add("Center", lstAddedIngredients);
      tempPan6.add("South", btnRemoveIngredient);
      btnRemoveIngredient.addActionListener(this);
      tempPanZ2.add(tempPan6);
      Panel tempPan5=new Panel();
      tempPan5.setLayout(new BorderLayout());
      tempPan5.add("North", new Label("Recipes:"));
      tempPan5.add("Center", lstRecipes);
      lstRecipes.addItemListener(this);
      tempPanZ2.add(tempPan5);
      Panel tempPan4=new Panel();
      tempPan4.setLayout(new BorderLayout());
      tempPan4.add("North", new Label("Details:"));
      tempPan4.add("Center", txtDetails);
      tempPanZ2.add(tempPan4);
      add("Center", tempPanZ2);

      Panel tempPan3=new Panel();
      tempPan3.add(btnCreateRecipe);
      btnCreateRecipe.addActionListener(this);
      tempPan3.add(btnDeleteRecipe);
      btnDeleteRecipe.addActionListener(this); 
      tempPan3.add(btnDone);
      btnDone.addActionListener(this);
      add("South", tempPan3);

      setLocation(screenDim.width/4, 0);
      setSize(screenDim.width/2, screenDim.height-40);
    }

    public void itemStateChanged(ItemEvent ie) {
      Object evSource=ie.getSource();

      if(evSource==lstRecipes) {
        int intSelIndex=lstRecipes.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        String fSep=System.getProperty("file.separator");
        String strFileName="recipes"+fSep+lstRecipes.getItem(intSelIndex);
        try {
          File fileRecipe=new File(strFileName);
          ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileRecipe));
          InventoryRecipe recipe=(InventoryRecipe)ois.readObject();
          ois.close();

          txtDetails.setText(recipe.getDetails());
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
      }
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnAddIngredient) {
        int intSelIndex=lstIngredients.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        lstAddedIngredients.add(lstIngredients.getItem(intSelIndex));
      }
      else if(evSource==btnRemoveIngredient) {
        int intSelIndex=lstAddedIngredients.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        lstAddedIngredients.remove(intSelIndex);
      }
      else if(evSource==btnCreateRecipe) {
        String strName=txtName.getText();
        if(strName.length()==0) {
          txtName.setText("Name required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex) {
          }
          txtName.setText("");

          return;
        }

        String fSep=System.getProperty("file.separator");
        String strFileName="recipes"+fSep+strName;

        try {
          File fileRecipe=new File(strFileName);
          if(fileRecipe.exists()) {
            txtName.setText("Error. Recipe already exists.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex) {
            }
            txtName.setText(strName);

            return;
          }

          String strDescription=txtDescription.getText();

          String strIngredients[]=lstAddedIngredients.getItems();

          Vector vecIngredients=new Vector();
          for(int i=0;i<strIngredients.length;i++) {
            String strFileName2="ingredients"+fSep+strIngredients[i];
            try {
              File fileIngredient=new File(strFileName2);
              ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileIngredient));
              InventoryIngredient ingredient=(InventoryIngredient)ois.readObject();
              ois.close();

              vecIngredients.addElement(ingredient);
            }
            catch(Exception ex) {
              ex.printStackTrace();
            }
          }

          InventoryRecipe recipe=new InventoryRecipe(strName, strDescription, vecIngredients);
          ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileRecipe));
          oos.writeObject(recipe);
          oos.close();

          String strRecipes[]=lstRecipes.getItems();
          String strRecipes2[]=new String[strRecipes.length+1];
          System.arraycopy(strRecipes, 0, strRecipes2, 0, strRecipes.length);
          strRecipes2[strRecipes.length]=strName;

          Arrays.sort(strRecipes2);

          lstRecipes.removeAll();
          for(int i=0;i<strRecipes2.length;i++)
            lstRecipes.add(strRecipes2[i]);
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
      }
      else if(evSource==btnDeleteRecipe) {
        int intSelIndex=lstRecipes.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        String fSep=System.getProperty("file.separator");
        String strFileName="recipes"+fSep+lstRecipes.getItem(intSelIndex);
        try {
          File fileRecipe=new File(strFileName);
          fileRecipe.delete();

          lstRecipes.remove(intSelIndex);
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
      }
      else if(evSource==btnDone) {
        dispose();
      }
    }
  }

  class UseRecipeDialog extends Dialog
  implements ActionListener, ItemListener {
    Checkbox cbShowOnlyMakeable=new Checkbox("Show only with sufficient ingredients", false);
    List lstInventories=new List(5);
    Button btnAddInventory=new Button("Add Inventory");
    Button btnRemoveInventory=new Button("Remove Inventory");
    Vector vecInventories=new Vector();
    Vector vecInventoriesFileNames=new Vector();
    List lstRecipes=new List(5);
    ScrollPane scrollPane=new ScrollPane(ScrollPane.SCROLLBARS_ALWAYS);
    Panel scrollPanePan=new Panel();
    TextArea txtDetails=new TextArea(5, 100);
    TextArea txtStatus=new TextArea(5, 100);
    Button btnUseRecipe=new Button("Use Recipe");
    Button btnDone=new Button("Done");
    InventoryRecipe recipe;

    UseRecipeDialog(Frame parent) {
      super(parent, "Use Recipe Dialog", false);

      setRecipeList();

      Panel tempPan=new Panel();
      tempPan.setLayout(new BorderLayout());
      Panel tempPanB=new Panel();
      tempPanB.setLayout(new GridLayout(2, 1));
      tempPanB.add(cbShowOnlyMakeable);
      cbShowOnlyMakeable.addItemListener(this);
      tempPanB.add(new Label("Inventories:"));
      tempPan.add("North", tempPanB);
      tempPan.add("Center", lstInventories);
      Panel tempPanA=new Panel();
      tempPanA.setLayout(new GridLayout(1, 2));
      tempPanA.add(btnAddInventory);
      btnAddInventory.addActionListener(this);
      tempPanA.add(btnRemoveInventory);
      btnRemoveInventory.addActionListener(this);
      tempPan.add("South", tempPanA);
      add("North", tempPan);

      Panel tempPan2=new Panel();
      tempPan2.setLayout(new BorderLayout());
      Panel tempPan2A=new Panel();
      tempPan2A.setLayout(new BorderLayout());
      tempPan2A.add("North", new Label("Recipes:"));
      tempPan2A.add("Center", lstRecipes);
      lstRecipes.addItemListener(this);
      tempPan2.add("North", tempPan2A);
      scrollPane.add(scrollPanePan);
      tempPan2.add("Center", scrollPane);
      Panel tempPan4=new Panel();
      tempPan4.setLayout(new GridLayout(2, 1));
      Panel tempPan2B=new Panel();
      tempPan2B.setLayout(new BorderLayout());
      tempPan2B.add("North", new Label("Details:"));
      tempPan2B.add("Center", txtDetails);
      tempPan4.add(tempPan2B);
      Panel tempPan2C=new Panel();
      tempPan2C.setLayout(new BorderLayout());
      tempPan2C.add("North", new Label("Status:"));
      tempPan2C.add("Center", txtStatus);
      tempPan4.add(tempPan2C);
      tempPan2.add("South", tempPan4);
      add("Center", tempPan2);

      Panel tempPan3=new Panel();
      tempPan3.add(btnUseRecipe);
      btnUseRecipe.addActionListener(this);
      tempPan3.add(btnDone); 
      btnDone.addActionListener(this);
      add("South", tempPan3);

      setLocation(screenDim.width/4, 0);
      setSize(screenDim.width/2, screenDim.height-40);
    }

    public void setRecipeList() {
      boolean blnShowOnlyMakeable=cbShowOnlyMakeable.getState();
      if(blnShowOnlyMakeable) {
        lstRecipes.removeAll();
        String strList[]=new File("recipes").list();
        Arrays.sort(strList);

        String fSep=System.getProperty("file.separator");

        for(int iz2=0;iz2<strList.length;iz2++) {
          String strFileName="recipes"+fSep+strList[iz2];
          try {
            File fileRecipe=new File(strFileName);
            ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileRecipe));
            InventoryRecipe recipe2=(InventoryRecipe)ois.readObject();
            ois.close();

            Vector vecIngredients=recipe2.getIngredients();
            Vector vecDatePreferences=new Vector();
            for(int i=0;i<vecIngredients.size();i++)
              vecDatePreferences.addElement(new Integer(2));

/*
            Component components[]=scrollPanePan.getComponents();
            for(int i=0;i<components.length;i++) {
              Component nextComponents[]=((Container)components[i]).getComponents();
//              Label nextLab=(Label)nextComponents[0];
              Checkbox cbOldest=(Checkbox)nextComponents[1];
              Checkbox cbNewest=(Checkbox)nextComponents[2];
              Checkbox cbNeither=(Checkbox)nextComponents[3];
              if(cbOldest.getState())
                vecDatePreferences.addElement(new Integer(0));
              else if(cbNewest.getState())
                vecDatePreferences.addElement(new Integer(1));
              if(cbNeither.getState())
                vecDatePreferences.addElement(new Integer(2));
            }
*/

//            Vector vecUseParents=new Vector();
//            Vector vecUseParentsIndex=new Vector();
//            Vector vecUse=new Vector();
//            Vector vecUseWeight=new Vector();
//            Vector vecItemsNamesMatch=new Vector();
            boolean blnHasIngredients=true;
            for(int i=0;i<vecIngredients.size();i++) {
              InventoryIngredient nextIngredient=(InventoryIngredient)vecIngredients.elementAt(i);
              int nextDatePreference=((Integer)vecDatePreferences.elementAt(i)).intValue();
              int intWeightRemaining=nextIngredient.getWeight();
              Vector vecItemsNamesMatch2=new Vector();
              for(int ia=0;ia<vecInventories.size();ia++) {
                InventoryContainer nextInventory=(InventoryContainer)vecInventories.elementAt(ia);
                Vector vecItemsNamesMatch3=nextInventory.searchForItem(nextIngredient.getName(), nextDatePreference);
//                InventoryItem searchedItem=nextInventory.searchForItem(nextIngredient.getName(), nextDatePreference, vecUse);

                for(int iz=0;iz<vecItemsNamesMatch3.size();iz++)
                  vecItemsNamesMatch2.addElement(vecItemsNamesMatch3.elementAt(iz));
              }

              InventoryItem items[]=new InventoryItem[vecItemsNamesMatch2.size()];
              for(int ia=0;ia<vecItemsNamesMatch2.size();ia++)
                items[ia]=(InventoryItem)vecItemsNamesMatch2.elementAt(ia);

/*
              if(nextDatePreference==2)
                Arrays.sort(items, new InventoryItemWeightComparator());
              else if(nextDatePreference==0)
                Arrays.sort(items, new InventoryItemDateOldestComparator());
              else if(nextDatePreference==1)
                Arrays.sort(items, new InventoryItemDateNewestComparator());
*/

              for(int ia=0;ia<items.length;ia++) {
/*
                InventoryContainer nextInventory=items[ia].getParent();
                while(true) {
                  InventoryContainer nextInventory2=nextInventory.getParent();
                  if(nextInventory2==null)
                    break;
                  nextInventory=nextInventory2;
                }
*/

/*
                for(int iz=0;iz<vecInventories.size();iz++) {
                  InventoryContainer nextInventory2=(InventoryContainer)vecInventories.elementAt(iz);
                  if(nextInventory.equals(nextInventory2)) {
                    if(!vecUseParents.contains(nextInventory)) {
                      vecUseParents.addElement(nextInventory);
                      vecUseParentsIndex.addElement(new Integer(iz));
                    }
                    break;
                  }
                }
*/

//                vecUse.addElement(items[ia]);

                int intSearchedWeight=items[ia].getWeight();

                if(intSearchedWeight<intWeightRemaining) {
//                  vecUseWeight.addElement(new Integer(intSearchedWeight));
                  intWeightRemaining-=intSearchedWeight;
                  continue;
                }
                else if(intSearchedWeight>intWeightRemaining) {
//                  vecUseWeight.addElement(new Integer(intWeightRemaining));
                  intWeightRemaining=0;
                  break;
                }
                else {
//                  vecUseWeight.addElement(new Integer(intWeightRemaining));
                  intWeightRemaining=0;
                  break;
                }
              }


              if(intWeightRemaining>0) {
                blnHasIngredients=false;
                break;
              }
            }

            if(blnHasIngredients) {
              lstRecipes.add(strList[iz2]);
            }
          }
          catch(Exception ex) {
            ex.printStackTrace();
          }
        }
      }
      else {
        lstRecipes.removeAll();
        String strList[]=new File("recipes").list();
        Arrays.sort(strList);
        for(int i=0;i<strList.length;i++)
          lstRecipes.add(strList[i]);
      }
    }

    public void itemStateChanged(ItemEvent ie) {
      Object evSource=ie.getSource();

      if(evSource==cbShowOnlyMakeable) {
        setRecipeList();
      }
      else if(evSource==lstRecipes) {
        int intSelIndex=lstRecipes.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        String fSep=System.getProperty("file.separator");
        String strFileName="recipes"+fSep+lstRecipes.getItem(intSelIndex);
        try {
          File fileRecipe=new File(strFileName);
          ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileRecipe));
          recipe=(InventoryRecipe)ois.readObject();
          ois.close();

          txtDetails.setText(recipe.getDetails());

          Vector vecIngredients=recipe.getIngredients();
          scrollPanePan.removeAll();
          scrollPanePan.setLayout(new GridLayout(vecIngredients.size(), 1));
          for(int i=0;i<vecIngredients.size();i++) {
            InventoryIngredient nextIngredient=(InventoryIngredient)vecIngredients.elementAt(i);
            Panel tempPan=new Panel();
            tempPan.setLayout(new GridLayout(1, 4));
            tempPan.add(new Label(nextIngredient.getName()));
            CheckboxGroup cbg=new CheckboxGroup();
            Checkbox cbOldest=new Checkbox("Oldest", cbg, true);
            Checkbox cbNewest=new Checkbox("Newest", cbg, false);
            Checkbox cbNeither=new Checkbox("Neither", cbg, false);
            tempPan.add(cbOldest);
            tempPan.add(cbNewest);
            tempPan.add(cbNeither);
            scrollPanePan.add(tempPan);
          }

          scrollPane.invalidate();
          scrollPane.validate();
          scrollPane.repaint();
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
      }
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnAddInventory) {
/*
        JFileChooser fDialog=new JFileChooser();
        fDialog.setCurrentDirectory(new File("."));
        fDialog.setDialogTitle("Add Inventory Dialog");
        fDialog.setMultiSelectionEnabled(false);
        fDialog.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int intResp=fDialog.showOpenDialog(this);

        if(intResp!=JFileChooser.APPROVE_OPTION)
          return;

        File fileLoad=fDialog.getSelectedFile();

        try {
          ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileLoad));
          InventoryContainer container=(InventoryContainer)ois.readObject();
          ois.close();
*/
        try {
          String strItems[]=thRemote.getContainerList();

          ListDialog lDialog=new ListDialog(refThis, "Add Inventory Dialog", strItems);
          lDialog.show();

          if(lDialog.cancelIt)
            return;

          String strItem=lDialog.lstList.getSelectedItem();

          InventoryContainer container=thRemote.fileLoad(strItem);

          vecInventories.addElement(container);
          vecInventoriesFileNames.addElement(strItem);

          container.setParent();
          container.setHashCode(refThis);

          lstInventories.add(strItem);

          setRecipeList();
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
      }
      else if(evSource==btnRemoveInventory) {
        int intSelIndex=lstInventories.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        vecInventories.removeElementAt(intSelIndex);
        vecInventoriesFileNames.removeElementAt(intSelIndex);

        lstInventories.remove(intSelIndex);

        setRecipeList();
      }
      else if(evSource==btnUseRecipe) {
        int intSelIndex=lstRecipes.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        Vector vecIngredients=recipe.getIngredients();
        Vector vecDatePreferences=new Vector();
        Component components[]=scrollPanePan.getComponents();
        for(int i=0;i<components.length;i++) {
          Component nextComponents[]=((Container)components[i]).getComponents();
//          Label nextLab=(Label)nextComponents[0];
          Checkbox cbOldest=(Checkbox)nextComponents[1];
          Checkbox cbNewest=(Checkbox)nextComponents[2];
          Checkbox cbNeither=(Checkbox)nextComponents[3];
          if(cbOldest.getState())
            vecDatePreferences.addElement(new Integer(0));
          else if(cbNewest.getState())
            vecDatePreferences.addElement(new Integer(1));
          if(cbNeither.getState())
            vecDatePreferences.addElement(new Integer(2));
        }

        Vector vecUseParents=new Vector();
        Vector vecUseParentsIndex=new Vector();
        Vector vecUse=new Vector();
        Vector vecUseWeight=new Vector();
//        Vector vecItemsNamesMatch=new Vector();
        boolean blnHasIngredients=true;
        for(int i=0;i<vecIngredients.size();i++) {
          InventoryIngredient nextIngredient=(InventoryIngredient)vecIngredients.elementAt(i);
          int nextDatePreference=((Integer)vecDatePreferences.elementAt(i)).intValue();
          int intWeightRemaining=nextIngredient.getWeight();
          Vector vecItemsNamesMatch2=new Vector();
          for(int ia=0;ia<vecInventories.size();ia++) {
            InventoryContainer nextInventory=(InventoryContainer)vecInventories.elementAt(ia);
            Vector vecItemsNamesMatch3=nextInventory.searchForItem(nextIngredient.getName(), nextDatePreference);
//            InventoryItem searchedItem=nextInventory.searchForItem(nextIngredient.getName(), nextDatePreference, vecUse);

            for(int iz=0;iz<vecItemsNamesMatch3.size();iz++)
              vecItemsNamesMatch2.addElement(vecItemsNamesMatch3.elementAt(iz));

/*
            if(searchedItem==null)
              continue;
            vecUse.addElement(searchedItem);

            if(!vecUseParents.contains(nextInventory)) {
              vecUseParents.addElement(nextInventory);
              vecUseParentsIndex.addElement(new Integer(ia));
            }

            int intSearchedWeight=searchedItem.getWeight();

            if(intSearchedWeight<intWeightRemaining) {
              vecUseWeight.addElement(new Integer(intSearchedWeight));
              intWeightRemaining-=intSearchedWeight;
              --ia;
              continue;
            }
            else if(intSearchedWeight>intWeightRemaining) {
              vecUseWeight.addElement(new Integer(intWeightRemaining));
              intWeightRemaining=0;
              break;
            }
            else {
              vecUseWeight.addElement(new Integer(intWeightRemaining));
              intWeightRemaining=0;
              break;
            }
*/

          }

          InventoryItem items[]=new InventoryItem[vecItemsNamesMatch2.size()];
          for(int ia=0;ia<vecItemsNamesMatch2.size();ia++)
            items[ia]=(InventoryItem)vecItemsNamesMatch2.elementAt(ia);

          if(nextDatePreference==2)
            Arrays.sort(items, new InventoryItemWeightComparator());
          else if(nextDatePreference==0)
            Arrays.sort(items, new InventoryItemDateOldestComparator());
          else if(nextDatePreference==1)
            Arrays.sort(items, new InventoryItemDateNewestComparator());

          for(int ia=0;ia<items.length;ia++) {
            InventoryContainer nextInventory=items[ia].getParent();
            while(true) {
              InventoryContainer nextInventory2=nextInventory.getParent();
              if(nextInventory2==null)
                break;
              nextInventory=nextInventory2;
            }

            for(int iz=0;iz<vecInventories.size();iz++) {
              InventoryContainer nextInventory2=(InventoryContainer)vecInventories.elementAt(iz);
              if(nextInventory.equals(nextInventory2)) {
                if(!vecUseParents.contains(nextInventory)) {
                  vecUseParents.addElement(nextInventory);
                  vecUseParentsIndex.addElement(new Integer(iz));
                }
                break;
              }
            }

            vecUse.addElement(items[ia]);

            int intSearchedWeight=items[ia].getWeight();

            if(intSearchedWeight<intWeightRemaining) {
              vecUseWeight.addElement(new Integer(intSearchedWeight));
              intWeightRemaining-=intSearchedWeight;
              continue;
            }
            else if(intSearchedWeight>intWeightRemaining) {
              vecUseWeight.addElement(new Integer(intWeightRemaining));
              intWeightRemaining=0;
              break;
            }
            else {
              vecUseWeight.addElement(new Integer(intWeightRemaining));
              intWeightRemaining=0;
              break;
            }
          }


          if(intWeightRemaining>0) {
            txtStatus.append("Insufficient ingredients to make "+lstRecipes.getItem(intSelIndex)+".\nYou have "+(nextIngredient.getWeight()-intWeightRemaining)+" "+nextIngredient.getName()+",\nbut you need "+nextIngredient.getWeight()+".\n\n");
            blnHasIngredients=false;
          }
        }

        if(blnHasIngredients) {
          for(int i=0;i<vecUse.size();i++) {
            InventoryItem nextItem=(InventoryItem)vecUse.elementAt(i);
            int intNextWeight=nextItem.getWeight();
            int intNextUsedWeight=((Integer)vecUseWeight.elementAt(i)).intValue();
            if(intNextWeight>intNextUsedWeight) {
              nextItem.setWeight(intNextWeight-intNextUsedWeight);
            }
            else {
              nextItem.getParent().getItems().remove(nextItem);
            }
          }

          for(int i=0;i<vecUseParents.size();i++) {
            InventoryContainer container=(InventoryContainer)vecUseParents.elementAt(i);
            String strFileName=(String)vecInventoriesFileNames.elementAt(((Integer)vecUseParentsIndex.elementAt(i)).intValue());
            try {
              thRemote.fileSave(strFileName, container);

/*
              File fileParent=new File(strFileName);
              ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileParent));
              oos.writeObject(container);
              oos.close();
*/
            }
            catch(Exception ex) {
              ex.printStackTrace();
            }
          }

          txtStatus.append("You successfully made "+lstRecipes.getItem(intSelIndex)+".\n\n");

          setRecipeList();

          for(int i=0;i<vecUseParents.size();i++) {
            InventoryContainer container=(InventoryContainer)vecUseParents.elementAt(i);
            String strFileName=(String)vecInventoriesFileNames.elementAt(((Integer)vecUseParentsIndex.elementAt(i)).intValue());

            Iterator iter=hashScrollPane.entrySet().iterator();
            while(iter.hasNext()) {
              Map.Entry mEntry=(Map.Entry)iter.next();
              InventoryScrollPane sPane=(InventoryScrollPane)mEntry.getValue();
              if(sPane.inventoryParent==null)
                continue;

              if(sPane.strFileName.equals(strFileName)) {
                Vector vecContainerPath=sPane.inventoryCurrent.getParentPath();

                sPane.inventoryParent=container;

//                sPane.inventoryParent.setParent();

//                sPane.inventoryParent.setHashCode(refThis);

                sPane.inventoryParent.makeContainerFitScreen(sPane.getViewportSize());

                sPane.blnChangesMade=false;

                sPane.vecInventoryParents.removeAllElements();
                Vector vecContainerPath2=sPane.inventoryParent.getParentFromPath(vecContainerPath);
                sPane.vecInventoryParents=vecContainerPath2;
                sPane.inventoryCurrent=(InventoryContainer)vecContainerPath2.elementAt(vecContainerPath2.size()-1);
//                sPane.vecInventoryParents.addElement(sPane.inventoryParent);
//                sPane.inventoryCurrent=sPane.inventoryParent;
  
                sPane.inventoryParent.initializeImage(refThis);

                sPane.invalidate();
                sPane.validate();
                sPane.iCanv.repaint();

                break;
              }
            }
          }
          
        }
      }
      else if(evSource==btnDone) {
        dispose();
      }
    }
  }

  class MessageDialog extends Dialog
  implements ActionListener {
    Button btnClose=new Button("Close");

    MessageDialog(Frame parent, String strTitle, String strLabel) {
      super(parent, strTitle, true);

      add("Center", new Label(strLabel));
      Panel tempPan=new Panel();
      tempPan.add(btnClose);
      btnClose.addActionListener(this);
      add("South", tempPan);

      Dimension screenDim=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      dispose();
    }
  }

  class DialogStarter extends Thread {
    volatile Dialog dialogTS;

    DialogStarter(Dialog dialogTS) {
      super();
      this.dialogTS=dialogTS;
    }

    public void run() {
//synchronized(syncDialog) {
      dialogTS.show();
//}
    }
  }

  class InputTextDialog extends Dialog
  implements ActionListener {
    TextField txtInput=new TextField();
    Button btnInputText=new Button("Enter Text");
    Button btnCancel=new Button("Cancel");
    boolean cancelIt=false;

    InputTextDialog(Frame parent, String strTitle, String strLabel, String strButton) {
      super(parent, strTitle, true);

      btnInputText.setLabel(strButton);

      Panel tempPan=new Panel();
      tempPan.setLayout(new BorderLayout());
      tempPan.add("West", new Label(strLabel));
      tempPan.add("Center", txtInput);
      add("North", tempPan);

      add("Center", new Label(""));

      Panel tempPan2=new Panel();
      tempPan2.add(btnInputText);
      btnInputText.addActionListener(this);
      tempPan2.add(btnCancel);
      btnCancel.addActionListener(this);

      add("South", tempPan2);

      Dimension screenDim=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public String getInputText() {
      return txtInput.getText();
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnInputText) {
        String strInput=txtInput.getText();
        if(strInput.length()==0) {
          txtInput.setText("Input required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex) {
          }
          txtInput.setText("");

          return;
        }

        cancelIt=false;
      }
      else if(evSource==btnCancel) {
        cancelIt=true;
      }
      dispose();
    }
  }

  class ListDialog extends Dialog
  implements ActionListener {
    List lstList=new List(5);
    Button btnSelect=new Button("Select");
    Button btnCancel=new Button("Cancel");
    Button btnClose=new Button("Close");
    boolean cancelIt=false;

    ListDialog(Frame parent, String strTitle, String strItems[]) {
      this(parent, strTitle, strItems, true);
    }

    ListDialog(Frame parent, String strTitle, String strItems[], boolean selectAndCancel) {
      super(parent, strTitle, true);

      for(int i=0;i<strItems.length;i++)
        lstList.add(strItems[i]);

      add("Center", lstList);

      Panel tempPan=new Panel();
      if(selectAndCancel) {
        tempPan.add(btnSelect);
        btnSelect.addActionListener(this);
        tempPan.add(btnCancel);
        btnCancel.addActionListener(this);
      }
      else {
        tempPan.add(btnClose);
        btnClose.addActionListener(this);
      }

      add("South", tempPan);

      Dimension screenDim=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnSelect) {
        int intSelIndex=lstList.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        cancelIt=false;
      }
      else if(evSource==btnCancel) {
        cancelIt=true;
      }
      else if(evSource==btnClose) {
      }
      dispose();
    }
  }

  class ConfirmDialog extends Dialog
  implements ActionListener {
    Button btnConfirm=new Button("Confirm");
    Button btnCancel=new Button("Cancel");
    boolean cancelIt=false;

    ConfirmDialog(Frame parent, String strTitle, String strLabel) {
      super(parent, strTitle, true);

      add("Center", new Label(strLabel));

      Panel tempPan=new Panel();
      tempPan.add(btnConfirm);
      btnConfirm.addActionListener(this);
      tempPan.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", tempPan);

      setLocation(0, screenDim.height/3);
      setSize(screenDim.width, screenDim.height/3);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnConfirm) {
        cancelIt=false;
      }
      else if(evSource==btnCancel) {
        cancelIt=true;
      }
      dispose();
    }     
  }

  class UserBanDialog extends Dialog
  implements ActionListener {
    TextField txtDays=new TextField();
    TextField txtHours=new TextField();
    TextField txtMinutes=new TextField();
    Button btnBan=new Button("Ban");
    Button btnCancel=new Button("Cancel");
    boolean cancelIt=false;
    Long lngBanDuration;

    UserBanDialog(Frame parent) {
      super(parent, "User Ban Duration Dialog", true);

      Panel tempPan=new Panel();
      tempPan.setLayout(new GridLayout(3, 2));
      tempPan.add(new Label("Days:"));
      tempPan.add(txtDays);
      tempPan.add(new Label("Hours:"));
      tempPan.add(txtHours);
      tempPan.add(new Label("Minutes:"));
      tempPan.add(txtMinutes);
      add("North", tempPan);

      add("Center", new Label(""));

      Panel tempPan2=new Panel();
      tempPan2.add(btnBan);
      btnBan.addActionListener(this);
      tempPan2.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", tempPan2);

      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public Long getBanDuration() {
      return lngBanDuration;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();
 
      if(evSource==btnBan) {
        String strDays=txtDays.getText();
        long lngDays=0l;
        if(strDays.length()>0) {
          try {
            lngDays=Long.valueOf(strDays).longValue();
          }
          catch(Exception ex) {
            txtDays.setText("Error. Digits only.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDays.setText(strDays);

            return;
          }

          if(lngDays<0) {
            txtDays.setText("Error. Positive digits only.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDays.setText(strDays);

            return;
          }
        }

        String strHours=txtHours.getText();
        long lngHours=0l;
        if(strHours.length()>0) {
          try {
            lngHours=Long.valueOf(strHours).longValue();
          }
          catch(Exception ex) {
            txtHours.setText("Error. Digits only.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtHours.setText(strHours);

            return;
          }

          if(lngHours<0) {
            txtHours.setText("Error. Positive digits only.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtHours.setText(strHours);

            return;
          }
        }

        String strMinutes=txtMinutes.getText();
        long lngMinutes=0l;
        if(strMinutes.length()>0) {
          try {
            lngMinutes=Long.valueOf(strMinutes).longValue();
          }
          catch(Exception ex) {
            txtMinutes.setText("Error. Digits only.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtMinutes.setText(strMinutes);

            return;
          }

          if(lngMinutes<0) {
            txtMinutes.setText("Error. Positive digits only.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtMinutes.setText(strMinutes);

            return;
          }
        }

        lngBanDuration=new Long(System.currentTimeMillis()+(lngDays*1000l*60l*60l*24l)+(lngHours*1000l*60l*60l)+(lngMinutes*1000l*60l));

        cancelIt=false;
      }
      else if(evSource==btnCancel) {
        cancelIt=true;
      }
      dispose();
    }
  }
}