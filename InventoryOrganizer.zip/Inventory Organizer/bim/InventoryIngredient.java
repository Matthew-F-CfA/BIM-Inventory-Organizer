package bim;

import java.io.Serializable;

class InventoryIngredient
implements Serializable {
  String strName;
  String strDescription;
  Integer intWeight;

  InventoryIngredient() {
  }

  InventoryIngredient(String strName, String strDescription, int intWeight) {
    this.strName=strName;
    this.strDescription=strDescription;
    this.intWeight=new Integer(intWeight);
  }

  public String getName() {
    return strName;
  }

  public void setName(String strName) {
    this.strName=strName;
  }

  public String getDescription() {
    return strDescription;
  }

  public void setDescription(String strDescription) {
    this.strDescription=strDescription;
  }

  public int getWeight() {
    return intWeight.intValue();
  }

  public void setWeight(int intWeight) {
    this.intWeight=new Integer(intWeight);
  }

  public String getDetails() {
    String strDetails="Name: "+strName+"\nWeight: "+String.valueOf(intWeight)+"\nDescription:\n"+strDescription;
    return strDetails;
  }
}