package bim;

import java.io.Serializable;
import java.util.Vector;
import java.util.Date;
import java.awt.Rectangle;
import java.util.Arrays;
import java.util.Comparator;
import java.awt.Dimension;

class InventoryContainer extends InventoryItem
implements Serializable {
//  static int WEST=0;
//  static int EAST=1;
//  static int NORTH=2;
//  static int SOUTH=3;

  static int DEFAULT_WIDTH=2000;
  static int DEFAULT_HEIGHT=2000;

  Integer intContainerWidth;
  Integer intContainerHeight;
  Vector vecItems=new Vector();
  Rectangle vacantSpaces[]=new Rectangle[0];


  InventoryContainer() {
    this.intContainerWidth=new Integer(DEFAULT_WIDTH);
    this.intContainerHeight=new Integer(DEFAULT_HEIGHT);

    vacantSpaces=new Rectangle[1];
    vacantSpaces[0]=new Rectangle(0, 0, intContainerWidth, intContainerHeight);
  }

  InventoryContainer(int intContainerWidth, int intContainerHeight) {
    this.intContainerWidth=new Integer(intContainerWidth);
    this.intContainerHeight=new Integer(intContainerHeight);

    vacantSpaces=new Rectangle[1];
    vacantSpaces[0]=new Rectangle(0, 0, intContainerWidth, intContainerHeight);
  }

  InventoryContainer(Vector vecItems) {
    this.intContainerWidth=new Integer(DEFAULT_WIDTH);
    this.intContainerHeight=new Integer(DEFAULT_HEIGHT);

    this.vecItems=vecItems;

    vacantSpaces=new Rectangle[1];
    vacantSpaces[0]=new Rectangle(0, 0, intContainerWidth, intContainerHeight);
  }

  InventoryContainer(String strName, String strDescription, int intX, int intY, int intWidth, int intHeight, int intWeight) {
    super(strName, strDescription, intX, intY, intWidth, intHeight, intWeight);

    this.intContainerWidth=new Integer(DEFAULT_WIDTH);
    this.intContainerHeight=new Integer(DEFAULT_HEIGHT);

    vacantSpaces=new Rectangle[1];
    vacantSpaces[0]=new Rectangle(0, 0, intContainerWidth, intContainerHeight);
  }

  InventoryContainer(String strName, String strDescription, int intX, int intY, int intWidth, int intHeight, int intWeight, int intWeightMax) {
    super(strName, strDescription, intX, intY, intWidth, intHeight, intWeight, intWeightMax);

    this.intContainerWidth=new Integer(DEFAULT_WIDTH);
    this.intContainerHeight=new Integer(DEFAULT_HEIGHT);

    vacantSpaces=new Rectangle[1];
    vacantSpaces[0]=new Rectangle(0, 0, intContainerWidth, intContainerHeight);
  }

  InventoryContainer(String strName, String strDescription, int intX, int intY, int intWidth, int intHeight, int intWeight, Date dateExpiration) {
    super(strName, strDescription, intX, intY, intWidth, intHeight, intWeight, dateExpiration);

    this.intContainerWidth=new Integer(DEFAULT_WIDTH);
    this.intContainerHeight=new Integer(DEFAULT_HEIGHT);

    vacantSpaces=new Rectangle[1];
    vacantSpaces[0]=new Rectangle(0, 0, intContainerWidth, intContainerHeight);
  }
  
  InventoryContainer(String strName, String strDescription, int intX, int intY, int intWidth, int intHeight, int intWeight, int intWeightMax, Date dateExpiration) {
    super(strName, strDescription, intX, intY, intWidth, intHeight, intWeight, intWeightMax, dateExpiration);

    this.intContainerWidth=new Integer(DEFAULT_WIDTH);
    this.intContainerHeight=new Integer(DEFAULT_HEIGHT);

    vacantSpaces=new Rectangle[1];
    vacantSpaces[0]=new Rectangle(0, 0, intContainerWidth, intContainerHeight);
  }

  InventoryContainer(String strName, String strDescription, int intX, int intY, int intWidth, int intHeight, int intWeight, Date dateExpiration, Vector vecItems) {
    super(strName, strDescription, intX, intY, intWidth, intHeight, intWeight, dateExpiration);

    this.intContainerWidth=new Integer(DEFAULT_WIDTH);
    this.intContainerHeight=new Integer(DEFAULT_HEIGHT);

    this.vecItems=vecItems;

    vacantSpaces=new Rectangle[1];
    vacantSpaces[0]=new Rectangle(0, 0, intContainerWidth, intContainerHeight);
  }

  InventoryContainer(String strName, String strDescription, int intX, int intY, int intWidth, int intHeight, int intWeight, int intWeightMax, Date dateExpiration, Vector vecItems) {
    super(strName, strDescription, intX, intY, intWidth, intHeight, intWeight, intWeightMax, dateExpiration);

    this.intContainerWidth=new Integer(DEFAULT_WIDTH);
    this.intContainerHeight=new Integer(DEFAULT_HEIGHT);

    this.vecItems=vecItems;

    vacantSpaces=new Rectangle[1];
    vacantSpaces[0]=new Rectangle(0, 0, intContainerWidth, intContainerHeight);
  }

  public int getContainerWidth() {
    return intContainerWidth.intValue();
  }

  public void setContainerWidth(int intContainerWidth) {
    if(expandVacantSpacesEast(intContainerWidth))
      this.intContainerWidth=new Integer(intContainerWidth);
  }

  public int getContainerHeight() {
    return intContainerHeight.intValue();
  }

  public void setContainerHeight(int intContainerHeight) {
    if(expandVacantSpacesSouth(intContainerHeight))
      this.intContainerHeight=new Integer(intContainerHeight);
  }

  public Vector getItems() {
    return vecItems;
  }

  public void setItems(Vector vecItems) {
    this.vecItems=vecItems;
  }

  public static int[] getPathToContainer(InventoryContainer inventoryParent, Vector vecInventoryParents) {
    Vector vecPathToContainer=new Vector();

    InventoryContainer nextContainer=inventoryParent;

    for(int i=1;i<vecInventoryParents.size();i++) {
      InventoryContainer container=(InventoryContainer)vecInventoryParents.elementAt(i);
      Vector vecItems=nextContainer.getItems();
      for(int ia=0;ia<vecItems.size();ia++) {
        Object nextObj=vecItems.elementAt(ia);
        if(nextObj instanceof InventoryContainer) {
          InventoryContainer nextContainer2=(InventoryContainer)nextObj;
          if(nextContainer2==container) {
            vecPathToContainer.addElement(new Integer(ia));
            nextContainer=nextContainer2;
            break;
          }
        }
      }
    }

    int intRet[]=new int[vecPathToContainer.size()];
    for(int i=0;i<intRet.length;i++)
      intRet[i]=((Integer)vecPathToContainer.elementAt(i)).intValue();

    return intRet;
  }

  public Vector getParentFromPath(Vector vecContainerPath) {
    Vector vecRet=new Vector();

    InventoryContainer nextContainer=this;
    vecRet.addElement(this);

    for(int i=0;i<vecContainerPath.size();i++) {
      int nextInd=((Integer)vecContainerPath.elementAt(i)).intValue();
      nextContainer=(InventoryContainer)nextContainer.getItems().elementAt(nextInd);
      vecRet.addElement(nextContainer);
    }

    return vecRet;
  }

  public void setParent() {
    for(int i=0;i<vecItems.size();i++)
      ((InventoryItem)vecItems.elementAt(i)).setParent(this);
  }

  public void setParent(InventoryContainer container) {
    super.setParent(container);
    for(int i=0;i<vecItems.size();i++)
      ((InventoryItem)vecItems.elementAt(i)).setParent(this);
  }

  public void setParent2(InventoryContainer container) {
    this.container=container;
  }

  public void setParentAll() {
    for(int i=0;i<vecItems.size();i++) {
      InventoryItem item=(InventoryItem)vecItems.elementAt(i);
      if(item instanceof InventoryContainer) {
        InventoryContainer container=(InventoryContainer)item;
        container.setParent2(this);
        container.setParentAll();
      }
      else
        item.setParent(this);
    }
  }

  public boolean expandVacantSpacesEast(int intNewContainerWidth) {
    if(vacantSpaces.length>0) {
      if(intNewContainerWidth>getContainerWidth()) {
        boolean blnSingleSpace=false;
        for(int i=0;i<vacantSpaces.length;i++) {
          if((vacantSpaces[i].getX()+vacantSpaces[i].getWidth())==((double)intContainerWidth.intValue())) {
            if(vacantSpaces[i].getHeight()==getContainerHeight()) {
              vacantSpaces[i].setSize(intNewContainerWidth-((int)vacantSpaces[i].getX()), (int)vacantSpaces[i].getHeight());
              blnSingleSpace=true;
              break;
            }
            else
              vacantSpaces[i].setSize(intNewContainerWidth-((int)vacantSpaces[i].getX()), (int)vacantSpaces[i].getHeight());
          }
        }

        if(!blnSingleSpace) {
          Rectangle newVacantSpaces[]=new Rectangle[vacantSpaces.length+1];
          System.arraycopy(vacantSpaces, 0, newVacantSpaces, 0, vacantSpaces.length);
          newVacantSpaces[vacantSpaces.length]=new Rectangle(getContainerWidth(), 0, intNewContainerWidth-getContainerWidth(), getContainerHeight());
          vacantSpaces=newVacantSpaces;
        }

        Arrays.sort(vacantSpaces, new RectangleSizeComparator());
      }
      else if(intNewContainerWidth<getContainerWidth()) {
        Rectangle retractRectangle=new Rectangle(intNewContainerWidth, 0, intContainerWidth.intValue()-intNewContainerWidth, intContainerHeight.intValue());
        for(int i=0;i<vecItems.size();i++) {
          InventoryItem nextItem=(InventoryItem)vecItems.elementAt(i);
          Rectangle nextRectangle=new Rectangle(nextItem.getX(), nextItem.getY(), nextItem.getWidth(), nextItem.getHeight());
          if(retractRectangle.intersects(nextRectangle))
            return false;
        }

        Vector vecRemoveRectangles=new Vector();
        for(int i=0;i<vacantSpaces.length;i++) {
          if((vacantSpaces[i].getX()+vacantSpaces[i].getWidth())==((double)intContainerWidth.intValue())) {
            if(vacantSpaces[i].getX()>=intNewContainerWidth)
              vecRemoveRectangles.addElement(new Integer(i));
            else
              vacantSpaces[i].setSize(intNewContainerWidth-((int)vacantSpaces[i].getX()), (int)vacantSpaces[i].getHeight());
          }
        }

        Rectangle newVacantSpaces[]=new Rectangle[vacantSpaces.length-vecRemoveRectangles.size()];
        int intCountV=0;
        int intCurrentStart=0;
        for(int i=0;i<vecRemoveRectangles.size();i++) {
          int intIndex=((Integer)vecRemoveRectangles.elementAt(i)).intValue();
          for(int ia=intCurrentStart;ia<intIndex;ia++)
            newVacantSpaces[intCountV++]=vacantSpaces[ia];
          intCurrentStart=intIndex+1;
        }
        for(int ia=intCurrentStart;ia<vacantSpaces.length;ia++)
          newVacantSpaces[intCountV++]=vacantSpaces[ia];

        vacantSpaces=newVacantSpaces;

        Arrays.sort(vacantSpaces, new RectangleSizeComparator());
      }
    }
    else {
      if(intContainerHeight!=null) {
        if(intContainerHeight.intValue()>0) {
          Rectangle newRectangle=new Rectangle(0, 0, intNewContainerWidth, intContainerHeight.intValue());
          vacantSpaces=new Rectangle[1];
          vacantSpaces[0]=newRectangle;
        }
      }
    }

    return true;
  }

  public boolean expandVacantSpacesSouth(int intNewContainerHeight) {
    if(vacantSpaces.length>0) {
      if(intNewContainerHeight>getContainerHeight()) {
        boolean blnSingleSpace=false;
        for(int i=0;i<vacantSpaces.length;i++) {
          if((vacantSpaces[i].getY()+vacantSpaces[i].getHeight())==((double)intContainerHeight.intValue())) {
            if(vacantSpaces[i].getWidth()==getContainerWidth()) {
              vacantSpaces[i].setSize((int)vacantSpaces[i].getWidth(), intNewContainerHeight-((int)vacantSpaces[i].getY()));
              blnSingleSpace=true;
              break;
            }
            else
              vacantSpaces[i].setSize((int)vacantSpaces[i].getWidth(), intNewContainerHeight-((int)vacantSpaces[i].getY()));
          }
        }

        if(!blnSingleSpace) {
          Rectangle newVacantSpaces[]=new Rectangle[vacantSpaces.length+1];
          System.arraycopy(vacantSpaces, 0, newVacantSpaces, 0, vacantSpaces.length);
          newVacantSpaces[vacantSpaces.length]=new Rectangle(0, getContainerHeight(), getContainerWidth(), intNewContainerHeight-getContainerHeight());
          vacantSpaces=newVacantSpaces;
        }

        Arrays.sort(vacantSpaces, new RectangleSizeComparator());
      }
      else if(intNewContainerHeight<getContainerHeight()) {
        Rectangle retractRectangle=new Rectangle(0, intNewContainerHeight, intContainerWidth.intValue(), intContainerHeight.intValue()-intNewContainerHeight);
        for(int i=0;i<vecItems.size();i++) {
          InventoryItem nextItem=(InventoryItem)vecItems.elementAt(i);
          Rectangle nextRectangle=new Rectangle(nextItem.getX(), nextItem.getY(), nextItem.getWidth(), nextItem.getHeight());
          if(retractRectangle.intersects(nextRectangle))
            return false;
        }

        Vector vecRemoveRectangles=new Vector();
        for(int i=0;i<vacantSpaces.length;i++) {
          if((vacantSpaces[i].getY()+vacantSpaces[i].getHeight())==((double)intContainerHeight.intValue())) {
            if(vacantSpaces[i].getY()>=intNewContainerHeight)
              vecRemoveRectangles.addElement(new Integer(i));
            else
              vacantSpaces[i].setSize((int)vacantSpaces[i].getWidth(), intNewContainerHeight-((int)vacantSpaces[i].getY()));
          }
        }

        Rectangle newVacantSpaces[]=new Rectangle[vacantSpaces.length-vecRemoveRectangles.size()];
        int intCountV=0;
        int intCurrentStart=0;
        for(int i=0;i<vecRemoveRectangles.size();i++) {
          int intIndex=((Integer)vecRemoveRectangles.elementAt(i)).intValue();
          for(int ia=intCurrentStart;ia<intIndex;ia++)
            newVacantSpaces[intCountV++]=vacantSpaces[ia];
          intCurrentStart=intIndex+1;
        }
        for(int ia=intCurrentStart;ia<vacantSpaces.length;ia++)
          newVacantSpaces[intCountV++]=vacantSpaces[ia];

        vacantSpaces=newVacantSpaces;

        Arrays.sort(vacantSpaces, new RectangleSizeComparator());
      }
    }
    else {
      if(intContainerWidth!=null) {
        if(intContainerWidth.intValue()>0) {
          Rectangle newRectangle=new Rectangle(0, 0, intContainerWidth.intValue(), intNewContainerHeight);
          vacantSpaces=new Rectangle[1];
          vacantSpaces[0]=newRectangle;
        }
      }
    }

    return true;
  }

  public int[] findNewLocation(InventoryItem item) {
    int intCoords[]=new int[2];

    int i=0;
    for(;i<vacantSpaces.length;i++) {
      if(((int)vacantSpaces[i].getWidth())>=item.getWidth()) {
        if(((int)vacantSpaces[i].getHeight())>=item.getHeight()) {
          intCoords[0]=(int)vacantSpaces[i].getX();
          intCoords[1]=(int)vacantSpaces[i].getY();
          break;
        }
      }
    }

    if(i==vacantSpaces.length) {
      int intContainerWidth0=intContainerWidth;
      setContainerWidth(intContainerWidth0+item.getWidth());
      intCoords[0]=intContainerWidth0;
      intCoords[1]=0;

      if(getContainerHeight()<item.getHeight())
        setContainerHeight(item.getHeight());

/*
      Rectangle newRectangle=new Rectangle(intCoords[0], intCoords[1], intContainerWidth-intContainerWidth0, intContainerHeight);
      Rectangle newVacantSpaces[]=new Rectangle[vacantSpaces.length+1];
      newVacantSpaces[vacantSpaces.length]=newRectangle;
      vacantSpaces=newVacantSpaces;
*/

//      Arrays.sort(vacantSpaces, new RectangleSizeComparator());
    }

    addItemToContainerSpace(intCoords[0], intCoords[1], item.getWidth(), item.getHeight(), true);

    return intCoords;
  }

  public void findNewLocation2(InventoryItem item) {
    addItemToContainerSpace(item.getX(), item.getY(), item.getWidth(), item.getHeight(), true);
  }

  public void findNewLocation2(InventoryItem item, boolean doSort) {
    addItemToContainerSpace(item.getX(), item.getY(), item.getWidth(), item.getHeight(), doSort);
  }

  public void addItemToContainerSpace(int intX, int intY, int intWidth, int intHeight, boolean doSort) {
    Rectangle rectangle=new Rectangle(intX, intY, intWidth, intHeight);

    Vector vecNewRectangles=new Vector();
    Vector vecRemoveRectangles=new Vector();
    for(int i=0;i<vacantSpaces.length;i++) {
      Rectangle rectangle2=rectangle.intersection(vacantSpaces[i]);
      if(rectangle2.getWidth()>0.0d) {
        if(rectangle2.getHeight()>0.0d) {
          Rectangle newRectangles[]=divideUpSpace(vacantSpaces[i], rectangle2);
          for(int ia=0;ia<newRectangles.length;ia++)
            vecNewRectangles.addElement(newRectangles[ia]);
          vecRemoveRectangles.addElement(new Integer(i));
        }
      }
    }

    Rectangle newVacantSpaces[]=new Rectangle[vacantSpaces.length-vecRemoveRectangles.size()+vecNewRectangles.size()];
    int intCountV=0;
    int intCurrentStart=0;
    for(int i=0;i<vecRemoveRectangles.size();i++) {
      int intIndex=((Integer)vecRemoveRectangles.elementAt(i)).intValue();
      for(int ia=intCurrentStart;ia<intIndex;ia++)
        newVacantSpaces[intCountV++]=vacantSpaces[ia];
      intCurrentStart=intIndex+1;
    }
    for(int ia=intCurrentStart;ia<vacantSpaces.length;ia++)
      newVacantSpaces[intCountV++]=vacantSpaces[ia];
    for(int i=0;i<vecNewRectangles.size();i++)
      newVacantSpaces[intCountV++]=(Rectangle)vecNewRectangles.elementAt(i);

    vacantSpaces=newVacantSpaces;

    removeDuplicateRectangles();

    if(doSort)
      Arrays.sort(vacantSpaces, new RectangleSizeComparator());
  }

  public Rectangle[] divideUpSpace(Rectangle container, Rectangle contained) {
    Vector vecRectangles=new Vector();

    int intContainerX=(int)container.getX();
    int intContainerY=(int)container.getY();
    int intContainerWidth=(int)container.getWidth();
    int intContainerHeight=(int)container.getHeight();

    int intContainedX=(int)contained.getX();
    int intContainedY=(int)contained.getY();
    int intContainedWidth=(int)contained.getWidth();
    int intContainedHeight=(int)contained.getHeight();

    if(intContainerWidth==intContainedWidth) {
      if(intContainerHeight==intContainedHeight) {
      }
      else {
        if(intContainedY==intContainerY) {
          Rectangle newRectangle=new Rectangle(intContainedX, intContainedY+intContainedHeight, intContainedWidth, intContainerY+intContainerHeight-(intContainedY+intContainedHeight));
          vecRectangles.addElement(newRectangle);
        }
        else if(intContainedY==(intContainerY+intContainerHeight-intContainedHeight)) {
          Rectangle newRectangle=new Rectangle(intContainedX, intContainerY, intContainedWidth, intContainedY-intContainerY);
          vecRectangles.addElement(newRectangle);
        }
        else {
          Rectangle newRectangle=new Rectangle(intContainedX, intContainedY+intContainedHeight, intContainedWidth, intContainerY+intContainerHeight-(intContainedY+intContainedHeight));
          vecRectangles.addElement(newRectangle);

          newRectangle=new Rectangle(intContainedX, intContainerY, intContainedWidth, intContainedY-intContainerY);
          vecRectangles.addElement(newRectangle);
        }
      }
    }
    else {
      if(intContainerHeight==intContainedHeight) {
        if(intContainedX==intContainerX) {
          Rectangle newRectangle=new Rectangle(intContainedX+intContainedWidth, intContainedY, intContainerX+intContainerWidth-(intContainedX+intContainedWidth), intContainedHeight);
          vecRectangles.addElement(newRectangle);
        }
        else if(intContainedX==(intContainerX+intContainerWidth-intContainedWidth)) {
          Rectangle newRectangle=new Rectangle(intContainerX, intContainedY, intContainedX-intContainerX, intContainedHeight);
          vecRectangles.addElement(newRectangle);
        }
        else {
          Rectangle newRectangle=new Rectangle(intContainedX+intContainedWidth, intContainedY, intContainerX+intContainerWidth-(intContainedX+intContainedWidth), intContainedHeight);
          vecRectangles.addElement(newRectangle);

          newRectangle=new Rectangle(intContainerX, intContainedY, intContainedX-intContainerX, intContainedHeight);
          vecRectangles.addElement(newRectangle);
        }
      }
      else {
        if(intContainerX==intContainedX) {
          if(intContainerY==intContainedY) {
//northwest

            Rectangle newRectangle=new Rectangle(intContainedX+intContainedWidth, intContainerY, intContainerX+intContainerWidth-(intContainedX+intContainedWidth), intContainerHeight);
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainerX, intContainedY+intContainedHeight, intContainerWidth, intContainerY+intContainerHeight-(intContainedY+intContainedHeight));
            vecRectangles.addElement(newRectangle);
          }
          else if((intContainerY+intContainerHeight-intContainedHeight)==intContainedY) {
//southwest

            Rectangle newRectangle=new Rectangle(intContainedX+intContainedWidth, intContainerY, intContainerX+intContainerWidth-(intContainedX+intContainedWidth), intContainerHeight);
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainerX, intContainerY, intContainerWidth, intContainedY-intContainerY);
            vecRectangles.addElement(newRectangle);
          }
          else {
//centerwest

            Rectangle newRectangle=new Rectangle(intContainerX, intContainedY+intContainedHeight, intContainerWidth, intContainerY+intContainerHeight-(intContainedY+intContainedHeight));
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainerX, intContainerY, intContainerWidth, intContainedY-intContainerY);
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainedX+intContainedWidth, intContainerY, intContainerX+intContainerWidth-(intContainedX+intContainedWidth), intContainerHeight);
            vecRectangles.addElement(newRectangle);
          }
        }
        else if((intContainerX+intContainerWidth-intContainedWidth)==intContainedX) {
          if(intContainerY==intContainedY) {
//northeast

            Rectangle newRectangle=new Rectangle(intContainerX, intContainerY, intContainedX-intContainerX, intContainerHeight);
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainerX, intContainedY+intContainedHeight, intContainerWidth, intContainerY+intContainerHeight-(intContainedY+intContainedHeight));
            vecRectangles.addElement(newRectangle);
          }
          else if((intContainerY+intContainerHeight-intContainedHeight)==intContainedY) {
//southeast

            Rectangle newRectangle=new Rectangle(intContainerX, intContainerY, intContainedX-intContainerX, intContainerHeight);
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainerX, intContainerY, intContainerWidth, intContainedY-intContainerY);
            vecRectangles.addElement(newRectangle);
          }
          else {
//centereast

            Rectangle newRectangle=new Rectangle(intContainerX, intContainerY, intContainedX-intContainerX, intContainerHeight);
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainerX, intContainedY+intContainedHeight, intContainerWidth, intContainerY+intContainerHeight-(intContainedY+intContainedHeight));
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainerX, intContainerY, intContainerWidth, intContainedY-intContainerY);
            vecRectangles.addElement(newRectangle);
          }
        }
        else {
          if(intContainerY==intContainedY) {
//northcenter

            Rectangle newRectangle=new Rectangle(intContainerX, intContainerY, intContainedX-intContainerX, intContainerHeight);
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainedX+intContainedWidth, intContainerY, intContainerX+intContainerWidth-(intContainedX+intContainedWidth), intContainerHeight);
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainerX, intContainedY+intContainedHeight, intContainerWidth, intContainerY+intContainerHeight-(intContainedY+intContainedHeight));
            vecRectangles.addElement(newRectangle);
          }
          else if((intContainerY+intContainerHeight-intContainedHeight)==intContainedY) {
//southcenter

            Rectangle newRectangle=new Rectangle(intContainerX, intContainerY, intContainedX-intContainerX, intContainerHeight);
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainedX+intContainedWidth, intContainerY, intContainerX+intContainerWidth-(intContainedX+intContainedWidth), intContainerHeight);
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainerX, intContainerY, intContainerWidth, intContainedY-intContainerY);
            vecRectangles.addElement(newRectangle);
          }
          else {
//centercenter

            Rectangle newRectangle=new Rectangle(intContainerX, intContainerY, intContainerWidth, intContainedY-intContainerY);
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainerX, intContainerY, intContainedX-intContainerX, intContainerHeight);
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainedX+intContainedWidth, intContainerY, intContainerX+intContainerWidth-(intContainedX+intContainedWidth), intContainerHeight);
            vecRectangles.addElement(newRectangle);

            newRectangle=new Rectangle(intContainerX, intContainedY+intContainedHeight, intContainerWidth, intContainerY+intContainerHeight-(intContainedY+intContainedHeight));
            vecRectangles.addElement(newRectangle);
          }
        }
      }
    }

    Rectangle rectangles[]=new Rectangle[vecRectangles.size()];
    for(int i=0;i<rectangles.length;i++)
      rectangles[i]=(Rectangle)vecRectangles.elementAt(i);

    return rectangles;
  }

  public void removeDuplicateRectangles() {
    Vector vecKeepInds=new Vector();
    for(int i=0;i<vacantSpaces.length;i++)
      vecKeepInds.addElement(new Integer(i));

    Vector vecExactMatches=new Vector();

    for(int i=0;i<vacantSpaces.length;i++) {
      for(int ia=0;ia<i;ia++) {
        if(vacantSpaces[i].contains(vacantSpaces[ia])) {
          vecKeepInds.remove(new Integer(ia));

          if(vacantSpaces[i].getX()==vacantSpaces[ia].getX() && vacantSpaces[i].getY()==vacantSpaces[ia].getY() && vacantSpaces[i].getWidth()==vacantSpaces[ia].getWidth() && vacantSpaces[i].getHeight()==vacantSpaces[ia].getHeight()) {
            int iz=0;
            for(;iz<vecExactMatches.size();iz++) {
              Rectangle rectangle=(Rectangle)vecExactMatches.elementAt(iz);
              if(rectangle.getX()==vacantSpaces[i].getX() && rectangle.getY()==vacantSpaces[i].getY() && rectangle.getWidth()==vacantSpaces[i].getWidth() && rectangle.getHeight()==vacantSpaces[i].getHeight()) {
                break;
              }
            }

            if(iz==vecExactMatches.size()) {
              vecExactMatches.addElement(vacantSpaces[i]);
            }
          }
        }
      }
      for(int ia=i+1;ia<vacantSpaces.length;ia++) {
        if(vacantSpaces[i].contains(vacantSpaces[ia])) {
          vecKeepInds.remove(new Integer(ia));

          if(vacantSpaces[i].getX()==vacantSpaces[ia].getX() && vacantSpaces[i].getY()==vacantSpaces[ia].getY() && vacantSpaces[i].getWidth()==vacantSpaces[ia].getWidth() && vacantSpaces[i].getHeight()==vacantSpaces[ia].getHeight()) {
            int iz=0;
            for(;iz<vecExactMatches.size();iz++) {
              Rectangle rectangle=(Rectangle)vecExactMatches.elementAt(iz);
              if(rectangle.getX()==vacantSpaces[i].getX() && rectangle.getY()==vacantSpaces[i].getY() && rectangle.getWidth()==vacantSpaces[i].getWidth() && rectangle.getHeight()==vacantSpaces[i].getHeight()) {
                break;
              }
            }

            if(iz==vecExactMatches.size()) {
              vecExactMatches.addElement(vacantSpaces[i]);
            }
          }
        }
      }
    }

    Rectangle newVacantSpaces[]=new Rectangle[vecKeepInds.size()+vecExactMatches.size()];
    int intCount=0;
    for(int i=0;i<vecKeepInds.size();i++) {
      Integer nextInd=(Integer)vecKeepInds.elementAt(i);
      newVacantSpaces[intCount++]=vacantSpaces[nextInd.intValue()];
    }

    for(int i=0;i<vecExactMatches.size();i++) {
      Rectangle nextRectangle=(Rectangle)vecExactMatches.elementAt(i);
      newVacantSpaces[intCount++]=nextRectangle;
    }

    vacantSpaces=newVacantSpaces;
  }

  public void freeSpace(InventoryItem item) {
    vacantSpaces=new Rectangle[1];
    vacantSpaces[0]=new Rectangle(0, 0, intContainerWidth, intContainerHeight);

    for(int i=0;i<vecItems.size();i++) {
      InventoryItem nextItem=(InventoryItem)vecItems.elementAt(i);
      if(nextItem==item)
        continue;

      findNewLocation2(nextItem, false);
    }

    removeDuplicateRectangles();

    Arrays.sort(vacantSpaces, new RectangleSizeComparator());
  }

/*
  public void freeSpace(InventoryItem item) {
    int intX=item.getX();
    int intY=item.getY();
    int intWidth=item.getWidth();
    int intHeight=item.getHeight());

    Vector vecRemoveRectangles=new Vector();
    Vector vecNewRectangles=new Vector();
    for(int i=0;i<vacantSpaces.length;i++) {
      int intX2=(int)vacantSpaces[i].getX();
      int intY2=(int)vacantSpaces[i].getY();
      int intWidth2=(int)vacantSpaces[i].getWidth();
      int intHeight2=(int)vacantSpaces[i].getHeight();

      if(intX==(intX2+intWidth2)) {
        if(intY>=intY2 && intY<(intY2+intHeight2)) {
          int intX3=intX;
          int intY3=intY;
          int intWidth3=intWidth;
          int intHeight3=-1;
          if((intY+intHeight)<=(intY2+intHeight2))
            intHeight3=intHeight;
          else
            intHeight3=intY2+intHeight2-intY;
          Rectangle newRectangles[]=freeSpace(EAST, intX3, intY3, intWidth3, intHeight3, i);
          for(int ia=0;ia<newRectangles.length;ia++)
            vecNewRectangles.addElement(newRectangles[ia]);
          vecRemoveRectangles.addElement(new Integer(i));
        }
        else if(intY<intY2 && (intY+intHeight)>intY2) {
          int intX3=intX;
          int intY3=intY2;
          int intWidth3=intWidth;
          int intHeight3=-1;
          if((intY+intHeight)<=(intY2+intHeight2))
            intHeight3=intY+intHeight-intY2;
          else
            intHeight3=intHeight2;
          Rectangle newRectangles[]=freeSpace(EAST, intX3, intY3, intWidth3, intHeight3, i);
          for(int ia=0;ia<newRectangles.length;ia++)
            vecNewRectangles.addElement(newRectangles[ia]);
          vecRemoveRectangles.addElement(new Integer(i));
        }
      }
      else if((intX+intWidth)==intX2) {
        if(intY>=intY2 && intY<(intY2+intHeight2)) {
          int intX3=intX;
          int intY3=intY;
          int intWidth3=intWidth;
          int intHeight3=-1;
          if((intY+intHeight)<=(intY2+intHeight2))
            intHeight3=intHeight;
          else
            intHeight3=intY2+intHeight2-intY;
          Rectangle newRectangles[]=freeSpace(WEST, intX3, intY3, intWidth3, intHeight3, i);
          for(int ia=0;ia<newRectangles.length;ia++)
            vecNewRectangles.addElement(newRectangles[ia]);
          vecRemoveRectangles.addElement(new Integer(i));
        }
        else if(intY<intY2 && (intY+intHeight)>intY2) {
          int intX3=intX;
          int intY3=intY2;
          int intWidth3=intWidth;
          int intHeight3=-1;
          if((intY+intHeight)<=(intY2+intHeight2))
            intHeight3=intY+intHeight-intY2;
          else
            intHeight3=intHeight2;
          Rectangle newRectangles[]=freeSpace(WEST, intX3, intY3, intWidth3, intHeight3, i);
          for(int ia=0;ia<newRectangles.length;ia++)
            vecNewRectangles.addElement(newRectangles[ia]);
          vecRemoveRectangles.addElement(new Integer(i));
        }
      }
      else if(intY==(intY2+intHeight2)) {
        if(intX>=intX2 && intX<(intX2+intWidth2)) {
          int intX3=intX;
          int intY3=intY;
          int intWidth3=-1;
          if((intX+intWidth)<=(intX2+intWidth2))
            intWidth3=intWidth;
          else
            intWidth3=intX2+intWidth2-intX;
          int intHeight3=intHeight;
          Rectangle newRectangles[]=freeSpace(SOUTH, intX3, intY3, intWidth3, intHeight3, i);
          for(int ia=0;ia<newRectangles.length;ia++)
            vecNewRectangles.addElement(newRectangles[ia]);
          vecRemoveRectangles.addElement(new Integer(i));
        }
        else if(intX<intX2 && (intX+intWidth)>intX2) {
          int intX3=intX;
          int intY3=intY;
          int intWidth3=-1;
          if((intX+intWidth)<=(intX2+intWidth2))
            intWidth3=intX+intWidth-intX2;
          else
            intWidth3=intWidth2;
          int intHeight3=intHeight;
          Rectangle newRectangles[]=freeSpace(SOUTH, intX3, intY3, intWidth3, intHeight3, i);
          for(int ia=0;ia<newRectangles.length;ia++)
            vecNewRectangles.addElement(newRectangles[ia]);
          vecRemoveRectangles.addElement(new Integer(i));
        }
      }
      else if((intY+intHeight)==intY2) {
        if(intX>=intX2 && intX<(intX2+intWidth2)) {
          int intX3=intX;
          int intY3=intY;
          int intWidth3=-1;
          if((intX+intWidth)<=(intX2+intWidth2))
            intWidth3=intWidth;
          else
            intWidth3=intX2+intWidth2-intX;
          int intHeight3=intHeight;
          Rectangle newRectangles[]=freeSpace(NORTH, intX3, intY3, intWidth3, intHeight3, i);
          for(int ia=0;ia<newRectangles.length;ia++)
            vecNewRectangles.addElement(newRectangles[ia]);
          vecRemoveRectangles.addElement(new Integer(i));
        }
        else if(intX<intX2 && (intX+intWidth)>intX2) {
          int intX3=intX;
          int intY3=intY;
          int intWidth3=-1;
          if((intX+intWidth)<=(intX2+intWidth2))
            intWidth3=intX+intWidth-intX2;
          else
            intWidth3=intWidth2;
          int intHeight3=intHeight;
          Rectangle newRectangles[]=freeSpace(NORTH, intX3, intY3, intWidth3, intHeight3, i);
          for(int ia=0;ia<newRectangles.length;ia++)
            vecNewRectangles.addElement(newRectangles[ia]);
          vecRemoveRectangles.addElement(new Integer(i));
        }
      }
    }

    Rectangle newVacantSpaces[]=new Rectangle[vacantSpaces.length-vecRemoveRectangles.size()+vecNewRectangles.size()];
    int intCountV=0;
    int intCurrentStart=0;
    for(int i=0;i<vecRemoveRectangles.size();i++) {
      int intIndex=((Integer)vecRemoveRectangles.elementAt(i)).intValue();
      for(int ia=intCurrentStart;ia<intIndex;ia++)
        newVacantSpaces[intCountV++]=vacantSpaces[ia];
      intCurrentStart=intIndex+1;
    }
    for(int ia=intCurrentStart;ia<vacantSpaces.length;ia++)
      newVacantSpaces[intCountV++]=vacantSpaces[ia];
    for(int i=0;i<vecNewRectangles.size();i++)
      newVacantSpaces[intCountV++]=(Rectangle)vecNewRectangles.elementAt(i);

    vacantSpaces=newVacantSpaces;

    Arrays.sort(vacantSpaces, new RectangleSizeComparator());
  }

  public Rectangle[] freeSpace(int intDirection, int intX, int intY, int intWidth, int intHeight, int vacantSpacesIndex) {
    Vector vecRectangles=new Vector();

    int intX2=(int)vacantSpaces[i].getX();
    int intY2=(int)vacantSpaces[i].getY();
    int intWidth2=(int)vacantSpaces[i].getWidth();
    int intHeight2=(int)vacantSpaces[i].getHeight();

    if(intDirection==EAST) {
      
    }
    else if(intDirection==WEST) {
    }
    else if(intDirection==NORTH) {
    }
    else if(intDirection==SOUTH) {
    }

    Rectangle rectangles[]=new Rectangle[vecRectangles.size()];
    for(int i=0;i<rectangles.length;i++)
      rectangles[i]=(Rectangle)vecRectangles.elementAt(i);

    return rectangles;
  }
*/

  public Vector searchForItem(String strName, int intDatePreference) {
    Vector vecRet=new Vector();

    for(int i=0;i<vecItems.size();i++) {
      Object nextObj=vecItems.elementAt(i);
      if(nextObj instanceof InventoryContainer) {
        Vector vecRet2=((InventoryContainer)nextObj).searchForItem(strName, intDatePreference);
        for(int ia=0;ia<vecRet2.size();ia++)
          vecRet.addElement(vecRet2.elementAt(ia));
      }
      else {
        InventoryItem item=(InventoryItem)nextObj;

        if(strName.equals(item.getName())) {
          if(item.getWeight()>0) {
            if(intDatePreference==2)
              vecRet.addElement(item);
            else {
              if(item.getDateExpiration()!=null)
                vecRet.addElement(item);
            }
          }
        }

/*
        boolean blnMatchFound=true;

        String strName2=item.getName();
        int intIndex=-1;
        int intIndex2=-1;
        int intIndex3=-1;
        int intCurrentStart=0;
        if(!strName.startsWith("*")) {
          intIndex=strName.indexOf('*', intIndex+1);
          if(intIndex==-1) {
            if(!strName.equals(strName2))
              blnMatchFound=false;
          }
          else {
            String strNextPiece=strName.substring(0, intIndex);
            if(strName2.length()<intIndex)
              blnMatchFound=false;
            else {
              String strNextPiece2=strName2.substring(0, intIndex);
              intCurrentStart=intIndex;
              if(!strNextPiece.equals(strNextPiece2))
                blnMatchFound=false;
            }
          }
        }
        else
          intIndex=0;
        if(blnMatchFound) {
          while(intIndex!=-1) {
            intIndex2=strName.indexOf('*', intIndex+1);

            if(intIndex2==-1) {
              if((intIndex+1)!=strName.length()) {
                String strNextPiece=strName.substring(intIndex+1);
                String strNextPiece2=strName2.substring(intCurrentStart);
                intIndex3=strNextPiece2.indexOf(strNextPiece);
                if(intIndex3!=(strNextPiece2.length()-strNextPiece.length()))
                  blnMatchFound=false;
              }
              break;
            }
            else {
              String strNextPiece=strName.substring(intIndex+1, intIndex2);
              String strNextPiece2=strName2.substring(intCurrentStart);
              intIndex3=strNextPiece2.indexOf(strNextPiece);
              if(intIndex3==-1) {
                blnMatchFound=false;
                break;
              }
              intCurrentStart=intIndex3+strNextPiece.length();
              intIndex=intIndex2;
            }
          }
        }
*/
      }
    }

    return vecRet;
  }

  public void makeContainerFitScreen(Dimension dimScrollPane) {
    if(getContainerWidth()<dimScrollPane.width)
      setContainerWidth(dimScrollPane.width);
    if(getContainerHeight()<dimScrollPane.height)
      setContainerHeight(dimScrollPane.height);

    for(int i=0;i<vecItems.size();i++) {
      InventoryItem nextItem=(InventoryItem)vecItems.elementAt(i);
      if(nextItem instanceof InventoryContainer) {
        InventoryContainer nextContainer=(InventoryContainer)nextItem;
        nextContainer.makeContainerFitScreen(dimScrollPane);
      }
    }
  }

  public void initializeImage(InventoryFrame iFrame) {
    if(strImage!=null)
      super.initializeImage(iFrame);

    for(int i=0;i<vecItems.size();i++)
      ((InventoryItem)vecItems.elementAt(i)).initializeImage(iFrame);
  }

  public void setHashCode(InventoryFrame iFrame) {
    super.setHashCode(iFrame);
    for(int i=0;i<vecItems.size();i++)
      ((InventoryItem)vecItems.elementAt(i)).setHashCode(iFrame);
  }


  class RectangleSizeComparator
  implements Comparator {

    RectangleSizeComparator() {
      super();
    }

    public int compare(Object obj1, Object obj2) {
      Rectangle rectangle1=(Rectangle)obj1;
      Rectangle rectangle2=(Rectangle)obj2;

      double rectangle1Size=rectangle1.getWidth()*rectangle1.getHeight();
      double rectangle2Size=rectangle2.getWidth()*rectangle2.getHeight();

      if(rectangle1Size<rectangle2Size)
        return -1;
      else if(rectangle1Size>rectangle2Size)
        return 1;

      return 0;
    }

    public boolean equals(Object obj) {
      return false;
    }
  }
}