package bim;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.dnd.DnDConstants;
import javax.swing.JFileChooser;
import java.io.*;
import java.util.Vector;
import java.util.Date;
import javax.imageio.ImageIO;

class InventoryScrollPane extends ScrollPane
implements MouseListener, MouseMotionListener {
  String strFileName;
  ScrollPane sPane;
  Frame refThis;
  Dimension screenDim;
  boolean blnChangesMade=false;
  InventoryContainer inventoryParent;
  Vector vecInventoryParents=new Vector();
  InventoryContainer inventoryCurrent;
  InventoryCanvas iCanv=new InventoryCanvas();
  boolean blnAddingInventory=false;
  int intAddingInventoryX=-1;
  int intAddingInventoryY=-1;
  int intAddingInventoryX2=-1;
  int intAddingInventoryY2=-1;
  int intAddingInventoryWidth=-1;
  int intAddingInventoryHeight=-1;
  boolean blnMovingInventory=false;
  int intMovingInventoryX=-1;
  int intMovingInventoryY=-1;
  InventoryItem inventoryMoving;
  int intMovingInventoryX2=-1;
  int intMovingInventoryY2=-1;
  boolean blnResizingInventory=false;
  int intResizingX=-1;
  int intResizingY=-1;
  int intResizingWidth=-1;
  int intResizingHeight=-1;
  boolean blnSearched=false;
  InventoryItem inventorySearch;


  InventoryScrollPane(int intScrollbarPolicy, Frame refThis) {
    super(intScrollbarPolicy);
    sPane=this;
    this.refThis=refThis;

    screenDim=Toolkit.getDefaultToolkit().getScreenSize();

    add(iCanv);
    iCanv.addMouseListener(this);
    iCanv.addMouseMotionListener(this);

/*
    InventoryFrame iFrame=(InventoryFrame)refThis;
    iFrame.inventoryDragAndDrop=this;
    iFrame.recognizerDragAndDrop=iFrame.dragSource.createDefaultDragGestureRecognizer(iCanv, DnDConstants.ACTION_COPY, iFrame);
*/
  }

  public void mousePressed(MouseEvent me) {
    if(inventoryCurrent==null)
      return;

    InventoryFrame iFrame=(InventoryFrame)refThis;
    if(iFrame.recognizerDragAndDrop!=null) {
      int intMods=me.getModifiersEx();
      intMods=intMods & (MouseEvent.BUTTON3_DOWN_MASK | InputEvent.ALT_DOWN_MASK);
      if(intMods!=(MouseEvent.BUTTON3_DOWN_MASK | InputEvent.ALT_DOWN_MASK)) {
        iFrame.recognizerDragAndDrop.removeDragGestureListener((InventoryFrame)refThis);
        iFrame.recognizerDragAndDrop=null;
      }
    }

    Point mPoint=me.getPoint();
    int mX=mPoint.x;
    int mY=mPoint.y;
    Vector vecItems=inventoryCurrent.getItems();
    int i=0;
    for(;i<vecItems.size();i++) {
      InventoryItem nextItem=(InventoryItem)vecItems.elementAt(i);
      int intX=nextItem.getX();
      int intY=nextItem.getY();
      int intWidth=nextItem.getWidth();
      int intHeight=nextItem.getHeight();
      if(mX>=intX && mX<(intX+intWidth)) {
        if(mY>=intY && mY<(intY+intHeight)) {
          if(me.getButton()==MouseEvent.BUTTON1) {
            Vector vecChoices=new Vector();
            vecChoices.addElement("Select");
            vecChoices.addElement("View Properties");
            vecChoices.addElement("Set Properties");
            vecChoices.addElement("Resize");
            vecChoices.addElement("Delete");
            vecChoices.addElement("Set Image");
            vecChoices.addElement("Unset Image");
            if(inventoryCurrent!=inventoryParent)
              vecChoices.addElement("Remove from Container");
            if(nextItem instanceof InventoryContainer)
              vecChoices.addElement("View Inventory");

            String strChoices[]=new String[vecChoices.size()];
            for(int ia=0;ia<strChoices.length;ia++)
              strChoices[ia]=(String)vecChoices.elementAt(ia);

            ChoiceSelectorDialog cDialog=new ChoiceSelectorDialog(refThis, "Inventory Choice Selector", strChoices);
            cDialog.show();

            if(cDialog.cancelIt)
              return;

            String strChoice=cDialog.getChoice();
            if(strChoice.equals("Select")) {
              inventorySearch=nextItem;
              blnSearched=true;
              iCanv.repaint();
            }
            else if(strChoice.equals("View Properties")) {
              ViewPropertiesDialog vDialog=new ViewPropertiesDialog(refThis, nextItem);
              vDialog.show();
            }
            else if(strChoice.equals("Set Properties")) {
              SetPropertiesDialog sDialog=new SetPropertiesDialog(refThis, nextItem);
              sDialog.show();
            }
            else if(strChoice.equals("Resize")) {
              blnResizingInventory=true;
              intResizingX=nextItem.getX();
              intResizingY=nextItem.getY();
              intResizingWidth=nextItem.getWidth();
              intResizingHeight=nextItem.getHeight();
 
              InventoryResizerDialog iDialog=new InventoryResizerDialog(refThis, nextItem, intResizingWidth, intResizingHeight);
              iDialog.show();
            }
            else if(strChoice.equals("Delete")) {
              ConfirmDialog cDialog2=new ConfirmDialog(refThis, "Confirm Delete Dialog", "Delete \""+nextItem.getName()+"\"?");
              cDialog2.show();

              if(cDialog2.cancelIt)
                return;

              if(nextItem instanceof InventoryContainer) {
                InventoryContainer nextContainer=(InventoryContainer)nextItem;
                if(nextContainer.getItems().size()>0) {
                  cDialog2=new ConfirmDialog(refThis, "Confirm Delete Container Dialog", "\""+nextItem.getName()+"\" contains items. Are you sure?");
                  cDialog2.show();

                  if(cDialog2.cancelIt)
                    return;
                }
              }

/*
              if(blnSearched) {
                checkRemoveSearched(nextItem);
              }
*/

              vecItems.remove(nextItem);
              inventoryCurrent.freeSpace(nextItem);

              blnChangesMade=true;

              iCanv.repaint();
            }
            else if(strChoice.equals("Set Image")) {
              JFileChooser fDialog=new JFileChooser();
              fDialog.setCurrentDirectory(new File("images"));
              fDialog.setDialogTitle("Set Image Dialog");
              fDialog.setMultiSelectionEnabled(false);
              fDialog.setFileSelectionMode(JFileChooser.FILES_ONLY);
              int intResp=fDialog.showOpenDialog(this);

              if(intResp!=JFileChooser.APPROVE_OPTION)
                return;

              File fileLoad=fDialog.getSelectedFile();

              String strAbsolutePath=fileLoad.getAbsolutePath();

              String fSep=System.getProperty("file.separator");
              String strUserDir=System.getProperty("user.dir");
              if(!strUserDir.endsWith(fSep))
                strUserDir+=fSep;
              strUserDir+="images";
              strUserDir+=fSep;

              if(!strAbsolutePath.startsWith(strUserDir)) {
                MessageDialog mDialog=new MessageDialog(refThis, "Set Image Invalid Path Dialog", "Error. The image file must be inside the \"images\" folder.");
                mDialog.show();

                return;
              }

              String strFileName=fileLoad.getName();

              boolean blnFoundFile=false;
              String strExtensions[]=ImageIO.getReaderFileSuffixes();
              for(int ia=0;ia<strExtensions.length;ia++)
                strExtensions[ia]="."+strExtensions[ia];
              for(int ia=0;ia<strExtensions.length;ia++) {
                if(strFileName.endsWith(strExtensions[ia])) {
                  blnFoundFile=true;
                  break;
                }
              }
              if(!blnFoundFile) {
                for(int ia=0;ia<strExtensions.length;ia++)
                  strExtensions[ia]=strExtensions[ia].substring(1);

                ListDisplayDialog lDialog=new ListDisplayDialog(refThis, "Set Image Incorrect File Extension Dialog", "Acceptable File Extensions:", strExtensions);
                lDialog.show();

                return;
              }

              strFileName=strFileName.substring(0, strFileName.lastIndexOf("."));

              try {
                BufferedImage bufImage=ImageIO.read(fileLoad);

                ((InventoryFrame)refThis).hashImages.put(strFileName, bufImage);
                nextItem.setStrImage(strFileName);
                nextItem.setImage(bufImage);

                blnChangesMade=true;

                iCanv.repaint();
              }
              catch(Exception ex) {
                ex.printStackTrace();
              }
            }
            else if(strChoice.equals("Unset Image")) {
              nextItem.setStrImage(null);
              nextItem.setImage(null);

              blnChangesMade=true;

              iCanv.repaint();
            }
            else if(strChoice.equals("Remove from Container")) {
              inventoryCurrent.freeSpace(nextItem);
              InventoryContainer inventoryNewParent=getParentContainer();
//              vecInventoryParents.removeElementAt(vecInventoryParents.size()-1);
              inventoryCurrent.getItems().remove(nextItem);
              inventoryNewParent.getItems().addElement(nextItem);
              int intCoords[]=inventoryNewParent.findNewLocation(nextItem);
              nextItem.setX(intCoords[0]);
              nextItem.setY(intCoords[1]);
//              inventoryCurrent=inventoryNewParent;

              nextItem.setParent(inventoryNewParent);

              inventorySearch=nextItem;
              blnSearched=true;

//              setScrollPosition(inventorySearch.getX(), inventorySearch.getY());

              blnChangesMade=true;

              invalidate();
              validate();
              iCanv.repaint();
            }
            else if(strChoice.equals("View Inventory")) {
              inventoryCurrent=(InventoryContainer)nextItem;
              vecInventoryParents.addElement(inventoryCurrent);
              invalidate();
              validate();
              iCanv.repaint();
            }
          }
          else {
            int intMods=me.getModifiersEx();
            intMods=intMods & InputEvent.ALT_DOWN_MASK;
            if(intMods==InputEvent.ALT_DOWN_MASK) {
//              InventoryFrame iFrame=(InventoryFrame)refThis;
              if(iFrame.recognizerDragAndDrop==null) {
                inventoryMoving=nextItem;
                iFrame.inventoryDragAndDrop=this;
                iFrame.intHashCodeDragAndDrop=nextItem.hashCode();
                iFrame.recognizerDragAndDrop=iFrame.dragSource.createDefaultDragGestureRecognizer(iCanv, DnDConstants.ACTION_COPY, iFrame);
              }
            }
            else {
              blnMovingInventory=true;
              intMovingInventoryX=mX;
              intMovingInventoryY=mY;
              inventoryMoving=nextItem;
              intMovingInventoryX2=inventoryMoving.getX();
              intMovingInventoryY2=inventoryMoving.getY();

              iCanv.repaint();
            }
          }
          return;
        }
      }
    }

    if(i==vecItems.size()) {
      blnAddingInventory=true;
      intAddingInventoryX=mX;
      intAddingInventoryY=mY;
      intAddingInventoryX2=mX;
      intAddingInventoryY2=mY;
      intAddingInventoryWidth=0;
      intAddingInventoryHeight=0;

      iCanv.repaint();
    }
  }

  public void dragAndDropAdd(InventoryItem item) {
    if(inventoryCurrent==null)
      return;

    Rectangle rectangle0=new Rectangle(item.getX(), item.getY(), item.getWidth(), item.getHeight());

    Vector vecItems=inventoryCurrent.getItems();
    for(int i=0;i<vecItems.size();i++) {
      InventoryItem nextItem=(InventoryItem)vecItems.elementAt(i);

      int intNextX=nextItem.getX();
      int intNextY=nextItem.getY();
      int intNextWidth=nextItem.getWidth();
      int intNextHeight=nextItem.getHeight();

      Rectangle rectangle1=new Rectangle(intNextX, intNextY, intNextWidth, intNextHeight);

      if(rectangle0.intersects(rectangle1)) {
        if(nextItem instanceof InventoryContainer) {
          ConfirmDialog cDialog=new ConfirmDialog(refThis, "Confirm Move To Container Dialog", "Do you want to move "+item.getName()+" into "+nextItem.getName()+"?");
          cDialog.show();
          if(cDialog.cancelIt) {
            inventoryCurrent.getItems().addElement(item);
            int intCoords[]=inventoryCurrent.findNewLocation(item);
            item.setX(intCoords[0]);
            item.setY(intCoords[1]);

            item.setParent(inventoryCurrent);

            inventorySearch=item;
            blnSearched=true;

            setScrollPosition(inventorySearch.getX(), inventorySearch.getY());

            blnChangesMade=true;

            invalidate();
            validate();
            iCanv.repaint();

            return;
          }

//          inventoryCurrent.freeSpace(inventoryMoving);
//            vecInventoryParents.addElement(nextItem);
          InventoryContainer inventoryNewParent=(InventoryContainer)nextItem;
//          inventoryCurrent.getItems().remove(inventoryMoving);
          inventoryNewParent.getItems().addElement(item);
          int intCoords[]=inventoryNewParent.findNewLocation(item);
          item.setX(intCoords[0]);
          item.setY(intCoords[1]);
//            inventoryCurrent=inventoryNewParent;

          item.setParent(inventoryNewParent);

          inventorySearch=item;
          blnSearched=true;

//            setScrollPosition(inventorySearch.getX(), inventorySearch.getY());

          blnChangesMade=true;

          invalidate();
          validate();
          iCanv.repaint();

          return;
        }

        inventoryCurrent.getItems().addElement(item);
        int intCoords[]=inventoryCurrent.findNewLocation(item);
        item.setX(intCoords[0]);
        item.setY(intCoords[1]);

        item.setParent(inventoryCurrent);

        inventorySearch=item;
        blnSearched=true;

        setScrollPosition(inventorySearch.getX(), inventorySearch.getY());

        blnChangesMade=true;

        invalidate();
        validate();
        iCanv.repaint();

        return;
      }
    }

    Rectangle rectangle2=new Rectangle(0, 0, inventoryCurrent.getContainerWidth(), inventoryCurrent.getContainerHeight());
    Rectangle rectangle3=rectangle0.intersection(rectangle2);
    if(rectangle0.getWidth()==rectangle3.getWidth() & rectangle0.getHeight()==rectangle3.getHeight()) {
      inventoryCurrent.getItems().addElement(item);
      inventoryCurrent.findNewLocation2(item);
    }
    else {
      inventoryCurrent.getItems().addElement(item);
      int intCoords[]=inventoryCurrent.findNewLocation(item);
      item.setX(intCoords[0]);
      item.setY(intCoords[1]);

      inventorySearch=item;
      blnSearched=true;

      setScrollPosition(inventorySearch.getX(), inventorySearch.getY());

      invalidate();
      validate();
    }

    item.setParent(inventoryCurrent);

    blnChangesMade=true;

    iCanv.repaint();
  }

  public void dragAndDropRemove(InventoryItem item) {
    if(inventoryCurrent==null)
      return;
    inventoryCurrent.getItems().remove(item);
    inventoryCurrent.freeSpace(item);
    blnChangesMade=true;

    iCanv.repaint();    
  }

  public void mouseReleased(MouseEvent me) {
    if(inventoryCurrent==null)
      return;

    if(blnMovingInventory) {
      blnMovingInventory=false;

      Point mPoint=me.getPoint();
      int mX=mPoint.x;
      int mY=mPoint.y;

      int intTranslateX=intMovingInventoryX-mX;
      int intTranslateY=intMovingInventoryY-mY;

      int intNewX=inventoryMoving.getX()-intTranslateX;
      int intNewY=inventoryMoving.getY()-intTranslateY;

      if(intNewX<0)
        intNewX=0;
      if(intNewY<0)
        intNewY=0;

      boolean blnDoInvalidate=false;
      if((intNewX+inventoryMoving.getWidth())>=inventoryCurrent.getContainerWidth()) {
        inventoryCurrent.setContainerWidth(intNewX+inventoryMoving.getWidth()+1);
        blnDoInvalidate=true;
      }
      if((intNewY+inventoryMoving.getHeight())>=inventoryCurrent.getContainerHeight()) {
        inventoryCurrent.setContainerHeight(intNewY+inventoryMoving.getHeight()+1);
        blnDoInvalidate=true;
      }

      if(blnDoInvalidate) {
        invalidate();
        validate();
        iCanv.repaint();
      }

      Rectangle rectangle0=new Rectangle(intNewX, intNewY, inventoryMoving.getWidth(), inventoryMoving.getHeight());

      Vector vecItems=inventoryCurrent.getItems();
      for(int i=0;i<vecItems.size();i++) {
        InventoryItem nextItem=(InventoryItem)vecItems.elementAt(i);
        if(nextItem==inventoryMoving)
          continue;

        int intNextX=nextItem.getX();
        int intNextY=nextItem.getY();
        int intNextWidth=nextItem.getWidth();
        int intNextHeight=nextItem.getHeight();

        Rectangle rectangle1=new Rectangle(intNextX, intNextY, intNextWidth, intNextHeight);

        if(rectangle0.intersects(rectangle1)) {
          if(nextItem instanceof InventoryContainer) {
            ConfirmDialog cDialog=new ConfirmDialog(refThis, "Confirm Move To Container Dialog", "Do you want to move "+inventoryMoving.getName()+" into "+nextItem.getName()+"?");
            cDialog.show();

            if(cDialog.cancelIt) {
              iCanv.repaint();

              return;
            }

            inventoryCurrent.freeSpace(inventoryMoving);
//            vecInventoryParents.addElement(nextItem);
            InventoryContainer inventoryNewParent=(InventoryContainer)nextItem;
            inventoryCurrent.getItems().remove(inventoryMoving);
            inventoryNewParent.getItems().addElement(inventoryMoving);
            int intCoords[]=inventoryNewParent.findNewLocation(inventoryMoving);
            inventoryMoving.setX(intCoords[0]);
            inventoryMoving.setY(intCoords[1]);
//            inventoryCurrent=inventoryNewParent;

            inventoryMoving.setParent(inventoryNewParent);

            inventorySearch=inventoryMoving;
            blnSearched=true;

//            setScrollPosition(inventorySearch.getX(), inventorySearch.getY());

            blnChangesMade=true;
          }
          else {
            if(inventoryMoving.getName().equals(nextItem.getName())) {
              ConfirmDialog cDialog=new ConfirmDialog(refThis, "Confirm Merge Two Items Dialog", "Do you want to merge "+inventoryMoving.getName()+"?");
              cDialog.show();

              if(cDialog.cancelIt) {
                iCanv.repaint();

                return;
              }

              inventoryCurrent.freeSpace(inventoryMoving);
              inventoryCurrent.getItems().remove(inventoryMoving);

              int intNewWeight=nextItem.getWeight()+inventoryMoving.getWeight();

              nextItem.setWeight(intNewWeight);
              if(nextItem.getWeightMax()<intNewWeight)
                nextItem.setWeightMax(intNewWeight);

              inventorySearch=inventoryMoving;
              blnSearched=true;

              blnChangesMade=true;
            }
          }

          invalidate();
          validate();
          iCanv.repaint();

          return;
        }
      }

      inventoryCurrent.freeSpace(inventoryMoving);

      inventoryMoving.setX(intNewX);
      inventoryMoving.setY(intNewY);

      inventoryCurrent.findNewLocation2(inventoryMoving);

      blnChangesMade=true;

      iCanv.repaint();

      return;
    }

    if(!blnAddingInventory)
      return;

    blnAddingInventory=false;

    Point mPoint=me.getPoint();
    int mX=mPoint.x;
    int mY=mPoint.y;

    if(mX==intAddingInventoryX) {
      if(mY==intAddingInventoryY) {
        iCanv.repaint();

        return;
      }
    }

    int intX=-1;
    int intY=-1;
    int intWidth=-1;
    int intHeight=-1;

    if(mX<intAddingInventoryX) {
      intX=mX;
      intWidth=intAddingInventoryX-mX;
      if(mY<intAddingInventoryY) {
        intY=mY;
        intHeight=intAddingInventoryY-mY;
      }
      else {
        intY=intAddingInventoryY;
        intHeight=mY-intAddingInventoryY;
      }
    }
    else {
      intX=intAddingInventoryX;
      intWidth=mX-intAddingInventoryX;
      if(mY<intAddingInventoryY) {
        intY=mY;
        intHeight=intAddingInventoryY-mY;
      }
      else {
        intY=intAddingInventoryY;
        intHeight=mY-intAddingInventoryY;
      }
    }

    Rectangle rectangle0=new Rectangle(intX, intY, intWidth, intHeight);

    Vector vecItems=inventoryCurrent.getItems();
    for(int i=0;i<vecItems.size();i++) {
      InventoryItem nextItem=(InventoryItem)vecItems.elementAt(i);
      int intNextX=nextItem.getX();
      int intNextY=nextItem.getY();
      int intNextWidth=nextItem.getWidth();
      int intNextHeight=nextItem.getHeight();

      Rectangle rectangle1=new Rectangle(intNextX, intNextY, intNextWidth, intNextHeight);

      if(rectangle0.intersects(rectangle1)) {
        iCanv.repaint();

        return;
      }
    }

    AddInventoryDialog aDialog=new AddInventoryDialog(refThis, intX, intY, intWidth, intHeight);
    aDialog.show();

    if(aDialog.cancelIt) {
      iCanv.repaint();

      return;
    }

    InventoryItem item=aDialog.getItem();
    if(item instanceof InventoryContainer) {
      InventoryContainerSizeDialog iDialog=new InventoryContainerSizeDialog(refThis);
      iDialog.show();

      InventoryContainer container=(InventoryContainer)item;
      container.setContainerWidth(iDialog.getInputContainerWidth());
      container.setContainerHeight(iDialog.getInputContainerHeight());

      container.makeContainerFitScreen(getViewportSize());
    }
    item.setParent(inventoryCurrent);
    inventoryCurrent.getItems().addElement(item);
    inventoryCurrent.findNewLocation2(item);

    InventoryFrame iFrame=(InventoryFrame)refThis;
    if(iFrame.hashImages.containsKey(item.getName())) {
      ConfirmDialog cDialog=new ConfirmDialog(refThis, "Use Image for Item Dialog", "Do you want to use "+item.getName()+" image?");
      cDialog.show();

      if(!cDialog.cancelIt) {
        BufferedImage bufImage=(BufferedImage)iFrame.hashImages.get(item.getName());

        item.setStrImage(item.getName());
        item.setImage(bufImage);
      }
    }
    else {
      String fSep=System.getProperty("file.separator");
      String strExtensions[]=ImageIO.getReaderFileSuffixes();
      for(int i=0;i<strExtensions.length;i++) {
        try {
          File fileImage=new File("images"+fSep+item.getName()+"."+strExtensions[i]);
          if(fileImage.exists()) {
            ConfirmDialog cDialog=new ConfirmDialog(refThis, "Use Image for Item Dialog", "Do you want to use "+item.getName()+" image?");
            cDialog.show();

            if(!cDialog.cancelIt) {
              BufferedImage bufImage=ImageIO.read(fileImage);

              item.setImage(bufImage);

              iFrame.hashImages.put(item.getName(), bufImage);
            }

            break;
          }
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
      }
    }

    blnChangesMade=true;

    iCanv.repaint();
  }

  public void mouseClicked(MouseEvent me) {
  }

  public void mouseEntered(MouseEvent me) {
  }

  public void mouseExited(MouseEvent me) {
/*
    if(!blnMovingInventory)
      return;

    int intMods=me.getModifiersEx();
    intMods=intMods & InputEvent.ALT_DOWN_MASK;
    if(intMods!=InputEvent.ALT_DOWN_MASK)
      return;

System.out.println("exited");

    InventoryFrame iFrame=(InventoryFrame)refThis;
    iFrame.inventoryDragAndDrop=this;
    iFrame.recognizerDragAndDrop=iFrame.dragSource.createDefaultDragGestureRecognizer(iCanv, DnDConstants.ACTION_COPY, iFrame);
*/
  }

  public void mouseMoved(MouseEvent me) {
  }

  public void mouseDragged(MouseEvent me) {
    if(inventoryCurrent==null)
      return;

    if(blnMovingInventory) {
      Point mPoint=me.getPoint();
      int mX=mPoint.x;
      int mY=mPoint.y;

      int intTranslateX=intMovingInventoryX-mX;
      int intTranslateY=intMovingInventoryY-mY;

      intMovingInventoryX2=inventoryMoving.getX()-intTranslateX;
      intMovingInventoryY2=inventoryMoving.getY()-intTranslateY;

/*
      int intMods=me.getModifiersEx();
      intMods=intMods & (InputEvent.ALT_DOWN_MASK | MouseEvent.BUTTON3_DOWN_MASK);
      if(intMods==(InputEvent.ALT_DOWN_MASK | MouseEvent.BUTTON3_DOWN_MASK)) {
        if(iCanv.getSize().height<=(intMovingInventoryY2+inventoryMoving.getHeight()))
          return;
      }
*/

      if(intMovingInventoryX2<0)
        intMovingInventoryX2=0;
      if(intMovingInventoryY2<0)
        intMovingInventoryY2=0;

      boolean blnDoInvalidate=false;
      if((intMovingInventoryX2+inventoryMoving.getWidth())>=inventoryCurrent.getContainerWidth()) {
        inventoryCurrent.setContainerWidth(intMovingInventoryX2+inventoryMoving.getWidth()+1);
        blnDoInvalidate=true;
      }
      if((intMovingInventoryY2+inventoryMoving.getHeight())>=inventoryCurrent.getContainerHeight()) {
        inventoryCurrent.setContainerHeight(intMovingInventoryY2+inventoryMoving.getHeight()+1);
        blnDoInvalidate=true;
      }

      if(blnDoInvalidate) {
        invalidate();
        validate();
      }
      iCanv.repaint();

      return;
    }

    if(!blnAddingInventory)
      return;

    Point mPoint=me.getPoint();
    int mX=mPoint.x;
    int mY=mPoint.y;

    if(mX==intAddingInventoryX) {
      if(mY==intAddingInventoryY) {
        intAddingInventoryX2=mX;
        intAddingInventoryY2=mY;
        intAddingInventoryWidth=0;
        intAddingInventoryHeight=0;

        iCanv.repaint();

        return;
      }
    }

    int intX=-1;
    int intY=-1;
    int intWidth=-1;
    int intHeight=-1;

    if(mX<intAddingInventoryX) {
      intX=mX;
      intWidth=intAddingInventoryX-mX;
      if(mY<intAddingInventoryY) {
        intY=mY;
        intHeight=intAddingInventoryY-mY;
      }
      else {
        intY=intAddingInventoryY;
        intHeight=mY-intAddingInventoryY;
      }
    }
    else {
      intX=intAddingInventoryX;
      intWidth=mX-intAddingInventoryX;
      if(mY<intAddingInventoryY) {
        intY=mY;
        intHeight=intAddingInventoryY-mY;
      }
      else {
        intY=intAddingInventoryY;
        intHeight=mY-intAddingInventoryY;
      }
    }

    intAddingInventoryX2=intX;
    intAddingInventoryY2=intY;
    intAddingInventoryWidth=intWidth;
    intAddingInventoryHeight=intHeight;

    iCanv.repaint();
  }

  public InventoryContainer getParentContainer() {
    InventoryContainer container=(InventoryContainer)vecInventoryParents.elementAt(vecInventoryParents.size()-2);

    return container;
  }

/*
  public InventoryContainer getParentContainer(InventoryItem item) {
    Vector vecItems=inventoryParent.getItems();
    for(int i=0;i<vecItems.size();i++) {
      InventoryContainer container=getParentContainer(item, inventoryParent, (InventoryItem)vecItems.elementAt(i));
      if(container!=null)
        return container;
    }

    return null;
  }

  public InventoryContainer getParentContainer(InventoryItem item, InventoryContainer container0, InventoryItem itemIterate) {
    if(item==itemIterate)
      return container0;
    else {
      if(itemIterate instanceof InventoryContainer) {
        InventoryContainer container=(InventoryContainer)itemIterate;
        Vector vecItems=container.getItems();
        for(int i=0;i<vecItems.size();i++) {
          InventoryContainer container1=getParentContainer(item, container, (InventoryItem)vecItems.elementAt(i));
          if(container1!=null)
            return container1;
        }
      }
    }

    return null;
  }
*/

  public boolean checkSearchParent() {
    Vector vecItems=inventoryCurrent.getItems();
    for(int i=0;i<vecItems.size();i++) {
      InventoryItem nextItem=(InventoryItem)vecItems.elementAt(i);
      if(nextItem==inventorySearch)
        return true;
    }

    return false;
  }

/*
  public boolean checkSearchParent(InventoryContainer container) {
    Vector vecItems=container.getItems();
    for(int i=0;i<vecItems.size();i++) {
      boolean blnFound[]=checkSearchParent(container, (InventoryItem)vecItems.elementAt(i));
      if(blnFound[0])
        return blnFound[1];
    }

    return false;
  }

  public boolean[] checkSearchParent(InventoryContainer container0, InventoryItem item) {
    boolean retBool[]=new boolean[2];

    if(item==inventorySearch) {
      retBool[0]=true;
      if(inventoryCurrent==container0)
        retBool[1]=true;
      else
        retBool[1]=false;
    }
    else {
      if(item instanceof InventoryContainer) {
        InventoryContainer container=(InventoryContainer)item;
        Vector vecItems=container.getItems();
        for(int i=0;i<vecItems.size();i++) {
          boolean blnFound[]=checkSearchParent(container, (InventoryItem)vecItems.elementAt(i));
          if(blnFound[0]) {
            retBool[0]=true;
            retBool[1]=blnFound[1];

            return retBool;
          }
        }
      }
      retBool[0]=false;
    }

    return retBool;
  }
*/

/*
  public boolean checkRemoveSearched(InventoryItem item) {
    if(item==inventorySearch) {
      blnSearched=false;
      return true;
    }
    else {
      if(item instanceof InventoryContainer) {
        InventoryContainer container=(InventoryContainer)item;
        Vector vecItems=container.getItems();
        for(int i=0;i<vecItems.size();i++) {
          boolean blnFound=checkRemoveSearched((InventoryItem)vecItems.elementAt(i));
          if(blnFound)
            return true;
        }
      }
    }

    return false;
  }
*/

  public boolean save() {
    while(true) {
      JFileChooser fDialog=new JFileChooser();
      fDialog.setCurrentDirectory(new File("."));
      fDialog.setDialogTitle("Save Inventory Dialog");
      fDialog.setMultiSelectionEnabled(false);
      fDialog.setFileSelectionMode(JFileChooser.FILES_ONLY);
      int intResp=fDialog.showSaveDialog(refThis);

      if(intResp!=JFileChooser.APPROVE_OPTION)
        return false;

      File fileSave=fDialog.getSelectedFile();

      try {
        if(fileSave.exists()) {
          ConfirmOverwriteDialog cDialog=new ConfirmOverwriteDialog(refThis);
          cDialog.show();

          if(!cDialog.overwrite)
            continue;
        }


        ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileSave));
        oos.writeObject(inventoryParent);
        oos.close();

        strFileName=fileSave.getAbsolutePath();

        blnChangesMade=false;

        break;
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }

    return true;
  }


  class InventoryCanvas extends Canvas {

    InventoryCanvas() {
      super();
    }

    public Dimension getPreferredSize() {
      if(inventoryCurrent!=null)
        return new Dimension(inventoryCurrent.getContainerWidth(), inventoryCurrent.getContainerHeight());

      return new Dimension(1, 1);
    }

    public void paint(Graphics graph) {
/*
      if(((InventoryFrame)refThis).inventoryScrollPane==sPane) {
        Color oldColor=graph.getColor();
        graph.setColor(Color.blue);
        Adjustable adjH=sPane.getHAdjustable();
        int intX=adjH.getValue();
        Adjustable adjV=sPane.getVAdjustable();
        int intY=adjV.getValue();
//        Point pntObj=sPane.getScrollPosition();
        Dimension dimObj=sPane.getViewportSize();
        int width=dimObj.width;
        int height=dimObj.height;
        graph.drawRect(intX+1, intY+1, width-3, height-3);
        graph.setColor(oldColor);
      }
*/

      if(inventoryCurrent==null)
        return;

      int intBorder=3;
      Font oldFont=graph.getFont();
      Vector vecItems=inventoryCurrent.getItems();
      for(int i=0;i<vecItems.size();i++) {
        InventoryItem nextItem=(InventoryItem)vecItems.elementAt(i);
        int intX=nextItem.getX();
        int intY=nextItem.getY();
        int intWidth=nextItem.getWidth();
        int intHeight=nextItem.getHeight();

        BufferedImage bufImage=nextItem.getImage();

        if(bufImage==null) {
          String strName=nextItem.getName();
          graph.drawRect(intX, intY, intWidth-1, intHeight-1);

          int intWidth2=intWidth-intBorder*2;
          int intHeight2=intHeight-intBorder*2;
          Font nextFont=oldFont;
          FontMetrics fMetr=graph.getFontMetrics(nextFont);
          int intStrWidth=fMetr.stringWidth(strName);
          int intStrHeight=fMetr.getHeight();
          if(intStrWidth>intWidth2 || intStrHeight>intHeight2) {
            while((nextFont.getSize2D()-0.1f)>0.1f) {
              nextFont=nextFont.deriveFont(nextFont.getSize2D()-0.1f);;
              fMetr=graph.getFontMetrics(nextFont);
              intStrWidth=fMetr.stringWidth(strName);
              intStrHeight=fMetr.getHeight();
              if(intStrWidth<intWidth2 && intStrHeight<intHeight2)
                break;
            }
          }
          else {
            int intStrWidth2=intStrWidth;
            int intStrHeight2=intStrHeight;
            Font nextFont2=nextFont;
            while(true) {
              nextFont=nextFont.deriveFont(nextFont.getSize2D()+0.1f);;
              fMetr=graph.getFontMetrics(nextFont);
              intStrWidth=fMetr.stringWidth(strName);
              intStrHeight=fMetr.getHeight();
              if(intStrWidth>intWidth2 || intStrHeight>intHeight2)
                break;
              intStrWidth2=intStrWidth;
              intStrHeight2=intStrHeight;
              nextFont2=nextFont;
            }
//          intStrWidth=intStrWidth2;
//          intStrHeight=intStrHeight2;
            nextFont=nextFont2;
          }
          graph.setFont(nextFont);
          graph.drawString(strName, intX+intBorder, intY+intHeight-intBorder);
        }
        else {
          BufferedImage bufImage2=new BufferedImage(intWidth, intHeight, BufferedImage.TYPE_INT_ARGB);
          
          Graphics2D graph2=(Graphics2D)bufImage2.getGraphics();
          double dblImageW=(double)bufImage.getWidth();
          double dblImageH=(double)bufImage.getHeight();
          double dblImage2W=(double)intWidth;
          double dblImage2H=(double)intHeight;
          graph2.scale(dblImage2W/dblImageW, dblImage2H/dblImageH);
          graph2.drawImage(bufImage, 0, 0, null);

          graph.drawImage(bufImage2, intX, intY, null);          
        }
      }
      graph.setFont(oldFont);

      if(blnAddingInventory) {
        Color oldColor=graph.getColor();
        graph.setColor(Color.green);
        graph.drawRect(intAddingInventoryX2, intAddingInventoryY2, intAddingInventoryWidth-1, intAddingInventoryHeight-1);
        graph.setColor(oldColor);
      }

      if(blnMovingInventory) {
        Color oldColor=graph.getColor();
        graph.setColor(Color.green);
        graph.drawRect(intMovingInventoryX2, intMovingInventoryY2, inventoryMoving.getWidth()-1, inventoryMoving.getHeight()-1);
        graph.setColor(oldColor);
      }

      if(blnResizingInventory) {
        Color oldColor=graph.getColor();
        graph.setColor(Color.green);
        graph.drawRect(intResizingX, intResizingY, intResizingWidth-1, intResizingHeight-1);
        graph.setColor(oldColor);
      }

      if(blnSearched) {
        boolean blnIsSearchParent=checkSearchParent();
        if(blnIsSearchParent) {
          Color oldColor=graph.getColor();
          graph.setColor(Color.red);
          graph.drawRect(inventorySearch.getX(), inventorySearch.getY(), inventorySearch.getWidth()-1, inventorySearch.getHeight()-1);
          graph.setColor(oldColor);
        }
      }

/*
graph.setColor(Color.blue);
for(int i=0;i<inventoryCurrent.vacantSpaces.length;i++)
graph.drawRect((int)inventoryCurrent.vacantSpaces[i].getX(), (int)inventoryCurrent.vacantSpaces[i].getY(), (int)inventoryCurrent.vacantSpaces[i].getWidth(), (int)inventoryCurrent.vacantSpaces[i].getHeight());
*/
    }
  }

  class ConfirmSaveDialog extends Dialog
  implements ActionListener {
    Button btnSave=new Button("Save");
    Button btnDontSave=new Button("Don't Save");
    Button btnCancel=new Button("Cancel");
    boolean save=false;
    boolean cancelIt=false;

    ConfirmSaveDialog(Frame parent, String strScrollPaneName) {
      this(parent, strScrollPaneName, false);
    }

    ConfirmSaveDialog(Frame parent, String strScrollPaneName, boolean blnMustSaveOrCancel) {
      super(parent, "Confirm Save Dialog - "+strScrollPaneName, true);

      if(blnMustSaveOrCancel)
        btnDontSave.setEnabled(false);

      Panel tempPan=new Panel();
      tempPan.add(btnSave);
      btnSave.addActionListener(this);
      tempPan.add(btnDontSave);
      btnDontSave.addActionListener(this);
      tempPan.add(btnCancel);
      btnCancel.addActionListener(this);
      add("Center", tempPan);

      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnSave) {
        save=true;
      }
      else if(evSource==btnDontSave) {
        save=false;
      }
      else if(evSource==btnCancel) {
        cancelIt=true;
      }
      dispose();
    }
  }

  class TextInputDialog extends Dialog
  implements ActionListener {
    TextField txtInput=new TextField();
    Button btnEnterText=new Button("Enter Text");
    Button btnCancel=new Button("Cancel");
    boolean cancelIt=false;

    TextInputDialog(Frame parent, String strTitle, String strLabel, String strEnterText) {
      super(parent, strTitle, true);
      Panel tempPan=new Panel();
      tempPan.setLayout(new BorderLayout());
      tempPan.add("West", new Label(strLabel));
      tempPan.add("Center", txtInput);
      add("Center", tempPan);

      btnEnterText.setLabel(strEnterText);

      Panel tempPan2=new Panel();
      tempPan2.add(btnEnterText);
      btnEnterText.addActionListener(this);
      tempPan2.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", tempPan2);

      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnEnterText) {
        if(txtInput.getText().length()==0) {
          txtInput.setText("Required text.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex) {
          }
          txtInput.setText("");

          return;
        }

        cancelIt=false;
      }
      else if(evSource==btnCancel) {
        cancelIt=true;
      }
      dispose();
    }
  }

  class ConfirmOverwriteDialog extends Dialog
  implements ActionListener {
    Button btnOverwrite=new Button("Overwrite");
    Button btnDontOverwrite=new Button("Don't Overwrite");
    boolean overwrite=false;

    ConfirmOverwriteDialog(Frame parent) {
      super(parent, "Confirm Overwrite Dialog", true);
      Panel tempPan=new Panel();
      tempPan.add(btnOverwrite);
      btnOverwrite.addActionListener(this);
      tempPan.add(btnDontOverwrite);
      btnDontOverwrite.addActionListener(this);
      add("Center", tempPan);

      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnOverwrite) {
        overwrite=true;
      }
      else if(evSource==btnDontOverwrite) {
        overwrite=false;
      }
      dispose();
    }
  }

  class ChoiceSelectorDialog extends Dialog
  implements ActionListener {
    List lstChoices=new List(5);
    Button btnSelect=new Button("Select");
    Button btnCancel=new Button("Cancel");
    boolean cancelIt=false;

    ChoiceSelectorDialog(Frame parent, String strTitle, String strChoices[]) {
      super(parent, strTitle, true);

      for(int i=0;i<strChoices.length;i++)
        lstChoices.add(strChoices[i]);

      add("Center", lstChoices);

      Panel tempPan=new Panel();
      tempPan.add(btnSelect);
      btnSelect.addActionListener(this);
      tempPan.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", tempPan);

      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public String getChoice() {
      return lstChoices.getItem(lstChoices.getSelectedIndex());
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnSelect) {
        int intSelIndex=lstChoices.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        cancelIt=false;
      }
      else if(evSource==btnCancel) {
        cancelIt=true;
      }
      dispose();
    }
  }

  class ViewPropertiesDialog extends Dialog
  implements ActionListener {
    Label lblName=new Label("");
    Label lblWeight=new Label("");
    Label lblWeightMax=new Label("");
    Label lblImage=new Label("");
    TextArea txtDescription=new TextArea();
    Label lblDate=new Label("");
    Button btnClose=new Button("Close");    

    ViewPropertiesDialog(Frame parent, InventoryItem item) {
      super(parent, "View Properties Dialog", true);

      String strImage=item.getStrImage();

      lblName.setText(item.getName());
      lblWeight.setText(String.valueOf(item.getWeight()));
      lblWeightMax.setText(String.valueOf(item.getWeightMax()));
      if(strImage!=null)
        lblImage.setText(strImage);
      txtDescription.setText(item.getDescription());

      Panel tempPanZ=new Panel();
      tempPanZ.setLayout(new GridLayout(3, 1));

      Panel tempPan=new Panel();
      tempPan.setLayout(new BorderLayout());
      tempPan.add("West", new Label("Name: "));
      tempPan.add("Center", lblName);
      tempPanZ.add(tempPan);
      Panel tempPanZ1=new Panel();
      tempPanZ1.setLayout(new BorderLayout());
      tempPanZ1.add("West", new Label("Weight: "));
      tempPanZ1.add("Center", lblWeight);
      tempPanZ.add(tempPanZ1);
      Panel tempPanZ2=new Panel();
      tempPanZ2.setLayout(new BorderLayout());
      tempPanZ2.add("West", new Label("Weight Max: "));
      tempPanZ2.add("Center", lblWeightMax);
      tempPanZ.add(tempPanZ2);

      add("North", tempPanZ);

      Panel tempPan2=new Panel();
      tempPan2.setLayout(new BorderLayout());
      tempPan2.add("North", new Label("Description:"));
      tempPan2.add("Center", txtDescription);
      add("Center", tempPan2);

      Date dateExpiration=item.getDateExpiration();
      if(dateExpiration==null) {
        if(strImage==null) {
          Panel tempPan3=new Panel();
          tempPan3.add(btnClose);
          btnClose.addActionListener(this);
          add("South", tempPan3);
        }
        else {
          Panel tempPan3=new Panel();
          tempPan3.setLayout(new GridLayout(2, 1));
          Panel tempPan3A=new Panel();
          tempPan3A.setLayout(new BorderLayout());
          tempPan3A.add("West", new Label("Image:"));
          tempPan3A.add("Center", lblImage);
          tempPan3.add(tempPan3A);
          Panel tempPan3B=new Panel();
          tempPan3B.add(btnClose);
          btnClose.addActionListener(this);
          tempPan3.add(tempPan3B);
          add("South", tempPan3);
        }
      }
      else {
        lblDate.setText(dateExpiration.toString());

        if(strImage==null) {
          Panel tempPan3=new Panel();
          tempPan3.setLayout(new GridLayout(2, 1));
          Panel tempPan3A=new Panel();
          tempPan3A.setLayout(new BorderLayout());
          tempPan3A.add("West", new Label("Expiration:"));
          tempPan3A.add("Center", lblDate);
          tempPan3.add(tempPan3A);
          Panel tempPan3B=new Panel();
          tempPan3B.add(btnClose);
          btnClose.addActionListener(this);
          tempPan3.add(tempPan3B);
          add("South", tempPan3);
        }
        else {
          Panel tempPan3=new Panel();
          tempPan3.setLayout(new GridLayout(3, 1));
          Panel tempPan3A=new Panel();
          tempPan3A.setLayout(new BorderLayout());
          tempPan3A.add("West", new Label("Image:"));
          tempPan3A.add("Center", lblImage);
          tempPan3.add(tempPan3A);
          Panel tempPan3B=new Panel();
          tempPan3B.setLayout(new BorderLayout());
          tempPan3B.add("West", new Label("Expiration:"));
          tempPan3B.add("Center", lblDate);
          tempPan3.add(tempPan3B);
          Panel tempPan3C=new Panel();
          tempPan3C.add(btnClose);
          btnClose.addActionListener(this);
          tempPan3.add(tempPan3C);
          add("South", tempPan3);
        }
      }

      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnClose) {
        dispose();
      }
    }
  }

  class SetPropertiesDialog extends Dialog
  implements ActionListener {
    TextField txtName=new TextField();
    TextField txtWeight=new TextField();
    TextField txtWeightMax=new TextField();
    TextField txtDateYear=new TextField();
    TextField txtDateMonth=new TextField();
    TextField txtDateDay=new TextField();
    TextArea txtDescription=new TextArea();
    Button btnSetProperties=new Button("Set Properties");
    Button btnCancel=new Button("Cancel");
    boolean cancelIt=false;

    InventoryItem item;

    SetPropertiesDialog(Frame parent, InventoryItem item) {
      super(parent, "Set Properties Dialog", true);
      this.item=item;

      txtName.setText(item.getName());
      txtWeight.setText(String.valueOf(item.getWeight()));
      txtWeightMax.setText(String.valueOf(item.getWeightMax()));
      txtDescription.setText(item.getDescription());
      Date dateExpiration=item.getDateExpiration();
      if(dateExpiration!=null) {
        txtDateYear.setText(String.valueOf(dateExpiration.getYear()+1900));
        txtDateMonth.setText(String.valueOf(dateExpiration.getMonth()+1));
        txtDateDay.setText(String.valueOf(dateExpiration.getDate()));
      }

      Panel tempPan=new Panel();
      tempPan.setLayout(new GridLayout(6, 2));
      tempPan.add(new Label("Name:"));
      tempPan.add(txtName);
      tempPan.add(new Label("Weight:"));
      tempPan.add(txtWeight);
      tempPan.add(new Label("Weight Max:"));
      tempPan.add(txtWeightMax);
      tempPan.add(new Label("Expiration Year:"));
      tempPan.add(txtDateYear);
      tempPan.add(new Label("Expiration Month:"));
      tempPan.add(txtDateMonth);
      tempPan.add(new Label("Expiration Day:"));
      tempPan.add(txtDateDay);
      add("North", tempPan);

      Panel tempPan2=new Panel();
      tempPan2.setLayout(new BorderLayout());
      tempPan2.add("North", new Label("Description:"));
      tempPan2.add("Center", txtDescription);
      add("Center", tempPan2);

      Panel tempPan3=new Panel();
      tempPan3.add(btnSetProperties);
      btnSetProperties.addActionListener(this);
      tempPan3.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", tempPan3);

      setLocation(screenDim.width/4, screenDim.height/8);
      setSize(screenDim.width/2, screenDim.height*3/4);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnSetProperties) {
        String strName=txtName.getText();
        if(strName.length()==0) {
          txtName.setText("Name required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex) {
          }
          txtName.setText("");

          return;
        }

        if(strName.indexOf('*')!=-1) {
          txtName.setText("Name can't contain '*'.");
          try {
            Thread.sleep(4000);
          }
          catch(Exception ex) {
          }
          txtName.setText(strName);

          return;
        }

        String strWeight=txtWeight.getText();
        int intWeight=0;
        if(strWeight.length()>0) {
          try {
            intWeight=Integer.parseInt(strWeight);
          }
          catch(Exception ex) {
            txtWeight.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtWeight.setText(strWeight);

            return;
          }

          if(intWeight<0) {
            txtWeight.setText("Positive digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtWeight.setText(strWeight);

            return;
          }
        }

        String strWeightMax=txtWeightMax.getText();
        int intWeightMax=0;
        if(strWeightMax.length()>0) {
          try {
            intWeightMax=Integer.parseInt(strWeightMax);
          }
          catch(Exception ex) {
            txtWeightMax.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtWeightMax.setText(strWeightMax);

            return;
          }

          if(intWeightMax<0) {
            txtWeightMax.setText("Positive digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtWeightMax.setText(strWeightMax);

            return;
          }
        }

        if(intWeightMax<intWeight) {
          txtWeightMax.setText("Must be greater than or equal to Weight.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex2) {
          }
          txtWeightMax.setText(strWeightMax);

          return;
        }

        String strDateYear=txtDateYear.getText();
        String strDateMonth=txtDateMonth.getText();
        String strDateDay=txtDateDay.getText();
        boolean blnHasDate=true;
        if(strDateYear.length()==0)
          blnHasDate=false;
        if(strDateMonth.length()==0)
          blnHasDate=false;
        if(strDateDay.length()==0)
          blnHasDate=false;

        int intDateYear=-1;
        int intDateMonth=-1;
        int intDateDay=-1;
        if(blnHasDate) {
          try {
            intDateYear=Integer.parseInt(strDateYear);
          }
          catch(Exception ex) {
            txtDateYear.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateYear.setText(strDateYear);

            return;
          }
          intDateYear-=1900;

          try {
            intDateMonth=Integer.parseInt(strDateMonth);
          }
          catch(Exception ex) {
            txtDateMonth.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateMonth.setText(strDateMonth);

            return;
          }

          if(intDateMonth<1 || intDateMonth>12) {
            txtDateMonth.setText("Digits 1-12 required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateMonth.setText(strDateMonth);

            return;
          }
          intDateMonth-=1;

          
          try {
            intDateDay=Integer.parseInt(strDateDay);
          }
          catch(Exception ex) {
            txtDateDay.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateDay.setText(strDateDay);

            return;
          }

          if(intDateDay<1 || intDateDay>31) {
            txtDateDay.setText("Digits 1-31 required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateDay.setText(strDateDay);

            return;
          }
        }

        String strDescription=txtDescription.getText();
        if(strDescription.indexOf('*')!=-1) {
          txtDescription.setText("Description can't contain '*'.");
          try {
            Thread.sleep(4000);
          }
          catch(Exception ex) {
          }
          txtDescription.setText(strDescription);

          return;
        }

        item.setName(strName);
        item.setDescription(strDescription);
        item.setWeight(intWeight);
        item.setWeightMax(intWeightMax);
        if(blnHasDate)
          item.setDateExpiration(new Date(intDateYear, intDateMonth, intDateDay));
        else
          item.setDateExpiration(null);

        blnChangesMade=true;

        iCanv.repaint();

        cancelIt=false;
      }
      else if(evSource==btnCancel) {
        cancelIt=true;
      }
      dispose();
    }
  }

  class AddInventoryDialog extends Dialog
  implements ActionListener {
    int intX=-1;
    int intY=-1;
    int intWidth=-1;
    int intHeight=-1;
    CheckboxGroup cbg=new CheckboxGroup();
    Checkbox cbItem=new Checkbox("Item", cbg, true);
    Checkbox cbContainer=new Checkbox("Container", cbg, false);
    TextField txtName=new TextField();
    TextField txtWeight=new TextField();
    TextField txtWeightMax=new TextField();
    TextField txtDateYear=new TextField();
    TextField txtDateMonth=new TextField();
    TextField txtDateDay=new TextField();
    TextArea txtDescription=new TextArea();
    Button btnAddInventory=new Button("Add Inventory");
    Button btnCancel=new Button("Cancel");
    boolean cancelIt=false;

    InventoryItem item;

    AddInventoryDialog(Frame parent) {
      super(parent, "Add Inventory Dialog", true);

      cbContainer.setState(true);
      cbItem.setEnabled(false);

      Panel tempPan=new Panel();
      tempPan.setLayout(new GridLayout(7, 2));
      tempPan.add(cbItem);
      tempPan.add(cbContainer);
      tempPan.add(new Label("Name:"));
      tempPan.add(txtName);
      tempPan.add(new Label("Weight:"));
      tempPan.add(txtWeight);
      tempPan.add(new Label("Weight Max:"));
      tempPan.add(txtWeightMax);
      tempPan.add(new Label("Expiration Year:"));
      tempPan.add(txtDateYear);
      tempPan.add(new Label("Expiration Month:"));
      tempPan.add(txtDateMonth);
      tempPan.add(new Label("Expiration Day:"));
      tempPan.add(txtDateDay);
      add("North", tempPan);

      Panel tempPan2=new Panel();
      tempPan2.setLayout(new BorderLayout());
      tempPan2.add("North", new Label("Description:"));
      tempPan2.add("Center", txtDescription);
      add("Center", tempPan2);

      Panel tempPan3=new Panel();
      tempPan3.add(btnAddInventory);
      btnAddInventory.addActionListener(this);
      tempPan3.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", tempPan3);

      setLocation(screenDim.width/4, screenDim.height/8);
      setSize(screenDim.width/2, screenDim.height*3/4);
    }

    AddInventoryDialog(Frame parent, int intX, int intY, int intWidth, int intHeight) {
      super(parent, "Add Inventory Dialog", true);
      this.intX=intX;
      this.intY=intY;
      this.intWidth=intWidth;
      this.intHeight=intHeight;

      Panel tempPan=new Panel();
      tempPan.setLayout(new GridLayout(7, 2));
      tempPan.add(cbItem);
      tempPan.add(cbContainer);
      tempPan.add(new Label("Name:"));
      tempPan.add(txtName);
      tempPan.add(new Label("Weight:"));
      tempPan.add(txtWeight);
      tempPan.add(new Label("Weight Max:"));
      tempPan.add(txtWeightMax);
      tempPan.add(new Label("Expiration Year:"));
      tempPan.add(txtDateYear);
      tempPan.add(new Label("Expiration Month:"));
      tempPan.add(txtDateMonth);
      tempPan.add(new Label("Expiration Day:"));
      tempPan.add(txtDateDay);
      add("North", tempPan);

      Panel tempPan2=new Panel();
      tempPan2.setLayout(new BorderLayout());
      tempPan2.add("North", new Label("Description:"));
      tempPan2.add("Center", txtDescription);
      add("Center", tempPan2);

      Panel tempPan3=new Panel();
      tempPan3.add(btnAddInventory);
      btnAddInventory.addActionListener(this);
      tempPan3.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", tempPan3);

      setLocation(screenDim.width/4, screenDim.height/8);
      setSize(screenDim.width/2, screenDim.height*3/4);
    }

    public InventoryItem getItem() {
      return item;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnAddInventory) {
        String strName=txtName.getText();
        if(strName.length()==0) {
          txtName.setText("Name required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex) {
          }
          txtName.setText("");

          return;
        }

        if(strName.indexOf('*')!=-1) {
          txtName.setText("Name can't contain '*'.");
          try {
            Thread.sleep(4000);
          }
          catch(Exception ex) {
          }
          txtName.setText(strName);

          return;
        }

        String strWeight=txtWeight.getText();
        int intWeight=0;
        if(strWeight.length()>0) {
          try {
            intWeight=Integer.parseInt(strWeight);
          }
          catch(Exception ex) {
            txtWeight.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtWeight.setText(strWeight);

            return;
          }

          if(intWeight<0) {
            txtWeight.setText("Positive digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtWeight.setText(strWeight);

            return;
          }
        }

        String strWeightMax=txtWeightMax.getText();
        int intWeightMax=0;
        if(strWeightMax.length()>0) {
          try {
            intWeightMax=Integer.parseInt(strWeightMax);
          }
          catch(Exception ex) {
            txtWeightMax.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtWeightMax.setText(strWeightMax);

            return;
          }

          if(intWeightMax<0) {
            txtWeightMax.setText("Positive digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtWeightMax.setText(strWeightMax);

            return;
          }
        }

        if(intWeightMax<intWeight) {
          txtWeightMax.setText("Must be greater than or equal to Weight.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex2) {
          }
          txtWeightMax.setText(strWeightMax);

          return;
        }

        String strDateYear=txtDateYear.getText();
        String strDateMonth=txtDateMonth.getText();
        String strDateDay=txtDateDay.getText();
        boolean blnHasDate=true;
        if(strDateYear.length()==0)
          blnHasDate=false;
        if(strDateMonth.length()==0)
          blnHasDate=false;
        if(strDateDay.length()==0)
          blnHasDate=false;

        int intDateYear=-1;
        int intDateMonth=-1;
        int intDateDay=-1;
        if(blnHasDate) {
          try {
            intDateYear=Integer.parseInt(strDateYear);
          }
          catch(Exception ex) {
            txtDateYear.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateYear.setText(strDateYear);

            return;
          }
          intDateYear-=1900;

          try {
            intDateMonth=Integer.parseInt(strDateMonth);
          }
          catch(Exception ex) {
            txtDateMonth.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateMonth.setText(strDateMonth);

            return;
          }

          if(intDateMonth<1 || intDateMonth>12) {
            txtDateMonth.setText("Digits 1-12 required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateMonth.setText(strDateMonth);

            return;
          }
          intDateMonth-=1;

          
          try {
            intDateDay=Integer.parseInt(strDateDay);
          }
          catch(Exception ex) {
            txtDateDay.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateDay.setText(strDateDay);

            return;
          }

          if(intDateDay<1 || intDateDay>31) {
            txtDateDay.setText("Digits 1-31 required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateDay.setText(strDateDay);

            return;
          }
        }

        String strDescription=txtDescription.getText();
        if(strDescription.indexOf('*')!=-1) {
          txtDescription.setText("Description can't contain '*'.");
          try {
            Thread.sleep(4000);
          }
          catch(Exception ex) {
          }
          txtDescription.setText(strDescription);

          return;
        }

        if(cbItem.getState()) {
          if(blnHasDate) {
            Date dateExpiration=new Date(intDateYear, intDateMonth, intDateDay);
            item=new InventoryItem(strName, strDescription, intX, intY, intWidth, intHeight, intWeight, intWeightMax, dateExpiration);
          }
          else {
            item=new InventoryItem(strName, strDescription, intX, intY, intWidth, intHeight, intWeight, intWeightMax);
          }
        }
        else if(cbContainer.getState()) {
          if(blnHasDate) {
            Date dateExpiration=new Date(intDateYear, intDateMonth, intDateDay);
            item=new InventoryContainer(strName, strDescription, intX, intY, intWidth, intHeight, intWeight, intWeightMax, dateExpiration);
          }
          else {
            item=new InventoryContainer(strName, strDescription, intX, intY, intWidth, intHeight, intWeight, intWeightMax);
          }
        }
        item.setHashCode((InventoryFrame)refThis);

        cancelIt=false;
      }
      else if(evSource==btnCancel) {
        cancelIt=true;
      }
      dispose();
    }
  }

  class InventoryContainerSizeDialog extends Dialog
  implements ActionListener {
    TextField txtWidth=new TextField();
    TextField txtHeight=new TextField();
    Button btnInputSize=new Button("Input Size");
    int intWidth=-1;
    int intHeight=-1;

    InventoryContainerSizeDialog(Frame parent) {
      super(parent, "Inventory Container Size Dialog", true);

      Panel tempPan=new Panel();
      tempPan.setLayout(new GridLayout(2, 2));
      tempPan.add(new Label("Width:"));
      tempPan.add(txtWidth);
      tempPan.add(new Label("Height:"));
      tempPan.add(txtHeight);
      add("North", tempPan);

      add("Center", new Label(""));

      Panel tempPan2=new Panel();
      tempPan2.add(btnInputSize);
      btnInputSize.addActionListener(this);
      add("South", tempPan2);

      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public int getInputContainerWidth() {
      return intWidth;
    }

    public int getInputContainerHeight() {
      return intHeight;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnInputSize) {
        String strWidth=txtWidth.getText();
        if(strWidth.length()==0) {
          txtWidth.setText("Width required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex) {
          }
          txtWidth.setText("");

          return;
        }

        try {
          intWidth=Integer.parseInt(strWidth);
        }
        catch(Exception ex) {
          txtWidth.setText("Digits required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex2) {
          }
          txtWidth.setText(strWidth);

          return;
        }

        if(intWidth<1) {
          txtWidth.setText("Positive digits required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex2) {
          }
          txtWidth.setText(strWidth);

          return;
        }


        String strHeight=txtHeight.getText();
        if(strHeight.length()==0) {
          txtHeight.setText("Height required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex) {
          }
          txtHeight.setText("");

          return;
        }

        try {
          intHeight=Integer.parseInt(strHeight);
        }
        catch(Exception ex) {
          txtHeight.setText("Digits required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex2) {
          }
          txtHeight.setText(strHeight);

          return;
        }

        if(intHeight<1) {
          txtHeight.setText("Positive digits required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex2) {
          }
          txtHeight.setText(strHeight);

          return;
        }

        dispose();
      }
    }
  }

  class InventoryResizerDialog extends Dialog
  implements ActionListener {
    InventoryItem item;
    TextField txtWidth=new TextField();
    TextField txtHeight=new TextField();
    Button btnUpdate=new Button("Update");
    Button btnSet=new Button("Set");
    Button btnCancel=new Button("Cancel");

    InventoryResizerDialog(Frame parent, InventoryItem item, int intResizingWidth0, int intResizingHeight0) {
      super(parent, "Inventory Resizer Dialog", false);
      this.item=item;

      txtWidth.setText(String.valueOf(intResizingWidth0));
      txtHeight.setText(String.valueOf(intResizingHeight0));

      Panel tempPan=new Panel();
      tempPan.setLayout(new GridLayout(2, 2));
      tempPan.add(new Label("Width:"));
      tempPan.add(txtWidth);
      tempPan.add(new Label("Height:"));
      tempPan.add(txtHeight);
      add("North", tempPan);

      add("Center", new Label(""));

      Panel tempPan2=new Panel();
      tempPan2.add(btnUpdate);
      btnUpdate.addActionListener(this);
      tempPan2.add(btnSet);
      btnSet.addActionListener(this);
      tempPan2.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", tempPan2);

      setLocation(screenDim.width/3, screenDim.height/3);
      setSize(screenDim.width/3, screenDim.height/3);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnUpdate) {
        String strWidth=txtWidth.getText();
        if(strWidth.length()==0) {
          txtWidth.setText("Width required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex) {
          }
          txtWidth.setText("");

          return;
        }

        int intWidth=-1;
        try {
          intWidth=Integer.parseInt(strWidth);
        }
        catch(Exception ex) {
          txtWidth.setText("Digits required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex2) {
          }
          txtWidth.setText(strWidth);

          return;
        }

        if(intWidth<1) {
          txtWidth.setText("Positive digits required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex2) {
          }
          txtWidth.setText(strWidth);

          return;
        }


        String strHeight=txtHeight.getText();
        if(strHeight.length()==0) {
          txtHeight.setText("Height required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex) {
          }
          txtHeight.setText("");

          return;
        }

        int intHeight=-1;
        try {
          intHeight=Integer.parseInt(strHeight);
        }
        catch(Exception ex) {
          txtHeight.setText("Digits required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex2) {
          }
          txtHeight.setText(strHeight);

          return;
        }

        if(intHeight<1) {
          txtHeight.setText("Positive digits required.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex2) {
          }
          txtHeight.setText(strHeight);

          return;
        }

        intResizingWidth=intWidth;
        intResizingHeight=intHeight;

        boolean blnDoInvalidate=false;
        if((item.getX()+intResizingWidth)>=inventoryCurrent.getContainerWidth()) {
          inventoryCurrent.setContainerWidth(item.getX()+intResizingWidth+1);
          blnDoInvalidate=true;
        }
        if((item.getY()+intResizingHeight)>=inventoryCurrent.getContainerHeight()) {
          inventoryCurrent.setContainerHeight(item.getY()+intResizingHeight+1);
          blnDoInvalidate=true;
        }

        if(blnDoInvalidate) {
          sPane.invalidate();
          sPane.validate();
        }

        iCanv.repaint();
      }
      else if(evSource==btnSet) {
        Rectangle rectangle0=new Rectangle(item.getX(), item.getY(), intResizingWidth, intResizingHeight);

        Vector vecItems=inventoryCurrent.getItems();
        for(int i=0;i<vecItems.size();i++) {
          InventoryItem nextItem=(InventoryItem)vecItems.elementAt(i);
          if(nextItem==item)
            continue;

          int intNextX=nextItem.getX();
          int intNextY=nextItem.getY();
          int intNextWidth=nextItem.getWidth();
          int intNextHeight=nextItem.getHeight();

          Rectangle rectangle1=new Rectangle(intNextX, intNextY, intNextWidth, intNextHeight);

          if(rectangle0.intersects(rectangle1)) {
            return;
          }
        }

        inventoryCurrent.freeSpace(item);

        item.setWidth(intResizingWidth);
        item.setHeight(intResizingHeight);

        inventoryCurrent.findNewLocation2(item);

        blnResizingInventory=false;

        blnChangesMade=true;

        iCanv.repaint();

        dispose();
      }
      else if(evSource==btnCancel) {
        blnResizingInventory=false;

        iCanv.repaint();

        dispose();
      }
    }
  }

  class ConfirmDialog extends Dialog
  implements ActionListener {
    Button btnConfirm=new Button("Confirm");
    Button btnCancel=new Button("Cancel");
    boolean cancelIt=false;

    ConfirmDialog(Frame parent, String strTitle, String strLabel) {
      super(parent, strTitle, true);

      add("Center", new Label(strLabel));

      Panel tempPan=new Panel();
      tempPan.add(btnConfirm);
      btnConfirm.addActionListener(this);
      tempPan.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", tempPan);

      setLocation(0, screenDim.height/3);
      setSize(screenDim.width, screenDim.height/3);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnConfirm) {
        cancelIt=false;
      }
      else if(evSource==btnCancel) {
        cancelIt=true;
      }
      dispose();
    }     
  }

  class SearchDialog extends Dialog
  implements ActionListener {
    TextField txtName=new TextField();
    TextField txtDescription=new TextField();
    TextField txtWeight=new TextField();
    TextField txtWeight2=new TextField();
    TextField txtDateYear=new TextField();
    TextField txtDateMonth=new TextField();
    TextField txtDateDay=new TextField();
    CheckboxGroup cbg=new CheckboxGroup();
    Checkbox cbDateBefore=new Checkbox("Before", cbg, true);
    Checkbox cbDateAfter=new Checkbox("After", cbg, false);
    List lstResults=new List(5);
    Vector vecResults=new Vector();
    Button btnSearch=new Button("Search");
    Button btnViewProperties=new Button("View Properties");
    Button btnNavigateTo=new Button("Navigate To");
    Button btnClose=new Button("Close");

    SearchDialog(Frame parent) {
      super(parent, "Search Dialog", false);

      Panel tempPan=new Panel();
      tempPan.setLayout(new GridLayout(7, 2));
      tempPan.add(new Label("Name:"));
      tempPan.add(txtName);
      tempPan.add(new Label("Description:"));
      tempPan.add(txtDescription);
      tempPan.add(new Label("Weight:"));
      Panel tempPanA=new Panel();
      tempPanA.setLayout(new GridLayout(1, 3));
      tempPanA.add(txtWeight);
      tempPanA.add(new Label("-"));
      tempPanA.add(txtWeight2);
      tempPan.add(tempPanA);
      tempPan.add(new Label("Expiration Year:"));
      tempPan.add(txtDateYear);
      tempPan.add(new Label("Expiration Month:"));
      tempPan.add(txtDateMonth);
      tempPan.add(new Label("Expiration Day:"));
      tempPan.add(txtDateDay);
      tempPan.add(cbDateBefore);
      tempPan.add(cbDateAfter);
      add("North", tempPan);

      Panel tempPan2=new Panel();
      tempPan2.setLayout(new BorderLayout());
      tempPan2.add("North", new Label("Results:"));
      tempPan2.add("Center", lstResults);
      add("Center", tempPan2);

      Panel tempPan3=new Panel();
      tempPan3.add(btnSearch);
      btnSearch.addActionListener(this);
      tempPan3.add(btnViewProperties);
      btnViewProperties.addActionListener(this);
      tempPan3.add(btnNavigateTo);
      btnNavigateTo.addActionListener(this);
      tempPan3.add(btnClose);
      btnClose.addActionListener(this);
      add("South", tempPan3);

      setLocation(screenDim.width/4, screenDim.height/8);
      setSize(screenDim.width/2, screenDim.height*3/4);
    }

    public Vector searchForMatches(Vector vecParents, InventoryItem item, String strName, String strDescription, int intWeight, int intWeight2) {
      Vector vecRet=new Vector();

      boolean blnMatchFound=true;

      String strName2=item.getName();
      int intIndex=-1;
      int intIndex2=-1;
      int intIndex3=-1;
      int intCurrentStart=0;
      if(!strName.startsWith("*")) {
        intIndex=strName.indexOf('*', intIndex+1);
        if(intIndex==-1) {
          if(!strName.equals(strName2))
            blnMatchFound=false;
        }
        else {
          String strNextPiece=strName.substring(0, intIndex);
          if(strName2.length()<intIndex)
            blnMatchFound=false;
          else {
            String strNextPiece2=strName2.substring(0, intIndex);
            intCurrentStart=intIndex;
            if(!strNextPiece.equals(strNextPiece2))
              blnMatchFound=false;
          }
        }
      }
      else
        intIndex=0;
      if(blnMatchFound) {
        while(intIndex!=-1) {
          intIndex2=strName.indexOf('*', intIndex+1);

          if(intIndex2==-1) {
            if((intIndex+1)!=strName.length()) {
              String strNextPiece=strName.substring(intIndex+1);
              String strNextPiece2=strName2.substring(intCurrentStart);
              intIndex3=strNextPiece2.indexOf(strNextPiece);
              if(intIndex3!=(strNextPiece2.length()-strNextPiece.length()))
                blnMatchFound=false;
            }
            break;
          }
          else {
            String strNextPiece=strName.substring(intIndex+1, intIndex2);
            String strNextPiece2=strName2.substring(intCurrentStart);
            intIndex3=strNextPiece2.indexOf(strNextPiece);
            if(intIndex3==-1) {
              blnMatchFound=false;
              break;
            }
            intCurrentStart=intIndex3+strNextPiece.length();
            intIndex=intIndex2;
          }
        }
      }

      if(blnMatchFound) {
        String strDescription2=item.getDescription();
        intIndex=-1;
        intIndex2=-1;
        intIndex3=-1;
        intCurrentStart=0;
        if(!strDescription.startsWith("*")) {
          intIndex=strDescription.indexOf('*', intIndex+1);
          if(intIndex==-1) {
            if(!strDescription.equals(strDescription2))
              blnMatchFound=false;
          }
          else {
            String strNextPiece=strDescription.substring(0, intIndex);
            if(strDescription2.length()<intIndex)
              blnMatchFound=false;
            else {
              String strNextPiece2=strDescription2.substring(0, intIndex);
              intCurrentStart=intIndex;
              if(!strNextPiece.equals(strNextPiece2))
                blnMatchFound=false;
            }
          }
        }
        else
          intIndex=0;
        if(blnMatchFound) {
          while(intIndex!=-1) {
            intIndex2=strDescription.indexOf('*', intIndex+1);

            if(intIndex2==-1) {
              if((intIndex+1)!=strDescription.length()) {
                String strNextPiece=strDescription.substring(intIndex+1);
                String strNextPiece2=strDescription2.substring(intCurrentStart);
                intIndex3=strNextPiece2.indexOf(strNextPiece);
                if(intIndex3!=(strNextPiece2.length()-strNextPiece.length()))
                  blnMatchFound=false;
              }
              break;
            }
            else {
              String strNextPiece=strDescription.substring(intIndex+1, intIndex2);
              String strNextPiece2=strDescription2.substring(intCurrentStart);
              intIndex3=strNextPiece2.indexOf(strNextPiece);
              if(intIndex3==-1) {
                blnMatchFound=false;
                break;
              }
              intCurrentStart=intIndex3+strNextPiece.length();
              intIndex=intIndex2;
            }
          }
        }
      }

      if(blnMatchFound) {
        int intItemWeight=item.getWeight();
        if(intItemWeight<intWeight || intItemWeight>intWeight2)
          blnMatchFound=false;
      }

      if(blnMatchFound) {
        Vector vecResult=new Vector();
        for(int i=0;i<vecParents.size();i++)
          vecResult.addElement(vecParents.elementAt(i));
        vecResult.addElement(item);
        vecRet.addElement(vecResult);
      }

      if(item instanceof InventoryContainer) {
        vecParents.addElement(item);
        InventoryContainer container=(InventoryContainer)item;
        Vector vecItems=container.getItems();
        for(int i=0;i<vecItems.size();i++) {
          InventoryItem item2=(InventoryItem)vecItems.elementAt(i);
          Vector vecRet2=searchForMatches(vecParents, item2, strName, strDescription, intWeight, intWeight2);
          for(int ia=0;ia<vecRet2.size();ia++)
            vecRet.addElement(vecRet2.elementAt(ia));
        }
      }

      return vecRet;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnSearch) {
        String strName=txtName.getText();
        if(strName.length()==0)
          strName="*";
        String strDescription=txtDescription.getText();
        if(strDescription.length()==0)
          strDescription="*";

        String strWeight=txtWeight.getText();
        int intWeight=0;
        if(strWeight.length()>0) {
          try {
            intWeight=Integer.parseInt(strWeight);
          }
          catch(Exception ex) {
            txtWeight.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtWeight.setText(strWeight);

            return;
          }

          if(intWeight<0) {
            txtWeight.setText("Positive digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtWeight.setText(strWeight);

            return;
          }
        }

        String strWeight2=txtWeight2.getText();
        int intWeight2=Integer.MAX_VALUE;
        if(strWeight2.length()>0) {
          try {
            intWeight2=Integer.parseInt(strWeight2);
          }
          catch(Exception ex) {
            txtWeight2.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtWeight2.setText(strWeight2);

            return;
          }

          if(intWeight2<0) {
            txtWeight2.setText("Positive digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtWeight2.setText(strWeight2);

            return;
          }
        }

        if(intWeight2<intWeight) {
          txtWeight2.setText("Must be greater than previous field.");
          try {
            Thread.sleep(3000);
          }
          catch(Exception ex2) {
          }
          txtWeight2.setText(strWeight2);

          return;
        }

        String strDateYear=txtDateYear.getText();
        String strDateMonth=txtDateMonth.getText();
        String strDateDay=txtDateDay.getText();
        boolean blnHasDate=true;
        if(strDateYear.length()==0)
          blnHasDate=false;
        if(strDateMonth.length()==0)
          blnHasDate=false;
        if(strDateDay.length()==0)
          blnHasDate=false;

        int intDateYear=-1;
        int intDateMonth=-1;
        int intDateDay=-1;
        if(blnHasDate) {
          try {
            intDateYear=Integer.parseInt(strDateYear);
          }
          catch(Exception ex) {
            txtDateYear.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateYear.setText(strDateYear);

            return;
          }
          intDateYear-=1900;

          try {
            intDateMonth=Integer.parseInt(strDateMonth);
          }
          catch(Exception ex) {
            txtDateMonth.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateMonth.setText(strDateMonth);

            return;
          }

          if(intDateMonth<1 || intDateMonth>12) {
            txtDateMonth.setText("Digits 1-12 required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateMonth.setText(strDateMonth);

            return;
          }
          intDateMonth-=1;

          
          try {
            intDateDay=Integer.parseInt(strDateDay);
          }
          catch(Exception ex) {
            txtDateDay.setText("Digits required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateDay.setText(strDateDay);

            return;
          }

          if(intDateDay<1 || intDateDay>31) {
            txtDateDay.setText("Digits 1-31 required.");
            try {
              Thread.sleep(3000);
            }
            catch(Exception ex2) {
            }
            txtDateDay.setText(strDateDay);

            return;
          }
        }

        vecResults=searchForMatches(new Vector(), inventoryParent, strName, strDescription, intWeight, intWeight2);

        if(blnHasDate) {
          Date date=new Date(intDateYear, intDateMonth, intDateDay);
          if(cbDateBefore.getState()) {
            for(int i=0;i<vecResults.size();i++) {
              Vector vecResult=(Vector)vecResults.elementAt(i);
              InventoryItem item=(InventoryItem)vecResult.elementAt(vecResult.size()-1);
              Date date2=item.getDateExpiration();
              if(date2==null) {
                vecResults.removeElementAt(i);
                --i;
                continue;
              }
              if(!date2.before(date)) {
                vecResults.removeElementAt(i);
                --i;
              }
            }
          }
          else if(cbDateAfter.getState()) {
            for(int i=0;i<vecResults.size();i++) {
              Vector vecResult=(Vector)vecResults.elementAt(i);
              InventoryItem item=(InventoryItem)vecResult.elementAt(vecResult.size()-1);
              Date date2=item.getDateExpiration();
              if(date2==null) {
                vecResults.removeElementAt(i);
                --i;
                continue;
              }
              if(!date2.after(date)) {
                vecResults.removeElementAt(i);
                --i;
              }
            }
          }
        }

        lstResults.removeAll();
        for(int i=0;i<vecResults.size();i++) {
          Vector vecResult=(Vector)vecResults.elementAt(i);
          InventoryItem item=(InventoryItem)vecResult.elementAt(vecResult.size()-1);
          lstResults.add(item.getName());
        }
      }
      else if(evSource==btnViewProperties) {
        int intSelIndex=lstResults.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        Vector vecResult=(Vector)vecResults.elementAt(intSelIndex);
        InventoryItem item=(InventoryItem)vecResult.elementAt(vecResult.size()-1);
        
        ViewPropertiesDialog vDialog=new ViewPropertiesDialog(refThis, item);
        vDialog.show();
      }
      else if(evSource==btnNavigateTo) {
        int intSelIndex=lstResults.getSelectedIndex();
        if(intSelIndex==-1)
          return;

        Vector vecResult=(Vector)vecResults.elementAt(intSelIndex);
        vecInventoryParents=vecResult;
        if(vecInventoryParents.size()==1)
          inventoryCurrent=(InventoryContainer)vecInventoryParents.elementAt(vecInventoryParents.size()-1);
        else {
          inventoryCurrent=(InventoryContainer)vecInventoryParents.elementAt(vecInventoryParents.size()-2);
          inventorySearch=(InventoryItem)vecInventoryParents.elementAt(vecInventoryParents.size()-1);
          blnSearched=true;
          vecInventoryParents.removeElementAt(vecInventoryParents.size()-1);

          sPane.setScrollPosition(inventorySearch.getX(), inventorySearch.getY());
        }

        sPane.invalidate();
        sPane.validate();
        iCanv.repaint();

        dispose();
      }
      else if(evSource==btnClose) {
        dispose();
      }
    }
  }

  class MessageDialog extends Dialog
  implements ActionListener {
    Button btnClose=new Button("Close");

    MessageDialog(Frame parent, String strTitle, String strLabel) {
      super(parent, strTitle, true);

      add("Center", new Label(strLabel));

      Panel tempPan=new Panel();
      tempPan.add(btnClose);
      btnClose.addActionListener(this);
      add("South", tempPan);

      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnClose) {
        dispose();
      }
    }
  }

  class ListDisplayDialog extends Dialog
  implements ActionListener {
    Button btnClose=new Button("Close");

    ListDisplayDialog(Frame parent, String strTitle, String strLabel, String strDisplay[]) {
      super(parent, strTitle, true);

      List lstDisplay=new List(5);

      for(int i=0;i<strDisplay.length;i++)
        lstDisplay.add(strDisplay[i]);

      add("North", new Label(strLabel));

      add("Center", lstDisplay);

      Panel tempPan=new Panel();
      tempPan.add(btnClose);
      btnClose.addActionListener(this);
      add("South", tempPan);

      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnClose) {
        dispose();
      }
    }
  }
}