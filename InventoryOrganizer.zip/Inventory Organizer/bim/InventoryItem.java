package bim;

import java.io.Serializable;
import java.io.File;
import java.util.Date;
import java.util.Vector;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

class InventoryItem
implements Serializable {
  transient int intHashCode=-1;
  String strName;
  String strDescription;
  Integer intX;
  Integer intY;
  Integer intWidth;
  Integer intHeight;
  Integer intWeight;
  Integer intWeightMax;
  Date dateExpiration;
  String strImage;
  transient BufferedImage bufImage;
  transient InventoryContainer container;

  InventoryItem() {
  }

  InventoryItem(String strName, String strDescription, int intX, int intY, int intWidth, int intHeight, int intWeight) {
    this.strName=strName;
    this.strDescription=strDescription;
    this.intX=new Integer(intX);
    this.intY=new Integer(intY);
    this.intWidth=new Integer(intWidth);
    this.intHeight=new Integer(intHeight);
    this.intWeight=new Integer(intWeight);
    this.intWeightMax=new Integer(intWeight);
  }

  InventoryItem(String strName, String strDescription, int intX, int intY, int intWidth, int intHeight, int intWeight, int intWeightMax) {
    this.strName=strName;
    this.strDescription=strDescription;
    this.intX=new Integer(intX);
    this.intY=new Integer(intY);
    this.intWidth=new Integer(intWidth);
    this.intHeight=new Integer(intHeight);
    this.intWeight=new Integer(intWeight);
    this.intWeightMax=new Integer(intWeightMax);
  }

  InventoryItem(String strName, String strDescription, int intX, int intY, int intWidth, int intHeight, int intWeight, Date dateExpiration) {
    this.strName=strName;
    this.strDescription=strDescription;
    this.intX=new Integer(intX);
    this.intY=new Integer(intY);
    this.intWidth=new Integer(intWidth);
    this.intHeight=new Integer(intHeight);
    this.intWeight=new Integer(intWeight);
    this.intWeightMax=new Integer(intWeightMax);
    this.dateExpiration=dateExpiration;
  }

  InventoryItem(String strName, String strDescription, int intX, int intY, int intWidth, int intHeight, int intWeight, int intWeightMax, Date dateExpiration) {
    this.strName=strName;
    this.strDescription=strDescription;
    this.intX=new Integer(intX);
    this.intY=new Integer(intY);
    this.intWidth=new Integer(intWidth);
    this.intHeight=new Integer(intHeight);
    this.intWeight=new Integer(intWeight);
    this.intWeightMax=new Integer(intWeightMax);
    this.dateExpiration=dateExpiration;
  }

  public String getName() {
    return strName;
  }

  public void setName(String strName) {
    this.strName=strName;
  }

  public String getDescription() {
    return strDescription;
  }

  public void setDescription(String strDescription) {
    this.strDescription=strDescription;
  }

  public int getX() {
    return intX.intValue();
  }

  public void setX(int intX) {
    this.intX=new Integer(intX);
  }

  public int getY() {
    return intY.intValue();
  }

  public void setY(int intY) {
    this.intY=new Integer(intY);
  }

  public int getWidth() {
    return intWidth.intValue();
  }

  public void setWidth(int intWidth) {
    this.intWidth=new Integer(intWidth);
  }

  public int getHeight() {
    return intHeight.intValue();
  }

  public void setHeight(int intHeight) {
    this.intHeight=new Integer(intHeight);
  }

  public int getWeight() {
    return intWeight.intValue();
  }

  public void setWeight(int intWeight) {
    this.intWeight=new Integer(intWeight);
  }

  public int getWeightMax() {
    return intWeightMax.intValue();
  }

  public void setWeightMax(int intWeightMax) {
    this.intWeightMax=new Integer(intWeightMax);
  }
  public Date getDateExpiration() {
    return dateExpiration;
  }

  public void setDateExpiration(Date dateExpiration) {
    this.dateExpiration=dateExpiration;
  }

  public String getStrImage() {
    return strImage;
  }

  public void setStrImage(String strImage) {
    this.strImage=strImage;
  }

  public BufferedImage getImage() {
    return bufImage;
  }

  public void setImage(BufferedImage bufImage) {
    this.bufImage=bufImage;
  }

  public Vector getParentPath() {
    Vector vecRet=new Vector();

    InventoryContainer nextContainer=getParent();
    InventoryContainer nextContainer2;
    if(nextContainer!=null)
      vecRet.addElement(new Integer(nextContainer.getItems().indexOf(this)));;
    while(nextContainer!=null) {
      nextContainer2=nextContainer;
      nextContainer=nextContainer.getParent();
      if(nextContainer==null)
        break;
      vecRet.insertElementAt(new Integer(nextContainer.getItems().indexOf(nextContainer2)), 0);;
    }

    return vecRet;
  }

  public InventoryContainer getParent() {
    return container;
  }

  public void setParent(InventoryContainer container) {
    this.container=container;
  }

  public void initializeImage(InventoryFrame iFrame) {
    if(strImage==null)
      return;

    if(iFrame.hashImages.containsKey(strImage)) {
      BufferedImage bufImage=(BufferedImage)iFrame.hashImages.get(strImage);

      setImage(bufImage);
    }
    else {
      String fSep=System.getProperty("file.separator");
      String strExtensions[]=ImageIO.getReaderFileSuffixes();
      for(int i=0;i<strExtensions.length;i++) {
        try {
          File fileImage=new File("images"+fSep+strImage+"."+strExtensions[i]);
          if(fileImage.exists()) {
            BufferedImage bufImage=ImageIO.read(fileImage);

            setImage(bufImage);

            iFrame.hashImages.put(strImage, bufImage);

            return;
          }
        }
        catch(Exception ex) {
          ex.printStackTrace();
        }
      }
    }
  }

  public boolean equals(Object obj) {
    if(hashCode()==obj.hashCode())
      return true;

    return false;
  }

  public int hashCode() {
    return intHashCode;
  }

  public void setHashCode(int intHashCode) {
    this.intHashCode=intHashCode;
  }

  public void setHashCode(InventoryFrame iFrame) {
    intHashCode=iFrame.uniqueHashCode++;
  }
}