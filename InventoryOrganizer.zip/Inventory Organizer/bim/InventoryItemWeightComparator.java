package bim;

import java.util.Comparator;

class InventoryItemWeightComparator
implements Comparator {

  InventoryItemWeightComparator() {
  }

  public int compare(Object obj1, Object obj2) {
    InventoryItem item1=(InventoryItem)obj1;
    InventoryItem item2=(InventoryItem)obj2;

    if(item1.getWeight()<item2.getWeight())
      return -1;
    else if(item1.getWeight()>item2.getWeight())
      return 1;

    return 0;
  }

  public boolean equals(Object obj) {
    return false;
  }
}